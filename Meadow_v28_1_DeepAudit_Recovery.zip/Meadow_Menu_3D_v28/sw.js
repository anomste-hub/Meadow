/* Meadow offline module cache. Scope: project root. */
'use strict';
const THREE_CACHE = 'meadow-three-r160-cache-v1';
self.addEventListener('install', event => { self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || !url.pathname.endsWith('/vendor/three/three.module.js')) return;
  event.respondWith((async () => {
    const cache = await caches.open(THREE_CACHE);
    const cached = await cache.match(event.request, { ignoreSearch: true });
    if (cached) return cached;
    try { return await fetch(event.request); }
    catch (_error) { return new Response('Three.js r160 is not cached yet. Open Meadow online once or add vendor/three/three.module.js.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }); }
  })());
});
