const fs=require('fs'),vm=require('vm'),path=require('path');
class Vec3{constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;}set(x,y,z){this.x=x;this.y=y;this.z=z;return this;}copy(v){return this.set(v.x,v.y,v.z)}clone(){return new Vec3(this.x,this.y,this.z)}lerp(v,a){this.x+=(v.x-this.x)*a;this.y+=(v.y-this.y)*a;this.z+=(v.z-this.z)*a;return this}}
class Vec2{constructor(x=0,y=0){this.x=x;this.y=y}set(x,y){this.x=x;this.y=y;return this}}
class Obj{constructor(){this.children=[];this.parent=null;this.userData={};this.position=new Vec3();this.rotation=new Vec3();this.scale=new Vec3(1,1,1);this.visible=true;}add(...xs){for(const x of xs){if(x.parent)x.parent.remove(x);x.parent=this;this.children.push(x)}return this}remove(x){this.children=this.children.filter(y=>y!==x);x.parent=null}traverse(fn){fn(this);for(const c of [...this.children])c.traverse(fn)}}
class Geometry{constructor(){this.attributes={}}dispose(){this.disposed=true}translate(){return this}computeVertexNormals(){}setAttribute(k,v){this.attributes[k]=v;return this}}
class BufferGeometry extends Geometry{}
class BufferAttribute{constructor(array,itemSize){this.array=array;this.itemSize=itemSize;this.count=array.length/itemSize}getY(i){return this.array[i*this.itemSize+1]}setY(i,y){this.array[i*this.itemSize+1]=y}}
class Material{constructor(o={}){Object.assign(this,o)}dispose(){this.disposed=true}}
class Texture{constructor(){this.isTexture=true;this.repeat=new Vec2()}dispose(){this.disposed=true}}
class Light extends Obj{constructor(color,intensity=1){super();this.color=color;this.intensity=intensity;this.shadow={mapSize:new Vec2(),camera:{},bias:0}}}
class Camera extends Obj{constructor(fov=50,aspect=1,near=.1,far=1000){super();this.fov=fov;this.aspect=aspect;this.near=near;this.far=far}updateProjectionMatrix(){}}
class Mesh extends Obj{constructor(geometry=new Geometry(),material=new Material()){super();this.geometry=geometry;this.material=material;this.isMesh=true}}
class Group extends Obj{}
class BufferTex extends Texture{}
class Shape{moveTo(){}lineTo(){}quadraticCurveTo(){}bezierCurveTo(){}closePath(){}}
class Clock{constructor(){this.elapsedTime=0;this.last=performance.now()}getDelta(){let n=performance.now(),d=Math.max(0,(n-this.last)/1000);this.last=n;this.elapsedTime+=d;return d}start(){this.last=performance.now()}}
class FakeElement{constructor(tag='div',id=''){this.tagName=tag.toUpperCase();this.id=id;this.children=[];this.parentNode=null;this.style={};this.attrs={};this.hidden=false;this.clientWidth=800;this.clientHeight=600;this.width=800;this.height=600;this.listeners={};this.classList={s:new Set(),add:(...a)=>a.forEach(x=>this.classList.s.add(x)),remove:(...a)=>a.forEach(x=>this.classList.s.delete(x)),contains:x=>this.classList.s.has(x)};this.textContent='';this.innerHTML='';}
 appendChild(c){if(c.parentNode)c.parentNode.removeChild(c);this.children.push(c);c.parentNode=this;return c}removeChild(c){this.children=this.children.filter(x=>x!==c);c.parentNode=null}remove(){if(this.parentNode)this.parentNode.removeChild(this)}setAttribute(k,v){this.attrs[k]=v}addEventListener(k,fn){(this.listeners[k] ||= new Set()).add(fn)}removeEventListener(k,fn){this.listeners[k]?.delete(fn)}dispatch(type,event={}){for(const fn of [...(this.listeners[type]||[])])fn({preventDefault(){},...event})}getBoundingClientRect(){return {left:0,top:0,width:this.clientWidth,height:this.clientHeight}}querySelector(sel){if(sel==='.joystick-thumb'){if(!this.thumb)this.thumb=new FakeElement('div');return this.thumb}return null}setPointerCapture(){}getContext(type){if(type==='2d')return fakeCtx;return null}}
const fakeCtx={fillRect(){},strokeRect(){},beginPath(){},moveTo(){},lineTo(){},bezierCurveTo(){},stroke(){},fillText(){},set fillStyle(v){},set strokeStyle(v){},set lineWidth(v){},set font(v){},set textAlign(v){}};
const els={chapterSceneFrame:new FakeElement('div','chapterSceneFrame'),chapterScene3D:new FakeElement('canvas','chapterScene3D'),chapterLoadingText:new FakeElement('div','chapterLoadingText'),bookOverlay:new FakeElement('div','bookOverlay')};
els.chapterSceneFrame.clientWidth=800;els.chapterSceneFrame.clientHeight=600;els.chapterSceneFrame.appendChild(els.chapterScene3D);
const document={hidden:false,getElementById:id=>id==='chapterScene3D'?(els.chapterSceneFrame.children.find(x=>x.id==='chapterScene3D')||null):(els[id]||null),createElement:tag=>new FakeElement(tag),addEventListener(){},removeEventListener(){}};
let rafId=0;const rafMap=new Map();
const rendererInstances=[];
function tickRAF(){const entry=rafMap.entries().next().value;if(!entry)return false;rafMap.delete(entry[0]);entry[1]();return true;}
class Renderer{constructor({canvas}){this.domElement=canvas;this.capabilities={isWebGL2:false};this.shadowMap={};this.info={memory:{geometries:100,textures:5}};this.disposed=false;rendererInstances.push(this)}setPixelRatio(v){this.ratio=v}setSize(w,h){this.w=w;this.h=h}render(){if(this.disposed)throw Error('render after dispose');if(this.failRender||window.__failNextRender){window.__failNextRender=false;throw Error('intentional render failure')}this.rendered=(this.rendered||0)+1}dispose(){this.disposed=true}forceContextLoss(){this.lost=true}}
class Raycaster{setFromCamera(){}intersectObjects(){return []}}
class Box3{constructor(){this.min=new Vec3(-.5,0,-.5);this.max=new Vec3(.5,1,.5)}setFromObject(){return this}getCenter(v){return v.set(0,.5,0)}getSize(v){return v.set(1,1,1)}}
class Points extends Obj{constructor(geometry,material){super();this.geometry=geometry;this.material=material}}
const THREE={Vector2:Vec2,Vector3:Vec3,Group,Scene:Group,Shape,ExtrudeGeometry:Geometry,CanvasTexture:Texture,Mesh,Points,BoxGeometry:Geometry,PlaneGeometry:Geometry,SphereGeometry:Geometry,CylinderGeometry:Geometry,TorusGeometry:Geometry,CircleGeometry:Geometry,ShapeGeometry:Geometry,TubeGeometry:Geometry,BufferGeometry,BufferAttribute,MeshStandardMaterial:Material,MeshBasicMaterial:Material,PointsMaterial:Material,PointLight:Light,HemisphereLight:Light,AmbientLight:Light,DirectionalLight:Light,PerspectiveCamera:Camera,WebGLRenderer:Renderer,Raycaster,Clock,Box3,CatmullRomCurve3:class{},Color:class{constructor(v){this.value=v}},Fog:class{},RepeatWrapping:1,SRGBColorSpace:'srgb',DoubleSide:2,PCFShadowMap:1,ACESFilmicToneMapping:2};
const window={MeadowThreeModule:THREE,devicePixelRatio:1.7,innerWidth:800,innerHeight:600,addEventListener(){},removeEventListener(){},MeadowLog:{record:(...args)=>logs.push(args)}};const logs=[];
const context={window,document,performance,console,Math,Set,Map,Array,Object,JSON,Date,DOMException,Float32Array,requestAnimationFrame:fn=>{const id=++rafId;rafMap.set(id,fn);return id},cancelAnimationFrame:id=>rafMap.delete(id),innerWidth:800,innerHeight:600,setTimeout,clearTimeout};
context.window.requestAnimationFrame=context.requestAnimationFrame;context.window.cancelAnimationFrame=context.cancelAnimationFrame;
vm.createContext(context);
vm.runInContext(fs.readFileSync(require('path').join(__dirname,'..','js','chapters','chapter-3d.js'),'utf8'),context,{filename:'chapter-3d.js'});
(async()=>{
 const api=window.MeadowChapter3D; const assert=(v,m)=>{if(!v)throw Error('ASSERT '+m)};
 await api.start({quality:'low'});assert(api.isActive(),'active');await new Promise(r=>setTimeout(r,45));tickRAF();assert(rendererInstances.at(-1).rendered>0,'first render');
 api.updateHotspots([{id:'takeBook',active:true}]);
 for(const room of ['closet','bedroom','kitchen','entry'])api.setRoom(room);
 api.setCandle(true);api.setPose('standing');api.showBook(true);
 api.stop();assert(!api.isActive(),'stopped');assert(rafMap.size===0,'RAF fully cancelled on stop');assert(!els.chapterSceneFrame.children.some(x=>x.id==='chapter3DJoystick'),'joystick removed');
 await api.start({quality:'low'});assert(api.isActive(),'restarted');await new Promise(r=>setTimeout(r,45));tickRAF();assert(rendererInstances.at(-1).rendered>0,'restart render');assert(els.chapterSceneFrame.children.some(x=>x.id==='chapterScene3D'),'canvas recreated after stop');api.stop();
 const controller=new AbortController();controller.abort();let aborted=false;try{await api.start({signal:controller.signal})}catch(e){aborted=e.name==='AbortError'}assert(aborted,'aborted start');assert(!api.isActive(),'abort remains stopped');
 // A render error during the first synchronous frame must roll back partial initialization.
 await new Promise(r=>setTimeout(r,45));window.__failNextRender=true;let firstFrameFailed=false;try{await api.start({quality:'low'})}catch(e){firstFrameFailed=e.message.includes('Перший кадр')}assert(firstFrameFailed,'first-frame error propagated');assert(!api.isActive(),'failed startup rolled back');assert(rafMap.size===0,'startup rollback cancels RAF');
 // A later render exception must stop RAF and be logged rather than spin forever.
 await api.start({quality:'low'});await new Promise(r=>setTimeout(r,45));tickRAF();const badRenderer=rendererInstances.at(-1);badRenderer.failRender=true;await new Promise(r=>setTimeout(r,45));tickRAF();assert(!api.isActive(),'render exception stops loop');assert(rafMap.size===0,'failed render cancels RAF');assert(logs.some(x=>x[2]==='Animation loop failed'),'render exception logged');api.stop();
 // WebGL context loss must halt the loop and be diagnosed.
 await api.start({quality:'low'});els.chapterSceneFrame.children.find(x=>x.id==='chapterScene3D').dispatch('webglcontextlost',{statusMessage:'test context loss'});assert(!api.isActive(),'context loss stops loop');assert(logs.some(x=>x[2]==='WebGL context lost'),'context loss logged');api.stop();
 console.log('PASS start/first render/all rooms/actions/stop/restart/abort/render-failure/context-loss');console.log('renderers',rendererInstances.length,'logs',logs.length,'rafPending',rafMap.size);assert(rafMap.size===0,'no animation callback leaked');
})().catch(e=>{console.error('FAIL',e.stack);process.exitCode=1});
