# Meadow — test plan (resource revision 45.0.0)

## Automated tests

Run from the project root:

```sh
node tests/chapter3d-smoke.cjs
node tests/menu-renderer-smoke.cjs
```

`chapter3d-smoke.cjs` uses a mock Three.js implementation. It verifies:
- chapter start and first render;
- lazy creation and switching among all four rooms;
- interaction-facing API calls;
- stop, restart and RAF cancellation;
- an already-aborted start signal;
- rollback when the first frame fails;
- logging and shutdown after a later render failure;
- WebGL context-loss handling.

`menu-renderer-smoke.cjs` uses a WebGL API stub. It verifies:
- low and high quality geometry construction;
- the normal shadow framebuffer and the incomplete-FBO fallback;
- grass toggles, quality changes, pause and resume;
- logging and shutdown after a draw failure;
- rollback after simulated shader compilation and buffer-upload failures;
- disposal and exact deletion of created shader/program/buffer/texture/renderbuffer/framebuffer handles;
- no new GPU allocations after disposal.

These are deterministic JavaScript/API tests. They do not compile GLSL with a device driver and do not replace Android WebView testing.

## Android / browser checklist

- [ ] Open the project through the same `http://localhost` or HTTPS origin on every launch.
- [ ] First launch online: save Three.js; confirm the UI says it is stored, not merely loaded for the current session.
- [ ] Reload online and confirm the log says Three.js was restored from cache or project-local path.
- [ ] Disconnect the network and reload the same origin; confirm the chapter still loads from local storage / Service Worker.
- [ ] Open and close Chapter I twice; confirm the menu context is released before the chapter renderer starts and recreated after returning.
- [ ] Tap Cancel during library loading and during scene initialization; confirm the menu returns and the loading overlay disappears.
- [ ] Test touch joystick, camera drag, taps on interactive objects, keyboard controls where available, and all four rooms.
- [ ] Test Low quality first. Record frame stability with grass off, then on. The phone profile is deliberately conservative.
- [ ] Simulate or observe a WebGL context reset; confirm the log contains a context-loss event and the chapter does not leave a permanent hidden loading overlay.
- [ ] Keep `chapters/chapter-01/story.md` empty until the author supplies the book text.

## Known limits

- A mock test cannot confirm real rendering output, GLSL-driver acceptance, sustained FPS, heat or Android GPU memory pressure.
- Three.js r160 is not bundled in the ZIP. Save it once while online or put the official module at `vendor/three/three.module.js`.
- Service Workers do not run from a raw `file://` page. Use localhost or HTTPS for the same-origin offline module path.


### Дополнительные проверки v28

`tests/chapter3d-smoke.cjs` проверяет первый кадр, сборку комнат, действия, stop/restart, abort, render failure и потерю WebGL-контекста.
`tests/menu-renderer-smoke.cjs` использует детерминированный WebGL stub: проверяет terrain-quad аргументы, uniform/attribute cache, grass buffer release, смену качества, shader/buffer/FBO failures, rollback, draw failure, dispose и равенство созданных/удалённых GPU handles. Это проверка JS/API-жизненного цикла, не измерение реального FPS или совместимости конкретного Android GPU.


### Ручная проверка WebGL на устройстве

Откройте `tests/browser-webgl-smoke.html` через тот же локальный HTTP-сервер. Страница выполняет реальную отрисовку встроенного меню, а не WebGL mock. В среде разработки Chromium присутствовал, но SwiftShader/EGL не смог инициализироваться (`EGL_NOT_INITIALIZED`), поэтому реальный GPU smoke test здесь не засчитан; его нужно пройти на Android.
