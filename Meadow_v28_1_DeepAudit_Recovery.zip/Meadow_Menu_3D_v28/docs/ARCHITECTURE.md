# Meadow architecture

## Rendering paths

- `index.html` contains the menu, settings, startup prompt, chapter list and loading transition. CSS/JS asset URLs use query version `37.0.0` to avoid stale cache on replacement.
- `css/style.css` owns visual presentation and responsive layout. Keep the current menu styling; scene improvements should not redesign UI.
- `js/engine/webgl-world.js` creates the standalone, no-download WebGL scene. It uses stable pre-generated geometry, simple directional lighting and layered contact shadow geometry.
- `js/scene/three-world.js` creates the optional Three.js scene with shadow maps and extra lighting.
- `js/storage/offline-engine.js` is the shared Three.js r160 loader for menu and chapter: it checks the local cache first, downloads once if missing, persists in IndexedDB with localStorage fallback, supports manual file import, and clears page-owned cached data/preferences.
- `js/ui/menu.js` wires controls and settings and launches Chapter I. `js/chapters/chapter-one.js` implements the first interactive chapter and its subtitle, hotspot, reading, and end-of-chapter flow.
- `js/audio/music.js` plays the local MP3.

Both renderers implement settings for time, automatic time, camera motion, birds, grass, wind strength/direction, quality, horror state, `setWalk(progress)`, and disposal.

## Scene composition constraints

The main menu scene remains the open meadow: compact irregular tree clusters, a clear path, gold wheat, distant ridges, high clouds, and distinguishable foreground grass. Chapter I is a separate real-time 3D interior in `js/chapters/chapter-3d.js`. It uses perspective camera movement and raycast interaction with 3D objects. Only the entry room is built on chapter start; the hall, kitchen and bedroom are generated when first entered. SVG room illustrations remain as legacy preview resources and are not the active 3D renderer.

## Grass and wind

- Animated layer: Low 45k, Balanced 100k, High 175k blades. They are GPU animated and should not be recreated every frame.
- Static underlayer: 100k cross-blade tufts, shown when the grass setting is enabled, to provide visible grass if a WebView has shader limitations.
- Roots are offset ~0.30–0.34 units above ground to avoid depth overlap. Placement uses a fixed seed and is weighted toward the near foreground.
- Wind must affect both lean and oscillation. Brief leaf gusts occur about every 12.8 seconds when wind is non-zero.

## Downloader/cache and chapter transition

The Chapter I renderer requires Three.js. Both the menu and Chapter I call the shared loader. The loader first reads IndexedDB (`meadow-offline-v4`, key `three-r160`), then localStorage fallback, and only then attempts a download from jsDelivr/unpkg. The downloaded source is stored once and reused by both systems. If loading fails, expose the exact error and manual download/file-picker controls; never leave a blank scene. The local-cache import error is retained and combined with a failed network-recovery error to explain the failure.

Time selection is limited to 03:00–21:00. `window.MeadowHorror.begin/end/setActive` toggles the horror preview and time-slider visibility. Chapter I calls `window.MeadowChapterOne.start()` from the menu transition. The loader signals `window.MeadowChapterReady()` when the first room is ready. Gameplay events and subtitles are in `js/chapters/chapter-one.js`; the book remains blank while `chapters/chapter-01/story.md` is empty. If Markdown fetch is blocked by `file://` restrictions, the book deliberately falls back to blank pages.


### v15 rendering
- `js/scene/three-world.js`: physically lit materials, directional PCF shadows, spatially partitioned grass with a standard `position` attribute for valid draw calls and frustum culling.
- `js/engine/webgl-world.js`: standalone fallback with directional grass shading, far-distance fade and clipping, scattered cloud layer, and baked directional tree shadows.


## Graphics update v15
The optional Three.js scene now uses physically lit grass with GPU wind deformation, receiving tree shadows, denser near-field blades, a tighter shadow camera aligned with the visible sun, separate frustum-cullable foliage/wheat cells, and a higher terrain grid. The no-download WebGL renderer remains a lightweight fallback with directional ground shading, contact shadows, and a periodically refreshed packed-depth shadow map when framebuffer support is available. Resource revision: `29.0.0`.


## Meadow v16 — grass, sky distribution and lighting
- Grass is built as three crossed tapered leaf blades per tuft, using standard position attributes and GPU wind deformation. Detail is concentrated in the foreground and fades smoothly into the turf with distance.
- The optional Three.js path uses physically lit standard materials, a subtle terrain bump texture, warm directional daylight, hemisphere fill, and soft tree/folliage shadow maps.
- Clouds are distributed over independent horizontal and vertical angles; tree trunks and crowns cluster around the woodland entrance rather than continuing down the road.
- In the offline WebGL path, grass uses the same three-blade tuft silhouette and receives a packed-depth shadow map when the framebuffer is supported. Trees are grouped near the starting woodland.
- Chapter fade and the 15-second load timeout/reset remain unchanged; ordinary UI does not narrate implementation details. Cache/resource revision is `29.0.0`.


## Meadow v17 visual pass
- Grass tufts now consist of three tapered crossed blades and are drawn using standard position geometry so Three.js can reliably determine vertex counts. Wind is vertex-shader driven; foreground detail is stronger and distant grass fades into the ground.
- Three.js uses PBR materials and a wider directional shadow volume; the built-in WebGL renderer uses a packed-depth directional shadow map when its framebuffer is supported.
- Trees are clustered near the entry, and cloud groups are distributed by horizontal and vertical viewing angles across multiple depths. Scene objects are culled by frustum/depth where the renderer supports it.
- Normal UI remains minimal; chapter fade and the 15-second timeout reset are preserved. Asset/cache revision `29.0.0`.


## Meadow v18 — visible grass and natural light
- Grass is three crossed, tapered leaves per tuft. The Three.js geometry now fills all nine vertices per tuft (not only six); roots sit close to the terrain, density is foreground-weighted, and distance fade hides fine detail toward the horizon.
- Three.js shadows are refreshed on a small time interval rather than every single frame to save mobile GPU time; sunlight, hemisphere fill, rough ground bump, PBR grass and instanced foliage share the same daylight rig.
- Trees are placed in jittered woodland pockets around the road entrance, not along the full road. Clouds are spread by viewing angle and elevation across multiple depths.
- The chapter transition's dark fade and 15-second timeout/reset are unchanged. Cache revision `29.0.0`.


## Meadow v18 — final scene pass
- Grass tufts use three slender crossed leaf blades per tuft. Every tuft fills all nine vertices, wind bends only upper vertices, and fine detail fades smoothly into terrain at distance.
- Three.js materials use physical lighting and soft shadow maps; shadows update at a throttled interval for mobile performance. The built-in renderer uses its own packed-depth shadow target where supported.
- Trees are in jittered groups near the forest entrance; clouds are sampled over horizontal and vertical viewing angles and several depths. Camera-frustum/depth culling is used for vegetation and sky elements where possible.
- Chapter fade and the 15-second loading timeout/reset remain unchanged. Cache/resource revision: `29.0.0`.


## Chapter I flow (v23)

- The scene begins with 1.35 seconds of darkness, a slow fade into the seated first-person room, and the protagonist's wake-up dialogue.
- The player gets up, approaches the front door, hears the lines about the book on the threshold, and presses the highlighted door a second time. After a blackout and tap prompt, the book is revealed.
- The player picks up the book, returns to the sofa and reads its 20-page spread. The actual story belongs only in `chapters/chapter-01/story.md`, which remains empty until the author supplies it.
- After pages 4, 8 and 12, one activity is chosen randomly from a hidden pool. The activity is performed in its room, then the player returns to the next page. The task list is never displayed all at once.
- The central room, hall/closet, bedroom and kitchen are separate SVG room scenes with object inspection dialogue. The bedroom is a room with a bed in it, not a bed-sized screen.
- Subtitles use typewriter reveal, tap-to-finish / tap-to-advance and a three-second delay after typing. Touch hotspots work independently of the optional Three.js module; WASD / arrow keys switch rooms on desktop.
- Full-room framing is retained in both orientations. Camera turning is intentionally disabled until room geometry includes real depth or off-screen areas.


## Chapter I mobile performance profile (v25)

- Low: 1.0 device-pixel-ratio cap, 30 render FPS, no real-time shadow map, reduced mesh segments and fewer dust particles.
- Balanced: 1.25 pixel-ratio cap, 45 render FPS, one 512px directional shadow map, medium mesh/texture detail.
- High: 1.55 pixel-ratio cap, 60 render FPS, antialiasing and one 1024px directional shadow map.
- Room creation is lazy; the first room is built before reveal and other room geometry is created on first entry.
- The menu quality selection is passed to the chapter renderer through `window.MeadowGameQuality`.
- `window.MeadowThreeOfflineReady` tracks whether the source is actually persisted, so session-only loading is never described as offline-ready.


### Mobile renderer compatibility

Three.js r160 is allowed to perform its built-in WebGL2-to-WebGL1 compatibility fallback. The chapter no longer rejects a valid WebGL1 context. When WebGL1 is selected, the runtime automatically drops to the Low profile (30 FPS target, pixel-ratio cap 1.0, no real-time shadows).


## Runtime architecture update — v26 (2026-11-02)

- Menu and chapter rendering are mutually exclusive. `releaseMenuWorld()` disposes the menu renderer, loses its context and replaces the canvas before Three.js creates the chapter renderer. `restoreMenuWorld()` creates a fresh canvas and starts the menu renderer after leaving the chapter or handling an error.
- The 3D chapter uses a bounded asset load pipeline: project-local `vendor/three/three.module.js` (HTTP(S) origin), IndexedDB/localStorage source cache, CacheStorage served by root `sw.js`, then CDN download. A cache check, two network attempts, import and storage operations all have explicit time limits; user cancellation propagates through AbortController.
- `sw.js` only intercepts the canonical Three.js module path and serves the saved CacheStorage response. It does not cache the whole application. Service Worker support requires secure origin (HTTPS or localhost).
- Chapter startup reads `story.md` with a 1.8-second deadline, then builds only the entry room. The user can cancel the load overlay; a 35-second final guard returns to the menu.
- `js/diagnostics.js` stores up to 240 local diagnostic events. The user can view or export the log from menu settings or the chapter loading overlay.
- Low menu quality is the mobile default and uses a smaller terrain mesh (64 divisions), fewer wheat triangles, 4,200 grass tufts and 8 clouds. This is an optimization target; FPS must still be measured on the user's device.
- `assets/models/` is a model handoff location. Use standard glTF 2.0 GLB assets and clear node names. Runtime `GLTFLoader` integration awaits actual supplied models; current scene remains procedural.
