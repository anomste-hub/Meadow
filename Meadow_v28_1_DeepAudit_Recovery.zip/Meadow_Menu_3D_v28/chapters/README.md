# Chapters

Each chapter has its own folder. The first playable chapter is `chapter-01/`.

Story text belongs in each chapter's `story.md`. That file is intentionally empty until the author adds the story; the game currently shows blank pages instead of inventing book content.

Scene beats and the intended order of actions are documented separately in `chapter-01/scene.json`. For exact pagination, separate authored book pages in `story.md` with `<!-- page -->` markers.
