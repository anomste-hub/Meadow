meadow-theme.mp3

Original music created for the Meadow menu. About 49 seconds, stereo, loopable, encoded at 112 kbps for a smaller Android/WebView package.

Keep this file at assets/audio/meadow-theme.mp3 because js/audio/music.js loads this relative path. Playback begins after a user gesture due to browser/WebView autoplay restrictions.
