# Meadow — 3D menu and interactive first chapter

Meadow is a standalone HTML/CSS/JavaScript project for a browser or Android WebView. It does not require a build step or package manager.

## Current structure

- `index.html` — page shell and local resource loader.
- `js/engine/webgl-world.js` — dependency-free WebGL renderer for the meadow menu.
- `js/storage/offline-engine.js` and `sw.js` — shared Three.js r160 loader and same-origin offline path.
- `js/chapters/chapter-one.js` — first-chapter flow, dialogue, book and tasks.
- `js/chapters/chapter-3d.js` — Three.js house scene, player controls, interactions and room lifecycle.
- `js/diagnostics.js` — local diagnostics log and text export.
- `assets/models/` — user-provided model assets and example manifest.
- `tests/` — reproducible mocked regression tests.

The first chapter contains four separately created rooms. `chapters/chapter-01/story.md` is intentionally empty; the author adds the book text.

## Run on Android

1. Extract the whole archive. Keep `index.html` beside `css/`, `js/`, `assets/`, `data/`, `chapters/` and `vendor/`.
2. Prefer a local HTTP server (`http://localhost`) or HTTPS. A `file://` launch may block ES modules, `fetch()` and Service Workers.
3. The meadow menu uses its built-in WebGL renderer and does not need Three.js. Three.js r160 is required only for the 3D chapter.
4. While online, use Settings to download/save Three.js or select the official r160 `three.module.js` file manually. Wait for the UI to confirm that it was saved. Reopen the same origin to test offline loading.
5. On touch devices the default profile is Low and grass is disabled initially. Start with Low when checking compatibility.

The Three.js source file is intentionally not embedded in this ZIP. The loader downloads it and stores it in browser storage; the optional project-local path is `vendor/three/three.module.js`. The service-worker URL requires the project to be served from localhost or HTTPS and the same origin to be used on each launch.

## Diagnostics

Open **Settings → Diagnostics** and export the `.txt` log after an error. The log includes startup phases, JavaScript errors, WebGL context events, the selected engine source and rendering statistics. It stays in local browser storage; the game does not send telemetry to a server.

## Regression tests

From the project root, with Node.js installed:

```sh
node tests/chapter3d-smoke.cjs
node tests/menu-renderer-smoke.cjs
```

These tests use mocks and a WebGL API stub. They check scene lifecycle, room creation, interaction methods, animation-loop errors, quality/grass toggles and GPU-resource cleanup. They do not emulate a real GPU or prove Android-driver compatibility; final touch, visual and FPS checks must still be made on the target device.

For a real browser WebGL smoke test, open `http://localhost:8081/tests/browser-webgl-smoke.html` while the local server is running (replace the port if needed).

## Current resource revision

The cache-busting revision in `index.html` is `45.0.0`. If an older scene remains visible, use **Settings → Reset cache** or reload the project with a new `meadow_refresh` query. If the project is wrapped in an APK, replace the embedded folder and rebuild the APK.


### Тесты и отладка

Из корня проекта: `node tests/chapter3d-smoke.cjs` и `node tests/menu-renderer-smoke.cjs`. Они используют mock WebGL/Three.js и проверяют жизненный цикл и аварийные сценарии, но не заменяют реальный тест на Android. При ошибке откройте журнал диагностики в настройках и сохраните TXT.
