/* Original Meadow menu theme. Local audio only; no streaming URL or external service. */
(function () {
  'use strict';
  const audio = new Audio('assets/audio/meadow-theme.mp3');
  audio.loop = true;
  audio.preload = 'auto';
  audio.volume = 0.28;
  let enabled = true;
  let started = false;

  function play() {
    if (!enabled) return Promise.resolve(false);
    const result = audio.play();
    if (result && typeof result.then === 'function') {
      return result.then(() => { started = true; return true; }).catch(() => false);
    }
    started = true;
    return Promise.resolve(true);
  }
  function setEnabled(value) {
    enabled = !!value;
    if (enabled) {
      // The checkbox change itself is a user gesture, so attempt playback immediately.
      play();
    } else {
      audio.pause();
    }
  }
  function setVolume(value) {
    audio.volume = Math.max(0, Math.min(1, Number(value) || 0));
  }
  function stop() { audio.pause(); audio.currentTime = 0; started = false; }

  // Unlock audio after the first gesture. This avoids autoplay-policy errors on Android.
  document.addEventListener('pointerdown', function firstGesture() {
    if (enabled) play();
  }, { once: true, passive: true });
  document.addEventListener('keydown', function firstKey() {
    if (enabled) play();
  }, { once: true });

  window.MeadowMusic = { play, pause: () => audio.pause(), stop, setEnabled, setVolume, isEnabled: () => enabled };
})();
