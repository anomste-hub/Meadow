(function(){
  'use strict';

  const $ = id => document.getElementById(id);
  const ROOM_FILES = {
    entry: 'assets/chapters/room-entry.svg?v=38.0.0',
    entrySit: 'assets/chapters/room-entry-sitting.svg?v=38.0.0',
    entryRead: 'assets/chapters/room-entry-reading.svg?v=38.0.0',
    closet: 'assets/chapters/room-closet.svg?v=38.0.0',
    bedroom: 'assets/chapters/room-bedroom.svg?v=38.0.0',
    kitchen: 'assets/chapters/room-kitchen.svg?v=38.0.0'
  };
  const COPY = {
    ru: {
      overline:'ГЛАВА ПЕРВАЯ', title:'Книга', back:'В меню', skip:'Пропустить вступление',
      objectiveLabel:'ЗАПИСКА', captionLabel:'Я', nextCaption:'Далее', interact:'Действие',
      rooms:{entry:'Центр',closet:'Прихожая',bedroom:'Спальня',kitchen:'Кухня'},
      objectives:{getUp:'Встать с дивана',goDoor:'Выйти на улицу',openDoor:'Открыть дверь',takeBook:'Поднять книгу',returnSofa:'Вернуться на диван',miniTask:'Небольшая пауза',sleepHall:'Дойти до спальни',sleepRoom:'Лечь в кровать'},
      hints:{camera:'Перетащи сцену, чтобы оглядеться',cameraFull:'Вся комната уже видна',tap:'Коснись экрана',caption:'Нажми на текст, чтобы продолжить. После печати он сменится через 3 секунды.'},
      book:{overline:'НАЙДЕННАЯ КНИГА',title:'Книга',page:'СТРАНИЦА {page} ИЗ 20',previous:'Назад',next:'Дальше',finish:'Закончить чтение',empty:'Пока здесь пусто. Историю можно добавить в chapters/chapter-01/story.md.'},
      ending:{overline:'КОНЕЦ ГЛАВЫ',title:'Первая глава завершена',text:'Я откладываю книгу и наконец иду спать. В доме тихо, а за окном мерцают редкие огоньки. На сегодня хватит.',menu:'В меню',replay:'Начать сначала'},
      startLines:['Боже... наверное, я вчера очень устал.','Нужно пойти срочно отлить.'],
      afterStand:['Так, сначала бы с дивана подняться...','Вот. Уже лучше. Теперь можно и выйти на минутку.'],
      doorLines:['Что это валяется?','Книга? Прямо у порога? Я даже не слышал, чтобы кто-то подходил.','Ладно, не сейчас.'],
      revealLines:['А теперь это... что, кто? Книга?','Зачем она мне? Хотя... раз уж лежит прямо под дверью, посмотрю.'],
      pickedLines:['Тяжёлая. И обложка совсем без подписи.','Ладно, вернусь на диван. Посмотрим, что тут внутри.'],
      sitLines:['Посмотрим...','Зажгу свечу. Так хоть страницы будут видны.'],
      finalLines:['Ладно, хватит с меня сказок!','Спать вот пора! А я здесь это самое...'],
      sleepingLines:['Вот теперь точно всё. Завтра разберусь и с книгой, и со всем остальным.'],
      mini:{
        water:{title:'Налить стакан воды',room:'kitchen',before:'Пойду налью воды. А то уже пересохло во рту.',done:'Холодная вода — то, что надо. Возвращаюсь к книге.',ambient:'water'},
        sandwich:{title:'Сделать бутерброд',room:'kitchen',before:'Сделаю бутерброд. Читать на пустой желудок — сомнительное удовольствие.',done:'Вот теперь можно и продолжить. Только крошки со стола потом убрать.',ambient:'sandwich'},
        seat2:{title:'Пересесть в другое кресло',room:'entry',before:'В этом месте уже затекла спина. Пересяду на другой диван.',done:'Так гораздо удобнее. Где я остановился?',ambient:'seat2'},
        window:{title:'Посмотреть на огоньки за окном',room:'entry',before:'Пойду взгляну в окно. Интересно, у кого ещё горит свет.',done:'В деревне уже почти все легли. Пора и мне возвращаться.',ambient:'window'},
        stretch:{title:'Немного размяться',room:'entry',before:'Нужно размяться, а то засиделся над этой книгой.',done:'Плечи уже не такие деревянные. Ладно, обратно к чтению.',ambient:'stretch'},
        flowers:{title:'Осмотреть цветы на подоконнике',room:'entry',before:'Проверю цветы у окна. Кажется, листья опять осыпаются.',done:'Надо бы не забыть про них завтра. А пока — книга.',ambient:'flowers'},
        fridge:{title:'Заглянуть в холодильник',room:'kitchen',before:'Пойду посмотрю, что осталось в холодильнике. Вдруг там найдётся что-нибудь интересное.',done:'Запасы ещё есть. Ладно, хватит отвлекаться.',ambient:'fridge'},
        candies:{title:'Взять конфету из вазочки',room:'kitchen',before:'Возьму конфету. В вазочке их уже совсем мало — надо будет докупить.',done:'Сладкое немного подняло настроение. Продолжим.',ambient:'candies'},
        jacket:{title:'Осмотреть куртку на тумбочке',room:'closet',before:'Что-то куртка опять оказалась не на вешалке. Надо разобраться.',done:'Ну вот, хотя бы заметил. Теперь обратно к книге.',ambient:'jacket'},
        calendar:{title:'Взглянуть на старый календарь',room:'entry',before:'Пойду проверю календарь. Вдруг он всё ещё показывает прошлую жизнь.',done:'2010-й... Кажется, он пережил уже не один Новый год. Пора продолжать.',ambient:'calendar'}
      },
      ambient:{
        flowers:['Цветы почти высохли. На подоконнике лежат тонкие сухие листья.','Нужно будет заняться ими завтра. Сегодня уже поздно.'],
        ashtray:['Пепельница вымыта дочиста. Смешно — будто она и правда умеет слушать.','Впрочем, сегодня в доме и без разговоров хватает тишины.'],
        cross:['Крест над дверью висит уже много лет.','Перед выходом я машинально задерживаю на нём взгляд.'],
        rug:['Коврик у двери опять припал пылью.','Я всё собираюсь его вытряхнуть. Видимо, не сегодня.'],
        window:['За окном уже совсем темно. В соседних домах ещё горят редкие лампы, а выше видны звёзды.','В нашей деревне ночи обычно тихие. Только свет в нескольких окнах напоминает, что я здесь не один.'],
        calendar:['2010 год. Вот так новость.','Календарь давно пора снять, но рука всё никак не доходит.'],
        jacket:['Куртка снова лежит на тумбочке, хотя вешалка прямо над ней.','Наверное, вчера я вернулся настолько уставшим, что просто бросил её и прошёл дальше.','Или опять решил, что повешу потом. Забавно: я обещаю себе это уже не первый вечер.'],
        wardrobe:['В шкафу всё как обычно: вещи стоят тесно, но на своих местах.','Надо бы однажды разобрать его, но это точно не дело сегодняшнего вечера.'],
        hanger:['Вешалка пустая. И ведь куртке самое место именно здесь.','Но почему-то она опять оказалась на тумбочке.'],
        coffee:['Кофе уже остыл.','Утром без него, кажется, вообще не получится нормально проснуться.'],
        cardTable:['За этим столом мы иногда играем в карты или просто сидим вдвоём.','Сейчас здесь только чашка. И тишина.'],
        bed:['Кровать застелена кое-как. Никто сегодня никуда не спешил — да и повода стараться не было.'],
        fridge:['Старый холодильник гудит так, будто ему самому есть что рассказать.','Магнитики держатся крепче, чем некоторые мои планы.'],
        candies:['В вазочке осталась всего горстка конфет.','Надо бы докупить, а то в следующий раз там будет одно дно.'],
        sink:['Раковина чистая. На сегодня посуды почти не осталось.'],
        oven:['Духовка холодная. Сегодня ей работы не досталось.'],
        shelves:['На полках посуда стоит как попало, но я хотя бы знаю, где что лежит.'],
        table:['Маленький стол пустой.','Сейчас не время есть, да и желания особо нет.']
      },
      roomLines:{entry:'Центральная комната. Здесь и вход, и диваны, и всё, что обычно откладывается на потом.',closet:'Небольшая прихожая. Шкаф, тумбочка и ещё одна дверь — в спальню.',bedroom:'Спальня маленькая. Но всё нужное здесь помещается.',kitchen:'Кухня. Старый холодильник, раковина, плита и полки с посудой.'},
      controls:'На телефоне двигайся джойстиком слева, вращай камеру пальцем и нажимай на предметы. На компьютере — WASD, перетаскивание мышью, Q/R для поворота и колёсико для приближения. Двери и вкладки ведут в другие комнаты.',
      confirm:'Вернуться в главное меню?'
    },
    en: {
      overline:'CHAPTER ONE', title:'The Book', back:'Main menu', skip:'Skip introduction',
      objectiveLabel:'NOTE', captionLabel:'ME', nextCaption:'Next', interact:'Interact',
      rooms:{entry:'Living room',closet:'Hall',bedroom:'Bedroom',kitchen:'Kitchen'},
      objectives:{getUp:'Get up from the sofa',goDoor:'Step outside',openDoor:'Open the door',takeBook:'Pick up the book',returnSofa:'Return to the sofa',miniTask:'A short break',sleepHall:'Go to the bedroom',sleepRoom:'Go to bed'},
      hints:{camera:'Drag the scene to look around',cameraFull:'The whole room is already in view',tap:'Tap the screen',caption:'Tap the text to continue. It advances 3 seconds after typing ends.'},
      book:{overline:'THE FOUND BOOK',title:'The Book',page:'PAGE {page} OF 20',previous:'Previous',next:'Next',finish:'Finish reading',empty:'The pages are blank. Add your story in chapters/chapter-01/story.md.'},
      ending:{overline:'END OF CHAPTER',title:'Chapter One Complete',text:'I put the book aside and finally go to bed. The house is quiet, and a few distant lights shimmer outside. That is enough for tonight.',menu:'Main menu',replay:'Start again'},
      startLines:['God... I must have been really tired yesterday.','I really need to step outside.'],
      afterStand:['First, I should get up from this sofa...','There. Better. Now I can step outside for a moment.'],
      doorLines:['What is that lying there?','A book? Right on the doorstep? I did not hear anyone come by.','Not now.'],
      revealLines:['And now this... what is it? A book?','What would I need it for? Well... since it is right here, I might as well look.'],
      pickedLines:['Heavy. And there is no name on the cover.','I will go back to the sofa and see what is inside.'],
      sitLines:['Let’s see...','I will light the candle. At least I will be able to see the pages.'],
      finalLines:['That is enough fairy tales for me!','Time for bed! What am I still doing here...'],
      sleepingLines:['That is definitely enough for tonight. I will deal with the book tomorrow.'],
      mini:{
        water:{title:'Get a glass of water',room:'kitchen',before:'I will get some water. My throat is dry.',done:'Cold water. Just what I needed. Back to the book.',ambient:'water'},
        sandwich:{title:'Make a sandwich',room:'kitchen',before:'I will make a sandwich. Reading on an empty stomach is not ideal.',done:'Now I can continue. I should clean up the crumbs later.',ambient:'sandwich'},
        seat2:{title:'Move to the other sofa',room:'entry',before:'My back is getting stiff here. I will move to the other sofa.',done:'Much more comfortable. Where was I?',ambient:'seat2'},
        window:{title:'Look at the village lights',room:'entry',before:'I will look out the window. I wonder whose lights are still on.',done:'Most of the village is asleep. I should get back.',ambient:'window'},
        stretch:{title:'Stretch a little',room:'entry',before:'I need to stretch. I have been sitting too long.',done:'My shoulders feel a little better. Back to reading.',ambient:'stretch'},
        flowers:{title:'Check the flowers',room:'entry',before:'I will check the flowers. More leaves seem to be falling.',done:'I should remember them tomorrow. For now, the book.',ambient:'flowers'},
        fridge:{title:'Check the fridge',room:'kitchen',before:'I will see what is left in the fridge. Maybe there is something interesting.',done:'There are still supplies. Enough distractions for now.',ambient:'fridge'},
        candies:{title:'Take a sweet',room:'kitchen',before:'I will take a sweet. The bowl is almost empty; I should buy more.',done:'A little sugar helps. Let’s continue.',ambient:'candies'},
        jacket:{title:'Look at the jacket',room:'closet',before:'The jacket is on the cabinet again, not on the hook. I should look at that.',done:'At least I noticed it. Back to the book.',ambient:'jacket'},
        calendar:{title:'Look at the old calendar',room:'entry',before:'I will check the calendar. Maybe it still thinks it is another year.',done:'2010... It has survived quite a few New Years. Back to reading.',ambient:'calendar'}
      },
      ambient:{
        flowers:['The flowers are almost dry. Thin leaves lie on the windowsill.','I should take care of them tomorrow. It is too late tonight.'],
        ashtray:['The ashtray is spotless. Funny, as if it could really listen.','Still, the house is quiet enough without another conversation.'],
        cross:['The cross above the door has been there for years.','I always glance at it before going out.'],
        rug:['The little rug by the door is dusty again.','I keep promising to shake it out. Perhaps not tonight.'],
        window:['It is completely dark outside. A few lamps are still on in the neighbouring houses, and stars are visible above them.','Nights in this village are usually quiet. Only the lights in a few windows remind me that I am not alone here.'],
        calendar:['2010. What a surprise.','I should take this calendar down one day, but somehow I never do.'],
        jacket:['The jacket is on the cabinet again, even though the hook is right above it.','I must have been so tired yesterday that I dropped it there and kept walking.','Or maybe I just told myself I would hang it up later. Funny — I have made that promise more than once.'],
        wardrobe:['Everything in the wardrobe is as usual: crowded, but in its place.','I should sort it out one day, just not tonight.'],
        hanger:['The hook is empty. The jacket belongs right here.','And somehow it ended up on the cabinet again.'],
        coffee:['The coffee has gone cold.','I can hardly wake up in the morning without it.'],
        cardTable:['Sometimes we play cards here or just sit together.','Right now there is only a cup. And silence.'],
        bed:['The bed is made rather carelessly. Nobody was in a hurry today, and there was no reason to make it perfect.'],
        fridge:['The old fridge hums as if it has a story of its own.','The magnets seem to stick better than some of my plans.'],
        candies:['There are only a few sweets left in the bowl.','I should buy more before it is completely empty.'],
        sink:['The sink is clean. There is hardly any washing-up left tonight.'],
        oven:['The oven is cold. It has had nothing to do today.'],
        shelves:['The dishes are arranged any which way, but I know where everything is.'],
        table:['The little table is empty.','It is not time to eat, and I do not really feel like it.']
      },
      roomLines:{entry:'The central room. The entrance, the sofas, and all the things I keep putting off are here.',closet:'A small hall. A wardrobe, a cabinet, and another door — to the bedroom.',bedroom:'The bedroom is small, but everything important fits.',kitchen:'The kitchen. An old fridge, a sink, an oven and shelves of dishes.'},
      controls:'On a phone, move with the joystick, drag to look around and tap real objects. On a computer use WASD, mouse drag, Q/R to rotate and the wheel to zoom. Doors and room tabs move between rooms.',
      confirm:'Return to the main menu?'
    }
  };

  // This pool is intentionally not displayed to the player. One unused activity is
  // selected at each reading pause, so the player never sees a wall of tasks.
  const MINI_POOL = ['water','sandwich','seat2','window','stretch','flowers','fridge','candies','jacket','calendar'];
  const HOTSPOTS = {
    entry:{
      standUp:{x:205,y:900,label:'Встать'}, frontDoor:{x:450,y:645,label:'Дверь'}, takeBook:{x:450,y:795,label:'Поднять книгу'}, sitSofa:{x:205,y:900,label:'Сесть'}, seat2:{x:685,y:900,label:'Пересесть'},
      flowers:{x:255,y:485},ashtray:{x:650,y:485},cross:{x:450,y:245},rug:{x:450,y:1030},calendar:{x:125,y:355},doorCloset:{x:90,y:645,label:'Прихожая'},doorKitchen:{x:810,y:645,label:'Кухня'},window:{x:680,y:410},stretch:{x:450,y:970},sandwich:{x:450,y:900}
    },
    closet:{jacket:{x:645,y:740},wardrobe:{x:260,y:550},hanger:{x:620,y:485},doorBedroom:{x:775,y:600,label:'Спальня'},doorBack:{x:42,y:620,label:'Центр'}},
    bedroom:{bed:{x:310,y:830,label:'Кровать'},coffee:{x:670,y:585},cardTable:{x:690,y:720},doorBack:{x:100,y:635,label:'Прихожая'}},
    kitchen:{water:{x:700,y:635,label:'Вода'},sandwich:{x:655,y:525,label:'Бутерброд'},fridge:{x:220,y:590},candies:{x:330,y:860},sink:{x:700,y:635},oven:{x:760,y:950},shelves:{x:700,y:340},table:{x:450,y:930},doorBack:{x:42,y:620,label:'Центр'}}
  };

  let active=false, host={}, state=null, timers=new Set(), imageCache={}, captionToken=0;
  const lang=()=>host&&typeof host.language==='function'&&host.language()==='en'?'en':'ru';
  const t=(path,args)=>{
    const data=COPY[lang()];
    let value=path.split('.').reduce((obj,key)=>obj&&obj[key],data);
    if(typeof value!=='string')return path;
    if(args)Object.keys(args).forEach(key=>{value=value.replace(new RegExp('\\{'+key+'\\}','g'),String(args[key]));});
    return value;
  };
  const later=(fn,ms)=>{const id=setTimeout(()=>{timers.delete(id);fn();},ms);timers.add(id);return id;};
  function cancelTimer(id){if(id){clearTimeout(id);timers.delete(id);}}
  function clearTimers(){timers.forEach(clearTimeout);timers.clear();captionToken++;}
  function showObjective(key,args){
    if(!state)return;
    const text=!key?'':(key==='custom'?(args&&args.text||''):t('objectives.'+key,args||{}));
    $('chapterObjective').textContent=text;
    $('chapterObjectiveWrap').hidden=!text;
  }
  function setCaptionLabel(){ $('chapterCaptionLabel').textContent=t('captionLabel'); }
  function clearDialogue(){
    if(!state)return;
    if(state.dialogue&&state.dialogue.typeTimer)cancelTimer(state.dialogue.typeTimer);
    if(state.dialogue&&state.dialogue.autoTimer)cancelTimer(state.dialogue.autoTimer);
    state.dialogue=null; state.dialogueActive=false; captionToken++;
  }
  function typeDialogueLine(){
    if(!state||!state.dialogue)return;
    const d=state.dialogue, token=++captionToken;
    const text=d.lines[d.index];
    d.token=token;d.position=0;d.complete=false;
    $('chapterCaption').textContent='';$('chapterCaption').classList.add('is-typing');
    $('chapterCaptionContinue').textContent='…';
    const chars=Array.from(text);
    const tick=()=>{
      if(!active||!state||!state.dialogue||state.dialogue.token!==token)return;
      d.position++;
      $('chapterCaption').textContent=chars.slice(0,d.position).join('');
      if(d.position<chars.length){d.typeTimer=later(tick,27);}
      else{
        d.complete=true;$('chapterCaption').classList.remove('is-typing');
        $('chapterCaptionContinue').textContent=t('nextCaption');
        d.autoTimer=later(()=>advanceDialogue(true),3000);
      }
    };
    d.typeTimer=later(tick,27);
  }
  function playLines(lines,onDone){
    if(!state)return;
    clearDialogue();
    state.dialogue={lines:Array.isArray(lines)?lines:[String(lines)],index:0,onDone:typeof onDone==='function'?onDone:null,complete:false,typeTimer:null,autoTimer:null};
    state.dialogueActive=true;setCaptionLabel();renderHotspots();typeDialogueLine();
  }
  function advanceDialogue(fromTimer){
    if(!state||!state.dialogue)return;
    const d=state.dialogue;
    if(!d.complete){
      cancelTimer(d.typeTimer);d.position=Array.from(d.lines[d.index]).length;
      $('chapterCaption').textContent=d.lines[d.index];$('chapterCaption').classList.remove('is-typing');
      d.complete=true;$('chapterCaptionContinue').textContent=t('nextCaption');
      d.autoTimer=later(()=>advanceDialogue(true),3000);
      return;
    }
    cancelTimer(d.autoTimer);
    if(d.index<d.lines.length-1){d.index++;typeDialogueLine();return;}
    const done=d.onDone;state.dialogue=null;state.dialogueActive=false;captionToken++;
    $('chapterCaptionContinue').textContent='';
    if(done)done();
    if(state&&state.pendingAction){const queued=state.pendingAction;state.pendingAction=null;later(()=>{if(active&&state&&!state.dialogueActive)perform(queued);},0);}
    renderHotspots();
  }
  function sayAmbient(key){
    if(!state||state.dialogueActive||state.phase==='introBlack'||state.phase==='awaitTap'||state.phase==='ending')return;
    const lines=COPY[lang()].ambient[key];if(!lines)return;
    playLines(lines,()=>renderHotspots());
  }
  function refreshText(){
    if(!state)return;
    $('chapterOverline').textContent=t('overline');$('chapterTitle').textContent=t('title');$('chapterBackLabel').textContent=t('back');$('chapterSkipLabel').textContent=t('skip');$('chapterObjectiveLabel').textContent=t('objectiveLabel');$('chapterInteractLabel').textContent=t('interact');$('chapterControlHint').textContent=t('controls');
    $('roomLabelEntry').textContent=t('rooms.entry');$('roomLabelCloset').textContent=t('rooms.closet');$('roomLabelBedroom').textContent=t('rooms.bedroom');$('roomLabelKitchen').textContent=t('rooms.kitchen');
    $('chapterRoomNav').setAttribute('aria-label',lang()==='en'?'Move around the house':'Перемещение по дому');
    $('bookOverline').textContent=t('book.overline');$('bookHeading').textContent=t('book.title');$('bookPreviousLabel').textContent=t('book.previous');$('bookEmptyNote').textContent=t('book.empty');
    $('endingOverline').textContent=t('ending.overline');$('endingTitle').textContent=t('ending.title');$('endingText').textContent=t('ending.text');$('endingMenuLabel').textContent=t('ending.menu');$('endingReplay').textContent=t('ending.replay');
    $('chapterTapText').textContent=t('hints.tap');
    if(state.dialogue){$('chapterCaption').textContent=state.dialogue.lines[state.dialogue.index].slice(0,state.dialogue.position||0);}
    setCaptionLabel();updateBookUI();updateRoomNav();
  }
  function escapeHtml(value){return String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
  function inlineMarkdown(value){return escapeHtml(value).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*]+)\*/g,'<em>$1</em>');}
  function markdownPageHtml(source){
    const blocks=String(source||'').trim().split(/\n[ \t]*\n+/).filter(block=>block.trim());
    return blocks.map(block=>{
      const s=block.trim(),h=s.match(/^(#{1,3})\s+(.+)$/);
      if(h)return '<h'+h[1].length+'>'+inlineMarkdown(h[2])+'</h'+h[1].length+'>';
      if(/^[-*]\s+/m.test(s)){const items=s.split(/\r?\n/).map(line=>line.match(/^[-*]\s+(.+)$/)).filter(Boolean);if(items.length)return '<ul>'+items.map(item=>'<li>'+inlineMarkdown(item[1])+'</li>').join('')+'</ul>';}
      return '<p>'+inlineMarkdown(s).replace(/\r?\n/g,'<br>')+'</p>';
    }).join('');
  }
  function paginateMarkdown(source){
    const text=String(source||'').replace(/^\uFEFF/,'').trim();if(!text)return [];
    const explicit=text.split(/^\s*<!--\s*page\s*-->\s*$/im).map(x=>x.trim()).filter(Boolean);
    if(explicit.length>1)return explicit.slice(0,20);
    const parts=text.split(/\n[ \t]*\n+/).map(x=>x.trim()).filter(Boolean);
    if(parts.length<=20)return parts.slice(0,20);
    const per=Math.ceil(parts.length/20),out=[];for(let i=0;i<parts.length;i+=per)out.push(parts.slice(i,i+per).join('\n\n'));return out.slice(0,20);
  }
  async function loadStoryPages(signal){
    const controller=new AbortController();let timer=null;
    const abort=()=>controller.abort();if(signal){if(signal.aborted)throw new DOMException('Завантаження скасовано.','AbortError');signal.addEventListener('abort',abort,{once:true});}
    timer=setTimeout(()=>controller.abort(),1800);
    try{
      const res=await fetch('chapters/chapter-01/story.md?v=41.0.0',{cache:'no-store',signal:controller.signal});
      if(!res.ok){if(window.MeadowLog)window.MeadowLog.record('warn','story','story.md unavailable; the book will stay blank',{status:res.status});return [];}
      const text=await res.text();return paginateMarkdown(text);
    }catch(err){
      if(signal&&signal.aborted)throw new DOMException('Завантаження скасовано.','AbortError');
      if(window.MeadowLog)window.MeadowLog.record('warn','story','Could not read story.md; using blank pages',err);
      return [];
    }finally{clearTimeout(timer);if(signal)signal.removeEventListener('abort',abort);}
  }
  function renderBookPage(textId,blankId,n){
    const el=$(textId),blank=$(blankId),content=state&&state.storyPages&&n>0&&n<=state.storyPages.length?state.storyPages[n-1]:'';
    el.innerHTML=content?markdownPageHtml(content):'';el.style.display=content?'block':'none';blank.style.display=content?'none':'block';
  }
  function updateBookUI(){
    if(!state)return;const p=Math.max(1,Math.min(20,state.page||1));
    $('bookLeftNumber').textContent=p>1?String(p-1):'';$('bookRightNumber').textContent=String(p);$('bookPageCount').textContent=t('book.page',{page:p});
    $('bookPrevious').disabled=p<=1;$('bookNextLabel').textContent=p>=20?t('book.finish'):t('book.next');$('bookNext').setAttribute('aria-label',p>=20?t('book.finish'):t('book.next'));
    renderBookPage('bookLeftText','bookLeftBlank',p-1);renderBookPage('bookRightText','bookRightBlank',p);
  }
  function hideBook(){ $('bookOverlay').classList.remove('visible');$('bookOverlay').hidden=true;$('bookOverlay').setAttribute('aria-hidden','true');if(state)state.bookOpen=false; }
  function openBook(page){
    if(!state||state.phase!=='reading'||state.dialogueActive)return;
    state.bookOpen=true;state.page=Math.max(1,Math.min(20,page||state.readProgress+1));
    $('bookOverlay').hidden=false;$('bookOverlay').setAttribute('aria-hidden','false');$('bookOverlay').classList.add('visible');updateBookUI();
  }
  function closeBook(){if(!state||!state.bookOpen)return;hideBook();renderHotspots();}
  function shuffledPool(){
    const pool=MINI_POOL.slice();
    for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}
    return pool;
  }
  function chooseMiniTask(){
    if(!state.taskPool||!state.taskPool.length)state.taskPool=shuffledPool();
    const id=state.taskPool.pop();return {id,...COPY[lang()].mini[id]};
  }
  function startMiniPause(milestone){
    if(!state)return;
    hideBook();state.phase='miniTask';state.readProgress=milestone;state.pausedAt.push(milestone);state.currentTask=chooseMiniTask();
    $('chapterGame').classList.remove('is-seated');showObjective('custom',{text:state.currentTask.title});updateRoomNav();renderHotspots();
    const before=state.currentTask.before;
    let reaction='';
    if(milestone===4)reaction='Что за дичь?';
    else if(milestone===8)reaction='Точно что дичь, зачем я это читаю?';
    else reaction='Фу, ну что за нежности. Где там...';
    playLines([reaction,before],()=>{showObjective('custom',{text:state.currentTask.title});renderHotspots();});
  }
  function completeMiniTask(id){
    if(!state||state.phase!=='miniTask'||!state.currentTask||state.currentTask.id!==id)return;
    const task=state.currentTask;state.completedTasks.push(id);state.currentTask=null;state.phase='reading';
    const extra=id==='jacket'?COPY[lang()].ambient.jacket:[];
    if(id==='stretch'){$('chapterGame').classList.add('is-stretching');later(()=>$('chapterGame').classList.remove('is-stretching'),1400);}
    playLines([...(extra||[]),task.done,'Ну что же, продолжим.'],()=>{
      state.phase='returnToBook';state.seated=false;showObjective('returnSofa');updateRoomNav();renderHotspots();
    });
  }
  function finishReading(){
    if(!state)return;hideBook();state.phase='sleepReady';state.readProgress=20;state.currentTask=null;state.room='entry';state.seated=false;$('chapterGame').classList.remove('is-seated');selectRoom('entry',{quiet:true});
    playLines(COPY[lang()].finalLines,()=>{showObjective('sleepHall');renderHotspots();});
  }
  function nextPage(){
    if(!state||!state.bookOpen)return;
    const p=state.page;
    if(p===20){state.readProgress=20;finishReading();return;}
    state.page=p+1;state.readProgress=Math.max(state.readProgress,state.page);updateBookUI();
    if([4,8,12].includes(state.page)&&!state.pausedAt.includes(state.page))startMiniPause(state.page);
  }
  function previousPage(){if(!state||!state.bookOpen||state.page<=1)return;state.page--;updateBookUI();}
  function setRoomAsset(room){
    const image=$('chapterRoomImage');
    const src=room==='entry'?(state.openingPose?ROOM_FILES.entrySit:(state.candleLit?ROOM_FILES.entryRead:ROOM_FILES.entry)):ROOM_FILES[room];
    image.setAttribute('href',src);image.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href',src);
  }
  function updateRoomNav(){
    if(!state)return;
    const allowNav=state.phase==='miniTask'||state.phase==='returnToBook'||state.phase==='sleepReady'||(state.phase==='reading'&&!state.bookOpen);
    document.querySelectorAll('#chapterRoomNav [data-room]').forEach(btn=>{
      const room=btn.dataset.room;btn.classList.toggle('is-active',room===state.room);
      const locked=room==='bedroom'&&!state.visitedCloset;
      btn.disabled=locked||!allowNav||state.phase==='introBlack'||state.phase==='awaitTap'||state.phase==='ending'||!!state.bookOpen||state.dialogueActive;
      btn.classList.toggle('is-target',!!state.currentTask&&state.currentTask.room===room);
    });
  }
  function selectRoom(room,opts){
    if(!state||!ROOM_FILES[room])return;
    const allowNav=state.phase==='miniTask'||state.phase==='returnToBook'||state.phase==='sleepReady'||(state.phase==='reading'&&!state.bookOpen);
    if(room!==state.room&&!allowNav)return;
    if(room==='bedroom'&&!state.visitedCloset)return;
    const options=opts||{};state.room=room;state.focusIndex=0;state.cameraX=0;setRoomAsset(room);if(window.MeadowChapter3D&&window.MeadowChapter3D.isActive())window.MeadowChapter3D.setRoom(room);
    $('chapterCamera').style.transform='';$('chapterScene').dataset.room=room;
    updateRoomNav();renderHotspots();
    if(!options.quiet&&state.phase!=='introBlack'&&state.phase!=='awaitTap'&&!state.dialogueActive){
      const lines=COPY[lang()].roomLines[room];if(lines)playLines([lines],()=>renderHotspots());
    }
  }
  function hotspotMarkup(item,index){
    const x=item.x,y=item.y,label=item.label||'',activeItem=!!item.active;
    const w=Math.min(240,Math.max(112,label.length*8+28)),labelY=y>850?-58:42;
    return `<g class="chapter-hotspot ${activeItem?'is-task':'is-ambient'}" transform="translate(${x} ${y})" tabindex="0" role="button" aria-label="${escapeHtml(label||item.id)}" data-action="${item.id}"><circle class="hotspot-hit" r="${activeItem?48:38}" fill="transparent"/><circle class="hotspot-pulse" r="25"/><circle class="hotspot-ring" r="15"/><circle class="hotspot-core" r="5"/>${activeItem?`<g class="hotspot-label" transform="translate(0 ${labelY})"><rect x="${-w/2}" y="0" width="${w}" height="34" rx="7"/><text x="0" y="22" text-anchor="middle">${escapeHtml(label)}</text></g>`:''}</g>`;
  }
  function renderHotspots(){
    if(!state)return;const group=$('chapterHotspots');if(!group)return;
    const all=[],room=state.room,coords=HOTSPOTS[room]||{};
    const add=(id,label,activeItem)=>{const p=coords[id];if(p)all.push({id,x:p.x,y:p.y,label:label||p.label||'',active:!!activeItem});};
    if((!state.dialogueActive||state.phase==='miniTask')&&state.phase!=='introBlack'&&state.phase!=='awaitTap'&&state.phase!=='ending'&&!state.bookOpen){
      if(state.phase==='getUp'&&room==='entry')add('standUp','Встать',true);
      if((state.phase==='goDoor'||state.phase==='doorFound')&&room==='entry')add('frontDoor',state.phase==='doorFound'?'Открыть дверь':'Подойти к двери',true);
      if(state.phase==='takeBook'&&room==='entry'&&state.bookVisible)add('takeBook','Поднять книгу',true);
      if(state.phase==='returnSofa'&&room==='entry')add('sitSofa','Сесть на диван',true);
      if(state.phase==='miniTask'&&state.currentTask&&state.currentTask.room===room){
        const id=state.currentTask.id;const map={water:'water',sandwich:'sandwich',seat2:'seat2',window:'window',stretch:'stretch',flowers:'flowers',fridge:'fridge',candies:'candies',jacket:'jacket',calendar:'calendar'};add(map[id],state.currentTask.title,true);
      }
      if(state.phase==='returnToBook'&&room==='entry')add('sitSofa','Вернуться к книге',true);
      if(state.phase==='sleepReady'){
        if(room==='entry')add('doorCloset','В прихожую',true);
        if(room==='closet')add('doorBedroom','В спальню',true);
        if(room==='bedroom')add('bed','Лечь спать',true);
      }
      // Ambient inspection points remain subtle and never appear as a task list.
      const ambientByRoom={entry:['flowers','ashtray','cross','rug','calendar','doorCloset','doorKitchen','window'],closet:['jacket','wardrobe','hanger','doorBedroom','doorBack'],bedroom:['coffee','cardTable','bed','doorBack'],kitchen:['fridge','candies','sink','oven','shelves','table','doorBack']};
      (ambientByRoom[room]||[]).forEach(id=>{
        if(all.some(x=>x.id===id))return;
        if(state.currentTask&&((state.currentTask.id==='water'&&id==='sink')||(state.currentTask.id==='sandwich'&&id==='table')))return;
        // Hide ambient navigation during a critical objective; ambient details stay tappable.
        if(['doorCloset','doorKitchen','doorBedroom','doorBack'].includes(id)&&state.phase!=='miniTask'&&state.phase!=='returnToBook'&&state.phase!=='sleepReady')return;
        add(id,'',false);
      });
    }
    const bookProp=(state.bookVisible&&state.phase==='takeBook'&&room==='entry')?`<g class="chapter-book-prop" transform="translate(410 770) rotate(-13)"><ellipse cx="24" cy="56" rx="46" ry="13" fill="#080a08" opacity=".5"/><path d="M0 8L43 0L55 43L11 53Z" fill="#513326" stroke="#b99762" stroke-width="3"/><path d="M5 10L40 4L49 39L14 46Z" fill="#8b6545"/><path d="M12 12L37 8L43 34L17 39Z" fill="#c6b18a"/><path d="M12 12L37 8" stroke="#e0ceaa" stroke-width="2"/></g>`:'';
    state.hotspots=all;group.innerHTML=bookProp+all.map(hotspotMarkup).join('');if(window.MeadowChapter3D&&window.MeadowChapter3D.isActive())window.MeadowChapter3D.updateHotspots(all);
    $('chapterInteract').disabled=!all.some(x=>x.active)||state.dialogueActive;
    updateRoomNav();
  }
  function updateCameraCapability(){
    if(!state)return;
    state.cameraEnabled=true;state.cameraX=0;
    $('chapterCameraHint').textContent=lang()==='en'?'Drag the 3D scene to look around · Q / R on keyboard':'Перетаскивай 3D-сцену, чтобы оглядеться · Q / R на клавиатуре';
    $('chapterCameraHint').hidden=false;
    $('chapterScene').classList.remove('camera-pan-enabled');
    $('chapterCamera').style.transform='';
  }
  function perform(id){
    if(!state||state.bookOpen)return;if(state.dialogueActive){if(state.phase==='miniTask'&&state.currentTask&&state.currentTask.id===id)state.pendingAction=id;return;}
    if(state.phase==='introBlack'||state.phase==='awaitTap'||state.phase==='ending')return;
    switch(id){
      case 'standUp':
        if(state.phase!=='getUp')return;state.phase='goDoor';state.seated=false;state.openingPose=false;if(window.MeadowChapter3D)window.MeadowChapter3D.setPose('standing');setRoomAsset('entry');$('chapterGame').classList.remove('is-seated');
        playLines(COPY[lang()].afterStand,()=>{showObjective('goDoor');renderHotspots();});return;
      case 'frontDoor':
        if(state.phase==='goDoor'){state.phase='doorFound';playLines(COPY[lang()].doorLines,()=>{showObjective('openDoor');renderHotspots();});return;}
        if(state.phase==='doorFound'){if(window.MeadowChapter3D)window.MeadowChapter3D.openDoor('frontDoor',startDoorBlackout);else startDoorBlackout();return;}return;
      case 'takeBook':
        if(state.phase!=='takeBook')return;state.hasBook=true;state.bookVisible=false;if(window.MeadowChapter3D)window.MeadowChapter3D.showBook(false);state.phase='returnSofa';
        playLines(COPY[lang()].pickedLines,()=>{showObjective('returnSofa');renderHotspots();});return;
      case 'sitSofa':
        if(state.phase==='returnToBook'){state.phase='reading';state.seated=true;state.candleLit=true;if(window.MeadowChapter3D)window.MeadowChapter3D.setCandle(true);$('chapterGame').classList.add('is-reading-seat');showObjective('');playLines(['Ну что же, продолжим.'],()=>openBook(state.readProgress+1));return;}
        if(state.phase!=='returnSofa')return;state.phase='reading';state.seated=true;state.candleLit=true;if(window.MeadowChapter3D)window.MeadowChapter3D.setCandle(true);setRoomAsset('entry');$('chapterGame').classList.add('is-reading-seat');
        playLines(COPY[lang()].sitLines,()=>{showObjective('');openBook(1);});return;
      case 'doorCloset':
        if(state.phase==='sleepReady'&&state.room==='entry'){state.visitedCloset=true;const go=()=>{selectRoom('closet',{quiet:true});showObjective('sleepHall');renderHotspots();};if(window.MeadowChapter3D)window.MeadowChapter3D.openDoor('doorCloset',go);else go();return;}
        if(state.phase==='miniTask'||state.phase==='returnToBook'||state.phase==='reading'){state.visitedCloset=true;const go=()=>selectRoom('closet');if(window.MeadowChapter3D)window.MeadowChapter3D.openDoor('doorCloset',go);else go();return;}
        return;
      case 'doorKitchen':
        if(state.phase==='miniTask'||state.phase==='returnToBook'||state.phase==='reading'){const go=()=>selectRoom('kitchen');if(window.MeadowChapter3D)window.MeadowChapter3D.openDoor('doorKitchen',go);else go();return;}return;
      case 'doorBedroom':
        if(state.room==='closet'&&(state.phase==='sleepReady'||state.phase==='miniTask'||state.phase==='returnToBook'||state.phase==='reading')){state.visitedCloset=true;selectRoom('bedroom',{quiet:true});if(state.phase==='sleepReady')showObjective('sleepRoom');renderHotspots();return;}return;
      case 'doorBack':
        if(state.room==='bedroom'){const go=()=>selectRoom('closet');if(window.MeadowChapter3D)window.MeadowChapter3D.openDoor('doorBack',go);else go();return;}if(state.room==='closet'||state.room==='kitchen'){const go=()=>selectRoom('entry');if(window.MeadowChapter3D)window.MeadowChapter3D.openDoor('doorBack',go);else go();return;}return;
      case 'bed':
        if(state.phase==='sleepReady'&&state.room==='bedroom'){beginSleep();return;}sayAmbient('bed');return;
      case 'water':case 'sandwich':case 'seat2':case 'window':case 'stretch':case 'flowers':case 'fridge':case 'candies':case 'jacket':case 'calendar':
        if(state.phase==='miniTask'&&state.currentTask&&state.currentTask.id===id){completeMiniTask(id);return;}
        break;
      case 'ashtray':case 'cross':case 'rug':case 'wardrobe':case 'hanger':case 'coffee':case 'cardTable':case 'sink':case 'oven':case 'shelves':case 'table':
        sayAmbient(id);return;
    }
    // Inspecting the object associated with the current task is also a valid ambient action.
    const alias={water:'sink',sandwich:'table',seat2:'seat2',window:'window',stretch:'stretch',flowers:'flowers',fridge:'fridge',candies:'candies',jacket:'jacket',calendar:'calendar'};
    if(id in COPY[lang()].ambient){sayAmbient(id);return;}
    if(alias[id]&&alias[id] in COPY[lang()].ambient)sayAmbient(alias[id]);
  }
  function startDoorBlackout(){
    if(!state)return;state.phase='awaitTap';$('chapterBlackout').classList.add('active');$('chapterBlackout').setAttribute('aria-hidden','false');
    later(()=>{if(!active||!state||state.phase!=='awaitTap')return;$('chapterTapPrompt').hidden=false;$('chapterTapPrompt').classList.add('visible');},1250);
  }
  function revealBook(){
    if(!state||state.phase!=='awaitTap')return;
    $('chapterTapPrompt').classList.remove('visible');$('chapterTapPrompt').hidden=true;
    state.phase='takeBook';state.bookVisible=true;if(window.MeadowChapter3D)window.MeadowChapter3D.showBook(true);$('chapterBlackout').classList.remove('active');$('chapterBlackout').setAttribute('aria-hidden','true');
    playLines(COPY[lang()].revealLines,()=>{showObjective('takeBook');renderHotspots();});
  }
  function beginSleep(){
    state.phase='ending';$('chapterGame').classList.add('is-sleeping');
    playLines(COPY[lang()].sleepingLines,()=>{
      $('chapterIntroBlack').hidden=false;$('chapterIntroBlack').classList.remove('is-clearing');
      later(()=>{$('chapterIntroBlack').hidden=true;$('chapterEnding').hidden=false;$('chapterEnding').setAttribute('aria-hidden','false');$('chapterEnding').classList.add('visible');},1200);
    });
  }
  function showEnd(){
    if(!host||typeof host.onReturn!=='function')return;
    if(!window.confirm(t('confirm')))return;
    const cb=host.onReturn;stop();cb();
  }
  function stop(){
    clearTimers();clearDialogue();active=false;state=null;host={};if(window.MeadowChapter3D)window.MeadowChapter3D.stop();
    ['chapterGame','bookOverlay','chapterEnding'].forEach(id=>{$(id).classList.remove('visible','is-sleeping','is-seated','is-reading-seat');$(id).hidden=true;$(id).setAttribute('aria-hidden','true');});
    $('chapterBlackout').classList.remove('active');$('chapterTapPrompt').hidden=true;$('chapterIntroBlack').classList.remove('is-visible');$('chapterControlsHint').hidden=true;$('chapterControlsHint').classList.remove('is-gone');
  }
  function preloadRoom(room){
    if(imageCache[room])return imageCache[room];
    imageCache[room]=new Promise(resolve=>{const img=new Image();img.onload=()=>resolve(true);img.onerror=()=>resolve(false);img.src=ROOM_FILES[room];});return imageCache[room];
  }
  async function start(options){
    clearTimers();host=options||{};active=true;
    state={room:'entry',candleLit:false,phase:'introBlack',focusIndex:0,hotspots:[],captionKey:'',hasBook:false,bookVisible:false,seated:true,openingPose:true,bookOpen:false,page:1,readProgress:0,storyPages:[],visitedCloset:false,visitedBedroom:false,completedTasks:[],pausedAt:[],taskPool:shuffledPool(),currentTask:null,dialogue:null,dialogueActive:false,pendingAction:null,cameraX:0,cameraEnabled:false};
    $('chapterEnding').classList.remove('visible');$('chapterEnding').hidden=true;$('chapterEnding').setAttribute('aria-hidden','true');
    $('bookOverlay').classList.remove('visible');$('bookOverlay').hidden=true;$('bookOverlay').setAttribute('aria-hidden','true');
    $('chapterGame').classList.remove('is-sleeping','is-stretching','is-seated','is-reading-seat');$('chapterGame').hidden=false;$('chapterGame').classList.add('visible','is-seated');$('chapterGame').setAttribute('aria-hidden','false');
    $('chapterIntroBlack').classList.remove('is-clearing','is-visible');$('chapterIntroBlack').hidden=false;
    $('chapterTapPrompt').hidden=true;$('chapterBlackout').classList.remove('active');
    $('chapterObjectiveWrap').hidden=true;$('chapterCaption').textContent='';$('chapterCaptionContinue').textContent='';$('chapterControlsHint').hidden=true;$('chapterControlsHint').classList.remove('is-gone');
    refreshText();selectRoom('entry',{quiet:true});updateCameraCapability();renderHotspots();
    const loaded=await loadStoryPages(host.signal);
    if(host.signal&&host.signal.aborted)throw new DOMException('Завантаження скасовано.','AbortError');
    if(!active||!state)return;state.storyPages=loaded||[];updateBookUI();if(!window.MeadowChapter3D)throw new Error('Не знайдено модуль 3D-сцени js/chapters/chapter-3d.js.');
    if(window.MeadowLog)window.MeadowLog.record('info','chapter-one','Story data ready; starting 3D room renderer',{storyPages:state.storyPages.length});
    await window.MeadowChapter3D.start({onInteract:id=>perform(id),quality:window.MeadowGameQuality||'low',signal:host.signal,onProgress:host.onProgress});
    if(host.signal&&host.signal.aborted)throw new DOMException('Завантаження скасовано.','AbortError');
    window.MeadowChapter3D.setRoom('entry');window.MeadowChapter3D.setCandle(false);window.MeadowChapter3D.showBook(false);window.MeadowChapter3D.updateHotspots(state.hotspots||[]);
    if(typeof window.MeadowChapterReady==='function')window.MeadowChapterReady();
    // Stay in complete darkness for 1.35 seconds, then reveal the seated view slowly.
    later(()=>{
      if(!active||!state)return;$('chapterIntroBlack').classList.add('is-clearing');
      later(()=>{
        if(!active||!state)return;$('chapterIntroBlack').hidden=true;state.phase='getUp';showObjective('getUp');
        $('chapterControlsHint').hidden=false;$('chapterControlsHint').classList.remove('is-gone');
        later(()=>{$('chapterControlsHint').classList.add('is-gone');},8500);
        playLines(COPY[lang()].startLines,()=>renderHotspots());
      },1450);
    },1350);
  }

  // UI bindings
  document.querySelector('.chapter-caption').addEventListener('click',event=>{
    if(event.target.closest('.chapter-actions'))return;
    advanceDialogue(false);
  });
  $('chapterHotspots').addEventListener('click',event=>{const node=event.target.closest('.chapter-hotspot');if(!node)return;perform(node.dataset.action);});
  $('chapterHotspots').addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){const node=event.target.closest('.chapter-hotspot');if(node){event.preventDefault();perform(node.dataset.action);}}});
  document.querySelectorAll('#chapterRoomNav [data-room]').forEach(button=>button.addEventListener('click',()=>selectRoom(button.dataset.room)));
  $('chapterInteract').addEventListener('click',()=>{if(!state)return;const target=(state.hotspots||[]).find(item=>item.active);if(target)perform(target.id);});
  $('chapterSkipIntro').addEventListener('click',()=>{
    if(!state)return;clearDialogue();state.phase='getUp';$('chapterIntroBlack').classList.add('is-clearing');$('chapterIntroBlack').hidden=true;showObjective('getUp');$('chapterControlsHint').hidden=false;$('chapterControlsHint').classList.remove('is-gone');later(()=>$('chapterControlsHint').classList.add('is-gone'),8500);playLines(COPY[lang()].startLines,()=>renderHotspots());
  });
  $('chapterBack').addEventListener('click',showEnd);
  $('chapterTapPrompt').addEventListener('click',revealBook);
  $('chapterBlackout').addEventListener('click',()=>{if(state&&state.phase==='awaitTap'&&!$('chapterTapPrompt').hidden)revealBook();});
  $('bookNext').addEventListener('click',nextPage);$('bookPrevious').addEventListener('click',previousPage);$('closeBook').addEventListener('click',closeBook);
  $('endingMenu').addEventListener('click',()=>{const cb=host.onReturn;stop();if(typeof cb==='function')cb();});
  $('endingReplay').addEventListener('click',()=>start(host));

  // The 3D room camera remains draggable in every orientation.
  window.addEventListener('resize',updateCameraCapability);
  document.addEventListener('keydown',event=>{
    if(!active||!state)return;
    if(state.bookOpen){if(event.key==='Escape'){event.preventDefault();closeBook();}else if(event.key==='ArrowLeft'){event.preventDefault();previousPage();}else if(['ArrowRight','Enter',' '].includes(event.key)){event.preventDefault();nextPage();}return;}
    if(state.dialogueActive&&(event.key==='Enter'||event.key===' ')){event.preventDefault();advanceDialogue(false);return;}
    if(state.dialogueActive&&event.key!=='Escape')return;
    if(event.key==='Escape'){event.preventDefault();showEnd();return;}
    if(event.key==='Enter'){event.preventDefault();const h=(state.hotspots||[]).find(item=>item.active);if(h)perform(h.id);}
  });

  window.MeadowChapterOne={
    start,stop,
    setLanguage(){if(active&&state){refreshText();updateCameraCapability();}},
    isActive(){return active;}
  };
})();
