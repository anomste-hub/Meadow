(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const DEFAULTS={time:660/1440,autoTime:true,cameraMotion:true,birds:true,wind:.62,windDirection:'right',quality:'low',grass:false,horrorMode:false,musicEnabled:true,musicVolume:.28};
  const STRINGS={
    uk:{installTitle:'Завантажити додаткові файли для офлайн-режиму?',installText:'Це необов’язково. Файл можна додати пізніше в налаштуваннях.',download:'Завантажити',builtIn:'Не зараз',ready:'Можна завантажити бібліотеку або обрати файл із пристрою.',cached:'Three.js уже збережено для офлайн-запуску.',downloading:'Завантажую додатковий файл у фоні…',downloaded:'Three.js готовий і збережений для офлайн-запуску.',engineBuiltIn:'Меню працює на вбудованому WebGL. Three.js потрібен лише для глав.',engineThree:'Three.js збережено для запуску 3D-глав офлайн.',engineThreeSession:'Three.js доступний лише в цьому сеансі; офлайн-копії немає.',cacheConfirm:'Очистити локальні налаштування й збережений 3D-модуль, потім перезапустити проєкт?',cacheDone:'Локальне сховище очищено. Перезапускаю сторінку з новим параметром кешу.',levelsNotice:'Тут поки немає рівнів. Коли вони з’являться, список буде в цьому вікні.',exitNotice:'У браузері сторінку зазвичай не можна закрити скриптом. Скористайся кнопкою «Назад» на пристрої.',downloadError:'Завантаження не вдалося. Спробуй посилання або вибери файл у налаштуваннях.',language:'Мова змінена.'},
    en:{installTitle:'Download additional files for offline use?',installText:'This is optional. You can add the file later in Settings.',download:'Download',builtIn:'Not now',ready:'You can download the library or choose a file from your device.',cached:'Three.js is already saved for offline use.',downloading:'Downloading the additional file in the background…',downloaded:'Three.js is ready and saved for offline use.',engineBuiltIn:'Menu uses built-in WebGL. Three.js is only needed for chapters.',engineThree:'Three.js is saved for offline chapter loading.',engineThreeSession:'Three.js is available for this session only; no offline copy exists.',cacheConfirm:'Clear local preferences and the saved 3D module, then restart the project?',cacheDone:'Local storage cleared. Restarting the page with a fresh cache key.',levelsNotice:'There are no levels yet. When added, they will appear in this panel.',exitNotice:'Browsers usually do not allow a page to close itself. Use your device Back button.',downloadError:'Download failed. Try the direct link or choose a file in Settings.',language:'Language changed.'}
  };
  let language='uk',noticeTimeout=null,world=null,moduleNamespace=null;
  let startupChoice='';
  try{
    startupChoice=localStorage.getItem('meadow-startup-choice-v34')||localStorage.getItem('meadow-startup-choice-v33')||'';
    if(startupChoice)localStorage.setItem('meadow-startup-choice-v34',startupChoice);
  }catch(_e){}
  let prefs=Object.assign({},DEFAULTS),loadedCurrentPrefs=false;
  try{
    const current=localStorage.getItem('meadow-settings-v34')||localStorage.getItem('meadow-settings-v33');
    if(current){prefs=Object.assign(prefs,JSON.parse(current));loadedCurrentPrefs=true;try{localStorage.setItem('meadow-settings-v34',JSON.stringify(prefs));}catch(_e){}}
    else{
      const saved=localStorage.getItem('meadow-settings-v7')||localStorage.getItem('meadow-settings-v6')||localStorage.getItem('meadow-settings-v4');
      if(saved){prefs=Object.assign(prefs,JSON.parse(saved));prefs.grass=true;prefs.time=660/1440;prefs.horrorMode=false;/* Reset stale scene settings after the lighting/grass redesign. */}
    }
  }catch(_e){}
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  prefs.time=Number.isFinite(Number(prefs.time))?clamp(Number(prefs.time),3/24,21/24):DEFAULTS.time;
  prefs.wind=clamp(Number(prefs.wind)||0,0,1.6);
  prefs.musicVolume=clamp(Number(prefs.musicVolume)||0,0,1);
  prefs.horrorMode=!!prefs.horrorMode;prefs.musicEnabled=prefs.musicEnabled!==false;
  const coarseDevice=!!(window.matchMedia&&window.matchMedia('(pointer:coarse)').matches);
  if(coarseDevice){prefs.quality='low';prefs.grass=false;}
  window.MeadowGameQuality=prefs.quality||'low';
  const controls={autoTime:'autoTime',cameraMotion:'cameraMotion',birds:'birds',grass:'grass',windDirection:'windDirection',quality:'quality'};
  function savePrefs(){try{localStorage.setItem('meadow-settings-v34',JSON.stringify(prefs));}catch(_e){}}
  function notify(message,duration=3400){const n=$('notice');n.textContent=message;n.classList.add('show');clearTimeout(noticeTimeout);noticeTimeout=setTimeout(()=>n.classList.remove('show'),duration);}
  function open(id){$(id).classList.add('visible');}
  function close(id){$(id).classList.remove('visible');}
  function translate(){document.documentElement.lang=language;document.querySelectorAll('[data-uk][data-en]').forEach(el=>{el.textContent=el.getAttribute(language==='uk'?'data-uk':'data-en');});$('lang').innerHTML=language==='uk'?'UA <b>/</b> EN':'EN <b>/</b> UA';if($('startupTitle'))$('startupTitle').textContent=language==='uk'?'Увімкнути розширену 3D-сцену?':'Enable the enhanced 3D scene?';updateEngineStatus();if(window.MeadowChapterOne)window.MeadowChapterOne.setLanguage();}
  function syncControls(){
    $('autoTime').checked=!!prefs.autoTime;$('cameraMotion').checked=!!prefs.cameraMotion;$('birds').checked=!!prefs.birds;$('grass').checked=!!prefs.grass;$('musicEnabled').checked=!!prefs.musicEnabled;
    $('time').value=clamp(Math.round(prefs.time*1440),180,1260);$('windStrength').value=Math.round(prefs.wind*100);$('windValue').textContent=Math.round(prefs.wind*100)+'%';$('windDirection').value=prefs.windDirection;$('quality').value=prefs.quality;$('musicVolume').value=Math.round(prefs.musicVolume*100);$('musicVolumeValue').textContent=Math.round(prefs.musicVolume*100)+'%';
    $('timeControl').hidden=!!prefs.horrorMode;updateClock();
  }
  function updateClock(){const mins=clamp(Math.round((world?world.getTime():prefs.time)*1440),180,1260);$('clock').textContent=String(Math.floor(mins/60)).padStart(2,'0')+':'+String(mins%60).padStart(2,'0');}
  function applyAll(){if(!world)return;world.setTime(prefs.time);world.setAuto(prefs.autoTime);world.setMotion(prefs.cameraMotion);world.setBirds(prefs.birds);world.setGrass(prefs.grass);world.setWind(prefs.wind);world.setWindDirection(prefs.windDirection);world.setHorror(prefs.horrorMode);world.setQuality(prefs.quality);if(window.MeadowMusic){window.MeadowMusic.setVolume(prefs.musicVolume);window.MeadowMusic.setEnabled(prefs.musicEnabled);}}
  function updateEngineStatus(){const text=window.MeadowThreeModule?(window.MeadowThreeOfflineReady?STRINGS[language].engineThree:STRINGS[language].engineThreeSession):STRINGS[language].engineBuiltIn;$('engineStatus').textContent=text;}
  function bootBuiltIn(){const canvas=$('world');try{world=window.MeadowWebGL.create(canvas,prefs);}catch(err){world={engine:'WebGL unavailable',setTime(){},getTime(){return prefs.time;},setAuto(){},setMotion(){},setBirds(){},setGrass(){},setWind(){},setWindDirection(){},setHorror(){},setQuality(){},dispose(){}};notify('WebGL: '+(err&&err.message?err.message:'помилка створення сцени'));}$('engineStatus').textContent=world.engine==='WebGL unavailable'?'WebGL недоступний у цьому WebView.':STRINGS[language].engineBuiltIn;updateClock();}
  function releaseMenuWorld(){
    if(world&&world.dispose){try{world.dispose();}catch(err){if(window.MeadowLog)window.MeadowLog.record('warn','menu-renderer','Menu renderer dispose failed',err);}}
    const oldCanvas=$('world');
    if(oldCanvas){
      try{const gl=oldCanvas.getContext('webgl2')||oldCanvas.getContext('webgl')||oldCanvas.getContext('experimental-webgl');const ext=gl&&gl.getExtension&&gl.getExtension('WEBGL_lose_context');if(ext)ext.loseContext();}catch(_e){}
      const fresh=document.createElement('canvas');fresh.id='world';fresh.setAttribute('aria-label','Тривимірний луг');oldCanvas.replaceWith(fresh);
    }
    world=null;window.MeadowWorld=null;
    if(window.MeadowLog)window.MeadowLog.record('info','menu-renderer','Released menu WebGL context before loading chapter');
  }
  function restoreMenuWorld(){
    if(world)return;
    bootBuiltIn();window.MeadowWorld=world;
    if(window.MeadowLog)window.MeadowLog.record('info','menu-renderer','Recreated lightweight menu renderer after chapter');
  }
  function acceptThreeModule(result){
    if(!result||!result.module)throw new Error('Three.js loader returned an empty module.');
    window.MeadowThreeModule=result.module;window.MeadowThreeOfflineReady=!!result.saved;
    if(result.saved){try{localStorage.setItem('meadow-startup-choice-v34','three');}catch(_e){}startupChoice='three';}
    else{try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';}
    updateEngineStatus();return result;
  }
  window.MeadowThreeOfflineReady=false;window.MeadowWorld=null;bootBuiltIn();window.MeadowWorld=world;world.setHorror(prefs.horrorMode);
  if(startupChoice==='builtin'||startupChoice==='three')close('startupDialog');
  // The menu does not need Three.js and never downloads/imports it in the background.
  async function restoreCachedEngine(){
    try{
      const mod=await window.MeadowOffline.loadCached();
      if(!mod)throw new Error('Кеш Three.js відсутній.');
      window.MeadowThreeModule=mod;window.MeadowThreeOfflineReady=true;
      $('startupStatus').textContent=STRINGS[language].cached;updateEngineStatus();
      if(window.MeadowLog)window.MeadowLog.record('info','menu','Three.js restored for chapter use; menu keeps its lightweight WebGL renderer.');
      return true;
    }catch(err){
      window.MeadowThreeModule=null;window.MeadowThreeOfflineReady=false;
      try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';
      $('libraryStatus').textContent=err.message||String(err);updateEngineStatus();
      if(window.MeadowLog)window.MeadowLog.record('warn','menu','Could not restore saved Three.js; menu remains available',err);
      return false;
    }
  }

  const cachedCheck=startupChoice==='three'?restoreCachedEngine():Promise.resolve(false);
  let libraryLoadController=null;
  $('installEngine').addEventListener('click',async()=>{
    const btn=$('installEngine');btn.disabled=true;libraryLoadController=new AbortController();$('cancelLibraryLoad').hidden=false;close('startupDialog');open('settingsDialog');$('libraryStatus').textContent=STRINGS[language].downloading;$('startupStatus').textContent=STRINGS[language].downloading;
    try{
      const result=await window.MeadowOffline.loadOnline(info=>{if(info.phase==='bytes'){const loaded=(info.loaded/1024).toFixed(0)+' KB',total=info.total?(info.total/1024).toFixed(0)+' KB':'';const progress=language==='uk'?('Завантажено '+loaded+(total?' із '+total:'')):('Downloaded '+loaded+(total?' of '+total:''));if($('libraryStatus'))$('libraryStatus').textContent=progress;return;}if(info.phase==='direct'){const direct=language==='uk'?('Перевіряю пряме підключення '+info.host+'…'):('Trying direct module import from '+info.host+'…');if($('libraryStatus'))$('libraryStatus').textContent=direct;return;}const message=language==='uk'?('Завантаження бібліотеки — сервер '+info.attempt+' із '+info.total+' ('+info.host+')…'):('Downloading library — server '+info.attempt+' of '+info.total+' ('+info.host+')…');if($('libraryStatus'))$('libraryStatus').textContent=message;},{signal:libraryLoadController.signal});
      if(result.module){
        acceptThreeModule(result);
        if(result.saved){try{localStorage.setItem('meadow-startup-choice-v34','three');}catch(_e){}startupChoice='three';$('libraryStatus').textContent=language==='uk'?'Three.js збережено у '+(result.storage||'локальному сховищі')+'.':'Three.js saved to '+(result.storage||'local storage')+'.';}
        else{
          try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';
          const warning=result.warning||(language==='uk'?'Бібліотеку запущено, але браузер не зберіг її для офлайн.':'The library is loaded, but the browser did not save it for offline use.');
          notify(warning,6000);$('libraryStatus').textContent=warning;
        }
        updateEngineStatus();
      }else{try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';notify(STRINGS[language].downloadError,6000);}
    }catch(err){
      try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';
      if(err&&err.name==='AbortError'){$('libraryStatus').textContent='Завантаження Three.js скасовано.';return;}
      const message=(err&&err.message)?err.message:STRINGS[language].downloadError;
      $('libraryStatus').textContent=message+' '+(language==='uk'?'Можна скачати файл за прямим посиланням нижче або обрати його вручну.':'Use the direct download link below or choose the file manually.');open('settingsDialog');notify(message,9000);
    }finally{btn.disabled=false;$('cancelLibraryLoad').hidden=true;libraryLoadController=null;}
  });
  $('cancelLibraryLoad').addEventListener('click',()=>{if(libraryLoadController&&!libraryLoadController.signal.aborted){libraryLoadController.abort();$('libraryStatus').textContent='Завантаження Three.js скасовано.';if(window.MeadowLog)window.MeadowLog.record('info','three','Library download cancelled by user');}});
  function chooseBuiltIn(){try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';close('startupDialog');}
  $('useBuiltIn').addEventListener('click',()=>{chooseBuiltIn();});
  $('startupClose').addEventListener('click',()=>{chooseBuiltIn();});
  $('settings').addEventListener('click',()=>open('settingsDialog'));
  $('play').addEventListener('click',()=>open('levelsDialog'));
  let chapterLoadController=null,chapterSafetyTimer=null;
  async function returnFromChapter(){
    const veil=$('chapterTransition');
    veil.classList.add('active');veil.setAttribute('aria-hidden','false');veil.style.backgroundColor='rgba(5,9,6,.92)';
    await waitMs(260);
    restoreMenuWorld();
    if(world&&world.setWalk)world.setWalk(0);
    veil.style.backgroundColor='rgba(5,9,6,0)';
    await waitMs(850);
    veil.classList.remove('active');veil.setAttribute('aria-hidden','true');veil.style.backgroundColor='';
    if(world&&world.resume)world.resume();
  }
  function cancelChapterLoad(reason){
    if(chapterLoadController&&!chapterLoadController.signal.aborted){chapterLoadController.abort(reason||'user-cancel');if(window.MeadowLog)window.MeadowLog.record('info','chapter','Chapter loading cancelled by user',reason||'cancel button');}
  }
  async function launchChapterOne(){
    const btn=$('startChapter1'),veil=$('chapterTransition'),loadingText=$('chapterLoadingText');
    if(btn.disabled)return;
    if(!('AbortController' in window)){notify('Цей браузер не підтримує безпечне скасування завантаження. Онови браузер або відкрий проєкт у Chrome.');return;}
    btn.disabled=true;close('levelsDialog');chapterLoadController=new AbortController();const signal=chapterLoadController.signal;
    if(world&&world.pause)world.pause();releaseMenuWorld();
    veil.classList.add('active');veil.setAttribute('aria-hidden','false');veil.style.backgroundColor='rgba(5,9,6,.68)';
    $('chapterCancelLoad').hidden=false;loadingText.textContent='Читання данных первой главы…';
    if(window.MeadowLog)window.MeadowLog.record('info','chapter','Chapter I launch requested',{quality:window.MeadowGameQuality||'low',online:navigator.onLine,origin:location.origin||'file'});
    // Network/cache operations have their own 22-second deadline. This is a final
    // guard for stuck scene initialization; the Cancel button remains available.
    chapterSafetyTimer=setTimeout(()=>{if(chapterLoadController===null||signal.aborted)return;window.MeadowLog&&window.MeadowLog.record('error','chapter','Chapter initialization exceeded 50-second safety limit');cancelChapterLoad('safety-timeout');},50000);
    try{
      if(!window.MeadowChapterOne)throw new Error('Не знайдено модуль js/chapters/chapter-one.js.');
      window.MeadowChapterReady=()=>{};
      await window.MeadowChapterOne.start({language:()=>language,onReturn:returnFromChapter,signal,onProgress:info=>{
        if(!info||signal.aborted)return;
        if(info.phase==='bytes')loadingText.textContent='Завантаження Three.js: '+Math.round(info.loaded/1024)+' КБ'+(info.total?' / '+Math.round(info.total/1024)+' КБ':'')+'…';
        else if(info.phase==='connect')loadingText.textContent='Підключення до '+info.host+' ('+info.attempt+'/'+info.total+')…';
        else if(info.phase==='import')loadingText.textContent='Перевірка та запуск 3D-бібліотеки…';
        else loadingText.textContent=info.message||'Побудова першої кімнати…';
      }});
      if(signal.aborted)throw new DOMException('Завантаження скасовано.','AbortError');
      $('chapterCancelLoad').hidden=true;
      if(window.MeadowLog)window.MeadowLog.record('info','chapter','Chapter I scene is ready',window.MeadowChapter3DInfo||{});
      await waitMs(180);veil.style.backgroundColor='rgba(5,9,6,0)';await waitMs(500);
      veil.classList.remove('active');veil.setAttribute('aria-hidden','true');veil.style.backgroundColor='';
    }catch(err){
      if(window.MeadowChapterOne){try{window.MeadowChapterOne.stop();}catch(cleanupError){if(window.MeadowLog)window.MeadowLog.record('error','chapter','Chapter cleanup failed; continuing recovery',cleanupError);}}
      restoreMenuWorld();if(world&&world.resume)world.resume();
      veil.style.backgroundColor='rgba(5,9,6,.35)';await waitMs(120);open('levelsDialog');
      veil.classList.remove('active');veil.setAttribute('aria-hidden','true');veil.style.backgroundColor='';
      if(err&&err.name==='AbortError'){
        if(signal.reason==='safety-timeout'){loadingText.textContent='Перевищено граничний час запуску. Переглянь журнал помилок.';notify('Запуск глави перевищив 50 секунд. Перевір журнал діагностики.',9000);if(window.MeadowLog)window.MeadowLog.record('error','chapter','Chapter startup aborted by safety timeout');}
        else{loadingText.textContent='Завантаження скасовано.';notify('Завантаження глави скасовано.',2500);}
      }else{
        const detail=(err&&err.message)?err.message:'Невідома помилка 3D-глави.';
        if(window.MeadowLog)window.MeadowLog.record('error','chapter','Chapter I failed to start',err);
        notify('Не вдалося запустити главу: '+detail,11000);
        $('startupStatus').textContent=detail;$('libraryStatus').textContent=detail;
      }
    }finally{clearTimeout(chapterSafetyTimer);chapterSafetyTimer=null;btn.disabled=false;$('chapterCancelLoad').hidden=true;chapterLoadController=null;}
  }
  const waitMs=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  $('startChapter1').addEventListener('click',launchChapterOne);
  $('chapterCancelLoad').addEventListener('click',()=>cancelChapterLoad('cancel-button'));
  document.addEventListener('keydown',e=>{if(chapterLoadController&&(e.key==='Escape'||e.key==='Backspace')){e.preventDefault();cancelChapterLoad('escape');}});
  $('exit').addEventListener('click',()=>notify(STRINGS[language].exitNotice));
  document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>close(btn.dataset.close)));
  document.querySelectorAll('.dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)close(d.id);}));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'||e.key==='Backspace'){const active=document.querySelector('.dialog.visible');if(active){close(active.id);e.preventDefault();}}});
  $('lang').addEventListener('click',()=>{language=language==='uk'?'en':'uk';translate();});
  $('autoTime').addEventListener('change',e=>{prefs.autoTime=e.target.checked;world.setAuto(prefs.autoTime);savePrefs();});
  $('cameraMotion').addEventListener('change',e=>{prefs.cameraMotion=e.target.checked;world.setMotion(prefs.cameraMotion);savePrefs();});
  $('birds').addEventListener('change',e=>{prefs.birds=e.target.checked;world.setBirds(prefs.birds);savePrefs();});
  $('grass').addEventListener('change',e=>{prefs.grass=e.target.checked;world.setGrass(prefs.grass);savePrefs();});
  function setHorrorMode(active){prefs.horrorMode=!!active;$('timeControl').hidden=prefs.horrorMode;if(world&&world.setHorror)world.setHorror(prefs.horrorMode);savePrefs();}
  window.MeadowHorror={setActive:setHorrorMode,begin(){setHorrorMode(true);},end(){setHorrorMode(false);},isActive(){return !!prefs.horrorMode;}};
  $('time').addEventListener('input',e=>{prefs.time=clamp(Number(e.target.value)/1440,3/24,21/24);world.setTime(prefs.time);updateClock();savePrefs();});
  $('windStrength').addEventListener('input',e=>{prefs.wind=Number(e.target.value)/100;$('windValue').textContent=Math.round(prefs.wind*100)+'%';world.setWind(prefs.wind);savePrefs();});
  $('windDirection').addEventListener('change',e=>{prefs.windDirection=e.target.value;world.setWindDirection(prefs.windDirection);savePrefs();});
  $('quality').addEventListener('change',e=>{prefs.quality=e.target.value;window.MeadowGameQuality=prefs.quality;world.setQuality(prefs.quality);savePrefs();});
  $('musicEnabled').addEventListener('change',e=>{prefs.musicEnabled=e.target.checked;if(window.MeadowMusic)window.MeadowMusic.setEnabled(prefs.musicEnabled);savePrefs();});
  $('musicVolume').addEventListener('input',e=>{prefs.musicVolume=clamp(Number(e.target.value)/100,0,1);$('musicVolumeValue').textContent=Math.round(prefs.musicVolume*100)+'%';if(window.MeadowMusic)window.MeadowMusic.setVolume(prefs.musicVolume);savePrefs();});
  $('installFromSettings').addEventListener('click',async()=>{open('startupDialog');$('startupStatus').textContent=STRINGS[language].ready;$('installEngine').disabled=false;});
  $('chooseLibrary').addEventListener('click',()=>{$('libraryFile').click();});
  $('libraryFile').addEventListener('change',async e=>{
    const file=e.target.files&&e.target.files[0];if(!file)return;
    const status=$('libraryStatus');status.textContent=language==='uk'?'Читаю '+file.name+'…':'Reading '+file.name+'…';
    try{
      const result=await window.MeadowOffline.importFile(file);
      acceptThreeModule(result);
      if(result.saved){try{localStorage.setItem('meadow-startup-choice-v34','three');}catch(_e){}startupChoice='three';status.textContent=language==='uk'?'Бібліотеку завантажено та збережено офлайн.':'Library imported and saved for offline use.';}
      else{try{localStorage.setItem('meadow-startup-choice-v34','builtin');}catch(_e){}startupChoice='builtin';status.textContent=language==='uk'?'Бібліотеку підключено, але збереження офлайн недоступне — після перезапуску може знадобитися обрати файл знову.':'Library loaded, but offline storage is unavailable — you may need to select it again after restarting.';}
      updateEngineStatus();
    }catch(err){status.textContent=(err&&err.message)?err.message:'Не вдалося прочитати бібліотеку.';if(window.MeadowLog)window.MeadowLog.record('error','three','Manual Three.js import failed',err);notify(status.textContent);}
    finally{e.target.value='';}
  });
  $('clearCache').addEventListener('click',async()=>{
    if(!window.confirm(STRINGS[language].cacheConfirm))return;
    try{if(world&&world.dispose)world.dispose();releaseMenuWorld();const errors=await window.MeadowOffline.clear();$('startupStatus').textContent=errors.length?'Частину кешу браузер не дозволив очистити.':'Локальне сховище очищене.';const u=new URL(window.location.href);u.searchParams.set('meadow_refresh',String(Date.now()));window.location.replace(u.href);}catch(err){notify('Не вдалося повністю очистити кеш: '+(err.message||''));}
  });
  syncControls();
  if(window.MeadowMusic){window.MeadowMusic.setVolume(prefs.musicVolume);window.MeadowMusic.setEnabled(prefs.musicEnabled);}
  // A cached download can finish while the startup panel is already visible; keep the UI in sync.
  cachedCheck.then(found=>{if(found)updateEngineStatus();});
  setInterval(()=>{if(world&&world.getTime){updateClock();}},700);
  window.MeadowMenuReady=true;
})();
