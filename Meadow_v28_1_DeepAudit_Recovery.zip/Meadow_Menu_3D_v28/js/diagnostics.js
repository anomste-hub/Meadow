/* Lightweight, persistent diagnostics for Meadow. No network telemetry. */
(function () {
  'use strict';
  const KEY = 'meadow-diagnostics-v1';
  const MAX = 240;
  let entries = [];
  try { entries = JSON.parse(localStorage.getItem(KEY) || '[]'); if (!Array.isArray(entries)) entries = []; }
  catch (_e) { entries = []; }

  function safe(value) {
    if (value instanceof Error) return { name: value.name, message: value.message, stack: value.stack || '' };
    if (value && typeof value === 'object') {
      try { return JSON.parse(JSON.stringify(value)); } catch (_e) { return String(value); }
    }
    return value == null ? '' : String(value);
  }
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(entries.slice(-MAX))); } catch (_e) {} }
  function record(level, area, message, details) {
    const item = { time: new Date().toISOString(), level: String(level || 'info'), area: String(area || 'app'), message: String(message || ''), details: safe(details) };
    entries.push(item); if (entries.length > MAX) entries = entries.slice(-MAX); persist();
    const method = item.level === 'error' ? 'error' : item.level === 'warn' ? 'warn' : 'log';
    try { console[method]('[Meadow][' + item.area + '] ' + item.message, item.details || ''); } catch (_e) {}
    render(); return item;
  }
  function serialize() { return entries.map(e => '[' + e.time + '] ' + e.level.toUpperCase() + ' [' + e.area + '] ' + e.message + (e.details ? '\n' + (typeof e.details === 'string' ? e.details : JSON.stringify(e.details)) : '')).join('\n\n'); }
  function render() { const out = document.getElementById('diagnosticsOutput'); if (out) out.textContent = serialize() || 'Журнал пока пуст.'; }
  function open() { const panel = document.getElementById('diagnosticsPanel'); if (panel) { panel.hidden = false; render(); } }
  function close() { const panel = document.getElementById('diagnosticsPanel'); if (panel) panel.hidden = true; }
  function download() {
    const blob = new Blob([serialize() || 'Meadow diagnostics: no entries'], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'meadow-diagnostics.txt'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1200);
  }
  function clear() { entries = []; persist(); render(); }
  window.MeadowLog = { record, open, close, render, download, clear, getEntries: () => entries.slice(), text: serialize };
  window.addEventListener('error', event => record('error', 'window', event.message || 'JavaScript error', { file: event.filename, line: event.lineno, column: event.colno, error: event.error }));
  window.addEventListener('unhandledrejection', event => record('error', 'promise', 'Unhandled promise rejection', event.reason));
  record('info', 'boot', 'Diagnostics initialized', { href: location.href, userAgent: navigator.userAgent, online: navigator.onLine, pixelRatio: window.devicePixelRatio || 1 });
  document.addEventListener('DOMContentLoaded', () => {
    const bind = (id, fn) => { const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
    bind('showDiagnostics', open); bind('chapterShowDiagnostics', open); bind('closeDiagnostics', close);
    bind('downloadDiagnostics', download); bind('clearDiagnostics', clear);
    render();
  });
})();
