/* Meadow's built-in real-time WebGL 3D renderer. No CDN or external files required. */
(function () {
  'use strict';
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function seeded(seed) { return function () { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }; }
  function mix(a, b, t) { return a.map((v, i) => v + (b[i] - v) * t); }
  function smooth(a, b, x) { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
  function pathCenter(z) { return 2.2 + Math.sin((z + 13.8) * 0.24) * 0.72; }

  function matPerspective(fov, aspect, near, far) {
    const f = 1 / Math.tan(fov / 2), nf = 1 / (near - far);
    return new Float32Array([f / aspect,0,0,0, 0,f,0,0, 0,0,(far + near) * nf,-1, 0,0,2 * far * near * nf,0]);
  }
  function matOrtho(left,right,bottom,top,near,far) {
    return new Float32Array([2/(right-left),0,0,0, 0,2/(top-bottom),0,0, 0,0,-2/(far-near),0, -(right+left)/(right-left),-(top+bottom)/(top-bottom),-(far+near)/(far-near),1]);
  }
  function normalize(v) { const n = Math.hypot(v[0],v[1],v[2]) || 1; return [v[0]/n,v[1]/n,v[2]/n]; }
  function cross(a,b) { return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]; }
  function dot(a,b) { return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
  function matLookAt(eye, target, up) {
    const z = normalize([eye[0]-target[0],eye[1]-target[1],eye[2]-target[2]]), x = normalize(cross(up,z)), y = cross(z,x);
    return new Float32Array([x[0],y[0],z[0],0, x[1],y[1],z[1],0, x[2],y[2],z[2],0, -dot(x,eye),-dot(y,eye),-dot(z,eye),1]);
  }
  function matMul(a,b) {
    const o = new Float32Array(16);
    for(let c=0;c<4;c++) for(let r=0;r<4;r++) o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];
    return o;
  }

  function create(canvas, initial) {
    let gl=null,pendingFrameId=0;
    const owned={shaders:new Set(),programs:new Set(),buffers:new Set(),textures:new Set(),renderbuffers:new Set(),framebuffers:new Set()};
    const cleanupCallbacks=[];
    const uniformCache=new Map(),attributeCache=new Map();
    try {
    gl = canvas.getContext('webgl', { alpha: false, antialias: true, depth: true, powerPreference: 'high-performance' }) || canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL не підтримується в цьому WebView.');if(window.MeadowLog)window.MeadowLog.record('info','menu-renderer','Built-in renderer initialized',{version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(gl.RENDERER),quality:initial&&initial.quality||'medium'});
    const state = Object.assign({ time: 660/1440, autoTime: true, cameraMotion: true, birds: true, grass: true, wind: 0.62, windDirection: 'right', quality: 'medium', horrorMode:false, walkProgress:0 }, initial || {});
    state.quality=['low','medium','high'].includes(state.quality)?state.quality:'low';
    state.time=clamp(Number(state.time)||660/1440,3/24,21/24);
    let alive = true, paused = false, frameId = 0, previous = 0, lastDrawAt = 0, elapsed = 0, width=1, height=1, ratio=1, frameInterval = state.quality==='low'?1000/30:state.quality==='high'?1000/45:1000/36;
    const random = seeded(340721);
    const grassRandom = seeded(113008);

    const shader = (type, source) => {
      const compiled=gl.createShader(type);
      if(!compiled)throw new Error('Не вдалося створити WebGL shader.');
      owned.shaders.add(compiled);
      try{gl.shaderSource(compiled,source);gl.compileShader(compiled);
        if(!gl.getShaderParameter(compiled,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(compiled)||'Shader compilation failed');
        return compiled;
      }catch(err){gl.deleteShader(compiled);owned.shaders.delete(compiled);throw err;}
    };
    const program = (vs, fs) => {
      const linked=gl.createProgram();if(!linked)throw new Error('Не вдалося створити WebGL program.');
      owned.programs.add(linked);let vertex=null,fragment=null;
      try{
        vertex=shader(gl.VERTEX_SHADER,vs);fragment=shader(gl.FRAGMENT_SHADER,fs);
        gl.attachShader(linked,vertex);gl.attachShader(linked,fragment);gl.linkProgram(linked);
        if(!gl.getProgramParameter(linked,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(linked)||'Shader link failed');
        return linked;
      }catch(err){gl.deleteProgram(linked);owned.programs.delete(linked);throw err;}
      finally{if(vertex){gl.deleteShader(vertex);owned.shaders.delete(vertex);}if(fragment){gl.deleteShader(fragment);owned.shaders.delete(fragment);}}
    };
    function uniform(p,name){let cache=uniformCache.get(p);if(!cache){cache=new Map();uniformCache.set(p,cache);}if(!cache.has(name))cache.set(name,gl.getUniformLocation(p,name));return cache.get(name);}
    function attribute(p,name){let cache=attributeCache.get(p);if(!cache){cache=new Map();attributeCache.set(p,cache);}if(!cache.has(name))cache.set(name,gl.getAttribLocation(p,name));return cache.get(name);}
    const sceneProgram = program(
      'attribute vec3 aPosition; attribute vec3 aColor; uniform mat4 uMVP; uniform mat4 uShadowMVP; uniform float uNight; uniform float uDusk; uniform vec3 uCamera; varying vec3 vColor; varying float vDistance; varying vec4 vShadowCoord; void main(){ vec4 clip=uMVP*vec4(aPosition,1.0); float d=distance(aPosition,uCamera); if(clip.w<=0.0||d>380.0)clip=vec4(2.0,2.0,2.0,1.0); gl_Position=clip; vShadowCoord=uShadowMVP*vec4(aPosition,1.0); vDistance=d; vec3 lit=clamp(aColor*1.12+vec3(0.012,0.018,0.006),0.0,1.0); vec3 c=mix(lit,lit*vec3(1.0,0.81,0.62),uDusk); vec3 n=aColor*vec3(0.34,0.43,0.57)+vec3(0.014,0.025,0.044); vColor=mix(c,n,uNight*0.86); }',
      'precision mediump float; varying vec3 vColor; varying float vDistance; varying vec4 vShadowCoord; uniform float uDusk; uniform float uUseShadows; uniform float uSkipFog; uniform vec2 uShadowTexel; uniform sampler2D uShadowMap; float unpackDepth(vec4 c){return dot(c,vec4(1.0/16777216.0,1.0/65536.0,1.0/256.0,1.0));} void main(){vec3 color=vColor;if(uUseShadows>0.5&&vShadowCoord.w>0.0){vec3 sc=vShadowCoord.xyz/vShadowCoord.w*0.5+0.5;if(sc.x>0.002&&sc.x<0.998&&sc.y>0.002&&sc.y<0.998&&sc.z>0.0&&sc.z<1.0){float sum=0.0;for(int x=-1;x<=1;x++){for(int y=-1;y<=1;y++){vec2 uv=sc.xy+vec2(float(x),float(y))*uShadowTexel;float sd=unpackDepth(texture2D(uShadowMap,uv));sum+=(sc.z-0.00075>sd)?0.34:1.0;}}float shadow=sum/9.0;float goldMask=step(color.g*1.22,color.r)*step(color.b*1.9,color.g);color*=mix(1.0,shadow,0.76*(1.0-goldMask*.82));}}float haze=smoothstep(72.0,175.0,vDistance);vec3 fog=mix(vec3(0.57,0.68,0.67),vec3(0.83,0.70,0.56),uDusk);float fogAmount=haze*0.56*(1.0-uSkipFog);gl_FragColor=vec4(mix(color,fog,fogAmount),1.0); }');
    const grassProgram = program(
      'attribute vec3 aRoot; attribute vec3 aLocal; attribute vec3 aColor; uniform mat4 uMVP; uniform mat4 uShadowMVP; uniform float uTime; uniform float uWind; uniform vec2 uDirection; uniform vec3 uCamera; varying vec3 vColor; varying float vHeight; varying float vDistance; varying vec4 vShadowCoord; void main(){ float h=aLocal.y; float seed=fract(sin(dot(aRoot.xz,vec2(12.9898,78.233)))*43758.5453); float phase=aRoot.x*0.73+aRoot.z*0.51+uTime*(1.1+uWind*0.8); float gust=0.5+0.5*sin(uTime*0.68+aRoot.x*0.12+aRoot.z*0.16); float pulse=max(0.0,1.0-abs(mod(uTime+1.0,16.5)-8.0)/3.6); float bend=clamp(uWind*(0.40+0.46*gust+0.78*pulse),0.0,1.0); float sway=h*bend*(0.34+0.66*gust)*(0.84+0.16*sin(phase)); float drop=sway*sway*0.40; vec3 p=vec3(aRoot.x+aLocal.x+uDirection.x*sway,aRoot.y+h-drop,aRoot.z+aLocal.z+uDirection.y*sway); vec4 clip=uMVP*vec4(p,1.0); vShadowCoord=uShadowMVP*vec4(p,1.0); vDistance=distance(p,uCamera); if(vDistance>54.0 || clip.w<=0.0) clip=vec4(2.0,2.0,2.0,1.0); gl_Position=clip; float angle=seed*6.2831853; vec3 n=normalize(vec3(cos(angle)*0.62,0.47,sin(angle)*0.62)); vec3 sun=normalize(vec3(-0.46,0.82,0.34)); float ndl=max(dot(n,sun),0.0);float backlight=max(dot(-n,sun),0.0);vColor=aColor*(0.48+0.78*ndl+0.22*backlight); vHeight=h; }',
      'precision mediump float; varying vec3 vColor; varying float vHeight; varying float vDistance; varying vec4 vShadowCoord; uniform float uUseShadows; uniform vec2 uShadowTexel; uniform sampler2D uShadowMap; float unpackGrassDepth(vec4 c){return dot(c,vec4(1.0/16777216.0,1.0/65536.0,1.0/256.0,1.0));} float shadowGrassTap(vec2 uv,float z){float d=unpackGrassDepth(texture2D(uShadowMap,uv));return z-0.00055>d?0.40:1.0;} void main(){float fade=smoothstep(19.0,40.0,vDistance);vec3 groundTone=vec3(0.15,0.285,0.078);vec3 c=mix(vColor*(0.92+0.22*vHeight),groundTone,fade*0.96);if(uUseShadows>0.5&&vShadowCoord.w>0.0){vec3 sc=vShadowCoord.xyz/vShadowCoord.w*0.5+0.5;if(sc.x>0.002&&sc.x<0.998&&sc.y>0.002&&sc.y<0.998&&sc.z>0.0&&sc.z<1.0){float soft=(shadowGrassTap(sc.xy+uShadowTexel*vec2(-.5,-.5),sc.z)+shadowGrassTap(sc.xy+uShadowTexel*vec2(.5,-.5),sc.z)+shadowGrassTap(sc.xy+uShadowTexel*vec2(-.5,.5),sc.z)+shadowGrassTap(sc.xy+uShadowTexel*vec2(.5,.5),sc.z))*.25;c*=mix(1.0,soft,.68);}}gl_FragColor=vec4(c,1.0); }');
    const skyProgram = program(
      'attribute vec2 aClip; varying vec2 vUv; void main(){ vUv=aClip*0.5+0.5; gl_Position=vec4(aClip,0.999,1.0); }',
      'precision mediump float; varying vec2 vUv; uniform vec3 uTop; uniform vec3 uHorizon; uniform float uDusk; uniform float uNight; void main(){ float t=smoothstep(0.02,0.98,vUv.y); vec3 c=mix(uHorizon,uTop,t); vec3 warm=mix(c,vec3(0.91,0.43,0.28),0.40+0.25*(1.0-t)); c=mix(c,warm,uDusk); c=mix(c,vec3(0.035,0.07,0.14),uNight); gl_FragColor=vec4(c,1.0); }');
    const shadowPrecision=(gl.getShaderPrecisionFormat&&gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER,gl.HIGH_FLOAT).precision>0)?'highp':'mediump';
    const shadowProgram=program(
      'attribute vec3 aPosition; uniform mat4 uShadowMVP; void main(){gl_Position=uShadowMVP*vec4(aPosition,1.0);}',
      'precision '+shadowPrecision+' float; vec4 packDepth(float d){if(d>=0.99999)return vec4(1.0);vec4 shift=vec4(16777216.0,65536.0,256.0,1.0);vec4 mask=vec4(0.0,1.0/256.0,1.0/256.0,1.0/256.0);vec4 c=fract(d*shift);c-=c.xxyz*mask;return c;} void main(){gl_FragColor=packDepth(gl_FragCoord.z);}');
    function deleteShadowTarget(target){if(!target)return;[[gl.deleteFramebuffer,target.framebuffer,owned.framebuffers],[gl.deleteTexture,target.texture,owned.textures],[gl.deleteRenderbuffer,target.depth,owned.renderbuffers]].forEach(([remove,handle,set])=>{if(handle)try{remove.call(gl,handle);}catch(_e){}set.delete(handle);});}
    function makeShadowTarget(size){
      let texture=null,depth=null,framebuffer=null;
      try{
        texture=gl.createTexture();if(!texture)throw new Error('Не вдалося створити текстуру карти тіней.');owned.textures.add(texture);
        depth=gl.createRenderbuffer();if(!depth)throw new Error('Не вдалося створити буфер глибини карти тіней.');owned.renderbuffers.add(depth);
        framebuffer=gl.createFramebuffer();if(!framebuffer)throw new Error('Не вдалося створити framebuffer карти тіней.');owned.framebuffers.add(framebuffer);
        gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,size,size,0,gl.RGBA,gl.UNSIGNED_BYTE,null);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
        gl.bindRenderbuffer(gl.RENDERBUFFER,depth);gl.renderbufferStorage(gl.RENDERBUFFER,gl.DEPTH_COMPONENT16,size,size);gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);const complete=gl.checkFramebufferStatus(gl.FRAMEBUFFER)===gl.FRAMEBUFFER_COMPLETE;gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindTexture(gl.TEXTURE_2D,null);return {texture,depth,framebuffer,size,complete};
      }catch(err){try{gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindTexture(gl.TEXTURE_2D,null);}catch(_e){}deleteShadowTarget({texture,depth,framebuffer});throw err;}
    }
    let shadowTarget=makeShadowTarget(state.quality==='low'?256:state.quality==='high'?768:512);
    function resizeShadowTarget(size){if(shadowTarget&&shadowTarget.size===size)return;const next=makeShadowTarget(size),previous=shadowTarget;shadowTarget=next;deleteShadowTarget(previous);}

    function makeBuffer(data, usage) { const b=gl.createBuffer();if(!b)throw new Error('Не вдалося створити WebGL buffer.');owned.buffers.add(b);try{gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,data,usage||gl.STATIC_DRAW);return b;}catch(err){gl.deleteBuffer(b);owned.buffers.delete(b);throw err;} }
    function bindAttrs(p, specs) {
      specs.forEach(a=>{ const loc=attribute(p,a.name); if(loc<0)return; gl.bindBuffer(gl.ARRAY_BUFFER,a.buffer); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc,a.size,gl.FLOAT,false,0,0); });
    }
    const solidVerts=[],shadowVerts=[];let collectShadowGeometry=true;
    function vertex(p,c) { solidVerts.push(p[0],p[1],p[2],c[0],c[1],c[2]);if(collectShadowGeometry)shadowVerts.push(p[0],p[1],p[2]); }
    function triangle(a,b,c,color) { vertex(a,color);vertex(b,color);vertex(c,color); }
    function quad(a,b,c,d,color,alternate) { triangle(a,b,c,color);triangle(a,c,d,alternate||color); }
    function box(cx,cy,cz,sx,sy,sz,color) {
      const x0=cx-sx/2,x1=cx+sx/2,y0=cy-sy/2,y1=cy+sy/2,z0=cz-sz/2,z1=cz+sz/2;
      const p=[[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]];
      const shades=[color,mix(color,[0.18,0.2,0.15],0.16),mix(color,[0.12,0.16,0.13],0.3),mix(color,[1,1,1],0.12),mix(color,[0.23,0.24,0.17],0.16),color];
      [[0,1,2,3],[5,4,7,6],[4,0,3,7],[1,5,6,2],[3,2,6,7],[4,5,1,0]].forEach((f,i)=>quad(p[f[0]],p[f[1]],p[f[2]],p[f[3]],shades[i]));
    }
    function sphereTo(add, cx,cy,cz,rx,ry,rz,color,steps=8,rings=6) {
      for(let r=0;r<rings;r++){ const p0=-Math.PI/2+Math.PI*r/rings,p1=-Math.PI/2+Math.PI*(r+1)/rings;
        for(let s=0;s<steps;s++){const t0=TAU*s/steps,t1=TAU*(s+1)/steps;
          const p=(phi,t)=>[cx+rx*Math.cos(phi)*Math.cos(t),cy+ry*Math.sin(phi),cz+rz*Math.cos(phi)*Math.sin(t)];
          const a=p(p0,t0),b=p(p0,t1),c=p(p1,t1),d=p(p1,t0);
          const center=[(a[0]+b[0]+c[0]+d[0])*.25,(a[1]+b[1]+c[1]+d[1])*.25,(a[2]+b[2]+c[2]+d[2])*.25];
          const normal=normalize([(center[0]-cx)/(rx||1),(center[1]-cy)/(ry||1),(center[2]-cz)/(rz||1)]),lightDir=[-.43,.84,.32];
          const diffuse=.64+.48*Math.max(0,dot(normal,lightDir)),lit=color.map(v=>clamp(v*diffuse,0,1));
          add(a,b,c,lit);add(a,c,d,mix(lit,[1,1,1],0.035));
        }
      }
    }
    function cylinder(x,z,y0,y1,r0,r1,color,steps=8) {
      for(let i=0;i<steps;i++){const a=TAU*i/steps,b=TAU*(i+1)/steps;const p0=[x+Math.cos(a)*r0,y0,z+Math.sin(a)*r0],p1=[x+Math.cos(b)*r0,y0,z+Math.sin(b)*r0],p2=[x+Math.cos(b)*r1,y1,z+Math.sin(b)*r1],p3=[x+Math.cos(a)*r1,y1,z+Math.sin(a)*r1];const c=mix(color,[0.12,0.08,0.04],0.12);quad(p0,p1,p2,p3,c,mix(c,[1,1,1],0.07));triangle([x,y1,z],p3,p2,mix(color,[1,1,1],0.09));}
    }
    function terrainY(x,z) { return 0.06+Math.sin(x*0.125+1.2)*0.56+Math.sin(z*0.14)*0.48+Math.sin((x+z)*0.09)*0.27+Math.sin(x*0.73+z*0.41)*0.075+Math.cos(z*0.59-x*0.31)*0.055+Math.sin(x*1.9+z*1.35)*0.035+Math.sin(x*3.7-z*2.9)*0.018; }
    function buildTerrain() {
      const terrainDetail=state.quality==='low'?48:state.quality==='high'?156:118;const countX=terrainDetail,countZ=Math.round(terrainDetail*1.025),xMin=-70,xMax=70,zMin=-125,zMax=18;
      const grid=[];
      for(let iz=0;iz<=countZ;iz++){const row=[];const z=zMin+(zMax-zMin)*iz/countZ;for(let ix=0;ix<=countX;ix++){const x=xMin+(xMax-xMin)*ix/countX;row.push([x,terrainY(x,z),z]);}grid.push(row);}
      for(let iz=0;iz<countZ;iz++)for(let ix=0;ix<countX;ix++){
        const a=grid[iz][ix],b=grid[iz][ix+1],c=grid[iz+1][ix+1],d=grid[iz+1][ix],z=(a[2]+b[2]+c[2]+d[2])*.25;
        const shade=clamp((a[1]+.65)*.60,0,.7),field=1-smooth(-22,-14,z),noise=(random()-.5)*.10;
        const relief=clamp((Math.abs(a[1]-c[1])+Math.abs(b[1]-d[1]))*.30,0,.34);
        const green=[.24+shade*.12+noise,.43+shade*.17+noise,.13+shade*.065+noise],gold=[.64+shade*.065+noise,.44+shade*.085+noise,.075+noise*.45];
        let col=[green[0]*(1-field)+gold[0]*field,green[1]*(1-field)+gold[1]*field,green[2]*(1-field)+gold[2]*field];
        // Cheap but stable directional diffuse lighting for the offline renderer.
        const dx=(terrainY(a[0]+.3,a[2])-terrainY(a[0]-.3,a[2]))/.6,dz=(terrainY(a[0],a[2]+.3)-terrainY(a[0],a[2]-.3))/.6;
        const nl=normalize([-dx,1,-dz]),sun=clamp(nl[0]*-.56+nl[1]*.73+nl[2]*.53,0,1),light=.68+.55*sun;
        col=col.map(v=>clamp(v*light,0,1));
        col=mix(col,[.12,.09,.045],relief*.30);
        quad(a,b,c,d,col,mix(col,[.10,.19,.08],.11));
      }
    }
    function buildDistantRidges(){
      for(const spec of [{z:-103,base:-2.1,h:8.2,phase:1.3,color:[.39,.55,.41]},{z:-117,base:-1.4,h:10.5,phase:3.1,color:[.47,.61,.49]}]){
        const segments=state.quality==='low'?120:170;for(let i=0;i<segments;i++){const x0=-82+164*i/segments,x1=-82+164*(i+1)/segments;const y0=spec.base+spec.h*(.45+.32*Math.sin(x0*.075+spec.phase)+.12*Math.sin(x0*.21+spec.phase*1.7)),y1=spec.base+spec.h*(.45+.32*Math.sin(x1*.075+spec.phase)+.12*Math.sin(x1*.21+spec.phase*1.7));const c=mix(spec.color,[.7,.75,.55],.08);triangle([x0,y0,spec.z],[x1,y1,spec.z],[x1,spec.base-5,spec.z],c);triangle([x0,y0,spec.z],[x1,spec.base-5,spec.z],[x0,spec.base-5,spec.z],mix(c,[.13,.22,.16],.12));}
      }
    }
    function addSoftTreeShadow(x,z,scale){
      // Baked, directional contact shadow for the fallback; exclude it from the true depth pass.
      const previousShadowCollection=collectShadowGeometry;collectShadowGeometry=false;
      const cx=x+1.05*scale,cz=z+1.25*scale;
      const layers=[{r:.22,c:[.035,.060,.025]},{r:.42,c:[.045,.080,.030]},{r:.68,c:[.060,.105,.038]},{r:.98,c:[.082,.135,.050]},{r:1.34,c:[.11,.16,.065]},{r:1.72,c:[.15,.20,.085]}],segments=state.quality==='low'?16:32;
      let previous=0;
      for(const layer of layers){for(let i=0;i<segments;i++){const a0=TAU*i/segments,a1=TAU*(i+1)/segments;
        const pt=(a,r)=>{const sx=Math.cos(a)*r*scale*1.75,sz=Math.sin(a)*r*scale*.82;return [cx+sx,terrainY(cx+sx,cz+sz)+.055,cz+sz];};
        const p0=pt(a0,layer.r),p1=pt(a1,layer.r);if(previous===0){triangle([cx,terrainY(cx,cz)+.055,cz],p0,p1,layer.c);}else{const q0=pt(a0,previous),q1=pt(a1,previous);quad(q0,p0,p1,q1,layer.c,mix(layer.c,[.17,.27,.12],.10));}}
        previous=layer.r;}
      collectShadowGeometry=previousShadowCollection;
    }
    function buildTree(x,z,scale,variant) {
      const shape=variant%6,y=terrainY(x,z),trunk=[0.30,0.19,0.10];
      if(!shadowTarget.complete)addSoftTreeShadow(x,z,scale);
      const trunkHeight=(shape===2?3.12:shape===3?2.62:2.85)*scale;
      cylinder(x,z,y,y+trunkHeight,scale*(shape===1?.18:.205),scale*.09,trunk,9);
      const palettes=[
        [[.19,.42,.22],[.27,.49,.25],[.35,.55,.29],[.42,.60,.32]],
        [[.18,.39,.20],[.24,.46,.23],[.30,.52,.28],[.40,.58,.31]],
        [[.13,.34,.19],[.19,.42,.23],[.27,.49,.27],[.33,.53,.29]],
        [[.25,.43,.19],[.33,.51,.23],[.41,.58,.27],[.48,.62,.31]],
        [[.20,.36,.24],[.28,.46,.30],[.36,.54,.33],[.43,.60,.36]],
        [[.27,.39,.16],[.36,.49,.20],[.45,.57,.23],[.54,.63,.29]]
      ];
      const crowns=[
        [[0,2.95,1,0],[-.50,2.75,.72,.12],[.48,2.88,.78,-.10],[-.23,3.35,.71,-.25],[.30,3.48,.65,.22],[0,3.84,.58,.02],[-.72,3.08,.48,-.08],[.70,3.16,.48,.10],[-.18,2.55,.58,.32]],
        [[0,2.74,1.08,0],[-.62,2.63,.76,.15],[.58,2.83,.80,-.14],[-.28,3.15,.76,-.28],[.36,3.19,.68,.24],[.04,3.55,.61,.05],[-.82,2.98,.45,-.08],[.78,3.02,.50,.12]],
        [[0,3.24,.82,0],[-.40,2.85,.62,.12],[.41,2.96,.64,-.12],[-.22,3.55,.58,-.23],[.23,3.72,.53,.18],[0,4.12,.48,.02],[-.58,3.35,.42,-.08],[.56,3.42,.42,.11]],
        [[-.08,2.82,1.02,0],[-.66,3.02,.67,.18],[.52,2.69,.76,-.15],[-.34,3.45,.62,-.28],[.38,3.18,.77,.27],[.08,3.90,.52,.02],[-.78,2.68,.44,-.11],[.72,3.34,.55,.16],[-.18,2.43,.59,.33]],
        [[0,2.65,1.02,0],[-.42,2.72,.88,.18],[.45,2.85,.83,-.18],[-.24,3.27,.77,-.25],[.32,3.39,.72,.25],[0,3.68,.64,.02],[-.68,3.08,.50,-.11],[.70,3.05,.48,.14]],
        [[0,2.85,.90,0],[-.55,2.62,.62,.20],[.52,2.77,.67,-.18],[-.25,3.23,.68,-.25],[.28,3.47,.55,.19],[.05,3.90,.42,.02],[-.74,2.98,.41,-.10],[.71,3.22,.40,.13]]
      ];
      const layers=crowns[shape],xStretch=shape===2?.83:shape===3?1.10:shape===5?.86:1.04,yStretch=shape===2?1.15:shape===1?.94:shape===4?.92:1.04,zStretch=shape===3?1.05:shape===5?1.18:.90;
      layers.forEach((l,i)=>{const jitter=Math.sin(x*1.71+z*.83+i*2.13)*.055,r=scale*l[2];sphereTo(triangle,x+l[0]*scale+jitter,y+l[1]*scale*yStretch,z+l[3]*scale,r*xStretch,r*(.78+(i%3)*.06)*yStretch,r*zStretch,palettes[shape][i%palettes[shape].length],state.quality==='low'?8:11,state.quality==='low'?6:8);});
    }
    buildTerrain();
    // The animated shader grass is the only blade layer; it is denser near the camera and fades into the turf.
    const underGrassBuffer=null,underGrassCount=0;
    buildDistantRidges();
    // Irregular tree distribution wraps the opening to the meadow, while preserving the road corridor.
    const treeRand=seeded(821909),treeClusters=[[-11.8,16.1],[-7.2,13.4],[8.2,15.4],[12.4,17.0],[-14.0,9.0],[14.0,9.5],[-9.6,5.1],[10.0,5.8]];let treesPlaced=0,treeTries=0;
    const treeTarget=state.quality==='low'?10:state.quality==='high'?34:24;while(treesPlaced<treeTarget&&treeTries++<6000){const cluster=treeClusters[Math.floor(treeRand()*treeClusters.length)],x=cluster[0]+(treeRand()-.5)*5.6,z=cluster[1]+(treeRand()-.5)*4.8;if(x<-20||x>20||z<1.0||z>18.2||Math.abs(x-pathCenter(z))<2.55)continue;const scale=.64+treeRand()*1.02,variant=Math.floor(treeRand()*6);buildTree(x,z,scale,variant);treesPlaced++;}
    // A continuous dirt path is baked into the static scene mesh and follows the terrain.
    for(let i=0;i<132;i++){const z1=18-i*.70,z2=z1-.70,c1=pathCenter(z1),c2=pathCenter(z2),w=.86;
      const a=[c1-w,terrainY(c1-w,z1)+.028,z1],b=[c1+w,terrainY(c1+w,z1)+.028,z1],c=[c2+w,terrainY(c2+w,z2)+.028,z2],d=[c2-w,terrainY(c2-w,z2)+.028,z2];
      const tone=i%5===0?[.34,.25,.14]:[.30,.22,.12];quad(a,b,c,d,tone);
    }
    // Golden wheat blades are one static triangle batch, not individual animated objects.
    const wheatPalette=[[.66,.47,.12],[.74,.54,.17],[.59,.40,.09],[.81,.61,.23]],wasCollectingForWheat=collectShadowGeometry;collectShadowGeometry=false;
    const wheatCount=state.quality==='low'?2300:state.quality==='high'?28000:16000;for(let i=0;i<wheatCount;i++){const x=-67+random()*134,z=-110+random()*86;if(Math.abs(x-pathCenter(z))<.95)continue;const y=terrainY(x,z)+.018,h=.42+random()*.68,lean=(random()-.5)*.27,w=.035+random()*.030,col=wheatPalette[Math.floor(random()*wheatPalette.length)];triangle([x-w,y,z],[x+w,y,z],[x+lean,y+h,z],mix(col,[1,.92,.60],.12));}
    // Wildflowers are kept in the green foreground and left out of the path.
    const flowerPalette=[[.91,.83,.63],[.79,.48,.50],[.82,.79,.93],[.92,.73,.34]];
    for(let i=0,tries=0;i<(state.quality==='low'?16:state.quality==='high'?64:40)&&tries<(state.quality==='low'?120:420);tries++){const x=-17+random()*34,z=-.2+random()*12.8;if(Math.abs(x-pathCenter(z))<.95)continue;i++;const y=terrainY(x,z),s=.72+random()*.72,col=flowerPalette[i%flowerPalette.length];cylinder(x,z,y,y+.29*s,.012*s,.006*s,[.16,.36,.17],4);for(let k=0;k<5;k++){const a=TAU*k/5;sphereTo(triangle,x+Math.cos(a)*.052*s,y+.355*s,z+Math.sin(a)*.052*s,.045*s,.026*s,.037*s,col,5,3);}sphereTo(triangle,x,y+.37*s,z,.021*s,.022*s,.021*s,[.91,.68,.28],5,3);}
    for(let i=0;i<(state.quality==='low'?38:state.quality==='high'?150:90);i++){const x=-29+random()*58,z=-4+random()*21,y=terrainY(x,z);if(Math.abs(x-pathCenter(z))<.95)continue;const r=.025+random()*.07;sphereTo(triangle,x,y+.014,z,r,.018+random()*.025,r*.8,[.28+random()*.08,.33+random()*.07,.18+random()*.05],5,3);}
    collectShadowGeometry=wasCollectingForWheat;
    const solidFloat=new Float32Array(solidVerts), solidBuffer=makeBuffer(solidFloat);
    const solidCount=solidFloat.length/6;const shadowFloat=new Float32Array(shadowVerts),shadowBuffer=makeBuffer(shadowFloat);const shadowCount=shadowFloat.length/3;

    // A single batched grass mesh: each blade is generated once and only the vertex shader moves its tip.
    let grassRoot=null,grassLocal=null,grassColor=null,grassCount=0;
    function rebuildGrass(){
      if(!state.grass){const old=[grassRoot,grassLocal,grassColor];grassRoot=grassLocal=grassColor=null;grassCount=0;old.forEach(buffer=>{if(buffer){gl.deleteBuffer(buffer);owned.buffers.delete(buffer);}});return;}
      const n=state.quality==='low'?1700:state.quality==='high'?42000:22000;
      // Three fine crossed blades per tuft; the far field is clipped/faded before it competes with the wheat horizon.
      const roots=new Float32Array(n*27),locals=new Float32Array(n*27),cols=new Float32Array(n*27),rand=seeded(113008);let vi=0,li=0,ci=0,created=0;
      const palette=[[.09,.25,.04],[.14,.32,.055],[.21,.40,.075],[.28,.47,.10],[.12,.29,.045],[.32,.49,.13],[.075,.22,.03],[.17,.35,.065]];
      while(created<n){const x=-17.5+rand()*35,z=18-Math.pow(rand(),2.0)*30;if(Math.abs(x-pathCenter(z))<1.22)continue;const y=terrainY(x,z)+.006,h=.105+Math.pow(rand(),1.35)*.205,wid=.012+rand()*.010,lean=(rand()-.5)*.045,ang=rand()*Math.PI*2,col=palette[Math.floor(rand()*palette.length)];
        const verts=[];for(let blade=0;blade<3;blade++){const a=ang+blade*Math.PI/3,px=-Math.sin(a),pz=Math.cos(a),tipX=Math.cos(a)*h*.075+lean*Math.cos(a*.7),tipZ=Math.sin(a)*h*.075+lean*Math.sin(a*.7);verts.push([-wid*px,0,-wid*pz],[wid*px,0,wid*pz],[tipX,h,tipZ]);}
        for(let j=0;j<verts.length;j++){const [lx,ly,lz]=verts[j];roots[vi++]=x;roots[vi++]=y;roots[vi++]=z;locals[li++]=lx;locals[li++]=ly;locals[li++]=lz;const tip=(j%3===2)?1.34:.68,noise=1+((j%3)-1)*.035;cols[ci++]=clamp(col[0]*tip*noise,0,1);cols[ci++]=clamp(col[1]*tip*noise,0,1);cols[ci++]=clamp(col[2]*tip*noise,0,1);}
        created++;
      }
      let nextRoot=null,nextLocal=null,nextColor=null;
      try{nextRoot=makeBuffer(roots);nextLocal=makeBuffer(locals);nextColor=makeBuffer(cols);}
      catch(err){[nextRoot,nextLocal,nextColor].forEach(buffer=>{if(buffer){gl.deleteBuffer(buffer);owned.buffers.delete(buffer);}});throw err;}
      const old=[grassRoot,grassLocal,grassColor];grassRoot=nextRoot;grassLocal=nextLocal;grassColor=nextColor;grassCount=n*9;old.forEach(buffer=>{if(buffer){gl.deleteBuffer(buffer);owned.buffers.delete(buffer);}});
    }
    rebuildGrass();

    // Dynamic sky objects are based on persistent seeds; their geometry is never re-randomized per frame.
    function sphereGeometry(rx,ry,rz,color,steps=12,rings=8) { const out=[];sphereTo((a,b,c,col)=>{[a,b,c].forEach(p=>out.push(...p,...col));},0,0,0,rx,ry,rz,color,steps,rings);return new Float32Array(out); }
    const sunGeometry=sphereGeometry(.62,.62,.62,[1,.91,.57],16,10);
    const cloudCount=state.quality==='low'?5:state.quality==='high'?28:19;const cloudDefs=Array.from({length:cloudCount},(_,i)=>{const depth=78+random()*170,z=-depth,span=depth*2.15;return {x:(random()-.5)*depth*1.55,y:20+(i%5)*5.1+random()*7.5,z,s:1.45+random()*2.15,span,speed:.055+random()*.11,parts:Array.from({length:2+Math.floor(random()*2)},(_,j)=>({x:(j-2)*.54+(random()-.5)*.42,y:(random()-.35)*.32,z:(random()-.5)*.42,s:.72+random()*.35}))};});
    const cloudGeometry=sphereGeometry(1,.46,.75,[.94,.97,.96],5,3);
    let birdsData=[];
    const birdDefs=[{x:-26,y:7.6,z:-15,speed:2.4,delay:0},{x:25,y:8.5,z:-22,speed:-2.0,delay:18}];
    const clipBuffer=makeBuffer(new Float32Array([-1,-1,1,-1,-1,1, -1,1,1,-1,1,1]));
    const dynamicBuffer=makeBuffer(new Float32Array(0),gl.DYNAMIC_DRAW);
    function addMesh(out, geom, x,y,z,sx,sy,sz) {
      for(let i=0;i<geom.length;i+=6){out.push(x+geom[i]*sx,y+geom[i+1]*sy,z+geom[i+2]*sz,geom[i+3],geom[i+4],geom[i+5]);}
    }
    function makeDynamicObjects(t,day) {
      const out=[];
      const arc=clamp((state.time-3/24)/(18/24),0,1);const sunX=-22+44*arc;const sunY=1.0+Math.sin(Math.PI*arc)*15.0;const sunZ=-98;
      const sunR=!state.horrorMode&&arc>.015&&arc<.99?1:0;
      if(sunR) addMesh(out,sunGeometry,sunX,sunY,sunZ,1,1,1);
      cloudDefs.forEach(c=>{const span=c.span,half=span*.5,windSign=state.windDirection==='left'?-1:state.windDirection==='variable'?(Math.sin(t*.19+c.x*.01)>=0?1:-1):1,x=((c.x+half+t*c.speed*(.18+state.wind*2.15)*windSign+span*2)%span)-half,depth=-c.z,aspect=(canvas.clientWidth||innerWidth)/(canvas.clientHeight||innerHeight),halfWidth=depth*(aspect<.82?.43:.84)+7;if(Math.abs(x-pathCenter(-18.0))>halfWidth)return;c.parts.forEach(p=>addMesh(out,cloudGeometry,x+p.x*c.s,c.y+p.y*c.s,c.z+p.z*c.s,c.s*p.s,c.s*p.s,c.s*p.s));});
      if(state.birds){birdDefs.forEach((b,i)=>{const cycle=(t*0.035+b.delay/60)%1;const x=b.x+b.speed*t;const wrapped=((x+30)%60+60)%60-30;if((i===0&&cycle<.7)||(i===1&&cycle>.28)){const y=b.y+Math.sin(t*2+i)*.14,z=b.z;const wing=(Math.sin(t*7+i)*.07);const c=[.12,.19,.18];const p1=[wrapped-.18,y+wing,z],p2=[wrapped,y,z-.015],p3=[wrapped+.18,y-wing,z];const p4=[wrapped,y,z+.02];out.push(...p1,...c,...p2,...c,...p3,...c,...p1,...c,...p4,...c,...p3,...c);}});}
      // Brief, occasional wind gusts lift small leaves from the nearby trees and carry them through view.
      if(state.wind>.10){const period=12.8,gust=(t%period)-3.0,dir=state.windDirection==='left'?-1:state.windDirection==='variable'?(Math.sin(t*.21)>=0?1:-1):1;
        if(gust>=0&&gust<4.7){const leafCount=state.quality==='low'?12:state.quality==='high'?28:19;for(let i=0;i<leafCount;i++){const delay=i*.046,p=(gust-delay)/(2.75+((i%3)*.28));if(p<0||p>1)continue;const side=((i%2)?1:-1),startX=(i-14.5)*.74, x=startX+dir*p*(10+state.wind*8), z=14-p*(15+state.wind*8)+Math.sin(p*15+i)*.52, y=terrainY(startX,13)+2.5+(i%5)*.39+Math.sin(p*Math.PI)*1.6, size=.065+(i%4)*.018, ang=p*8+i*.91, c=[[.72,.48,.13],[.83,.62,.20],[.45,.33,.12],[.60,.67,.31]][i%4];
          const dx=Math.cos(ang)*size,dy=Math.sin(ang)*size*.48,tipX=x+Math.cos(ang+1.1)*size*1.5,tipY=y+Math.sin(ang+1.1)*size*1.5;
          const a=[x-dx,y-dy,z],b=[tipX,tipY,z],d=[x+dx,y+dy,z],center=[x+Math.cos(ang+2.7)*size*.14,y+Math.sin(ang+2.7)*size*.14,z-.012];
          out.push(...a,...c,...b,...c,...d,...c,...a,...c,...center,...c,...d,...c);
        }} }
      return new Float32Array(out);
    }
    function paletteForTime(t) {
      const phase=clamp((t-3/24)/(18/24),0,1),dawn=smooth(0,.18,phase),dusk=smooth(.72,1,phase),night=state.horrorMode?1:0;
      const top=mix([.34,.52,.73],[.34,.72,.98],dawn);const warmTop=mix(top,[.48,.27,.34],dusk*.70);const horizon=mix([.99,.82,.61],[.91,.97,.87],dawn);const warmHorizon=mix(horizon,[.97,.43,.20],dusk);
      return {day:dawn*(1-smooth(.80,1,phase)),dusk,night,top:mix(warmTop,[.025,.045,.08],night*.92),horizon:mix(warmHorizon,[.055,.075,.11],night*.90)};
    }
    function resize(){ const q=state.quality==='low'?0.85:state.quality==='high'?Math.min(1.35,devicePixelRatio||1):Math.min(1.08,devicePixelRatio||1);ratio=q;width=canvas.clientWidth||innerWidth;height=canvas.clientHeight||innerHeight;canvas.width=Math.max(1,Math.floor(width*ratio));canvas.height=Math.max(1,Math.floor(height*ratio));gl.viewport(0,0,canvas.width,canvas.height); }
    function draw(now){ if(!alive||paused)return;try{if(now-lastDrawAt<frameInterval){frameId=requestAnimationFrame(draw);return;}lastDrawAt=now;const dt=Math.min(.04,Math.max(0,(now-previous)/1000));previous=now;elapsed+=dt;if(state.autoTime&&!state.horrorMode)state.time=Math.min(21/24,state.time+dt/1100*(18/24));
      resizeIfNeeded();const phase=paletteForTime(state.time);
      gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.disable(gl.DEPTH_TEST);gl.useProgram(skyProgram);bindAttrs(skyProgram,[{name:'aClip',size:2,buffer:clipBuffer}]);gl.uniform3fv(uniform(skyProgram,'uTop'),phase.top);gl.uniform3fv(uniform(skyProgram,'uHorizon'),phase.horizon);gl.uniform1f(uniform(skyProgram,'uDusk'),phase.dusk);gl.uniform1f(uniform(skyProgram,'uNight'),phase.night);gl.drawArrays(gl.TRIANGLES,0,6);
      gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);const walk=clamp(state.walkProgress||0,0,1),walking=walk>0.0001,eyeZ=walking?18.5-45*walk:18.5,roadX=pathCenter(eyeZ),baseX=roadX+(walking?Math.sin(elapsed*5.1)*.035:(state.cameraMotion?Math.sin(elapsed*.12)*.055:0)),stepBlend=clamp(walk*14,0,1),bob=walking?Math.sin(elapsed*5.15)*.026*stepBlend:0,eye=[baseX,terrainY(roadX,eyeZ)+1.68+bob,eyeZ],targetZ=eyeZ-36,targetX=pathCenter(targetZ),target=[targetX,terrainY(targetX,targetZ)+.42,targetZ];const mvp=matMul(matPerspective((canvas.width/canvas.height<.82?85:54)*Math.PI/180,canvas.width/canvas.height,.08,460),matLookAt(eye,target,[0,1,0]));
      // Refresh the directional depth map only after a meaningful time-of-day change; tree shadows stay coherent without a costly pass every frame.
      const useShadows=state.quality!=='low'&&shadowTarget.complete;if(useShadows&&(Math.abs(state.time-shadowLastTime)>1/360||shadowLastTime<0)){shadowMVP=makeShadowMVP(state.time);shadowLastTime=state.time;gl.bindFramebuffer(gl.FRAMEBUFFER,shadowTarget.framebuffer);gl.viewport(0,0,shadowTarget.size,shadowTarget.size);gl.clearColor(1,1,1,1);gl.clearDepth(1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(shadowProgram);bindAttrs(shadowProgram,[{name:'aPosition',size:3,buffer:shadowBuffer}]);gl.uniformMatrix4fv(uniform(shadowProgram,'uShadowMVP'),false,shadowMVP);gl.drawArrays(gl.TRIANGLES,0,shadowCount);gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(0,0,0,1);}
      gl.useProgram(sceneProgram);bindAttrs(sceneProgram,[{name:'aPosition',size:3,buffer:solidBuffer},{name:'aColor',size:3,buffer:solidBuffer,offset:3}]);
      // Packed interleaved attributes need a 24-byte stride; bind again with explicit offsets.
      const pl=attribute(sceneProgram,'aPosition'),cl=attribute(sceneProgram,'aColor');gl.bindBuffer(gl.ARRAY_BUFFER,solidBuffer);gl.enableVertexAttribArray(pl);gl.vertexAttribPointer(pl,3,gl.FLOAT,false,24,0);gl.enableVertexAttribArray(cl);gl.vertexAttribPointer(cl,3,gl.FLOAT,false,24,12);
      gl.uniformMatrix4fv(uniform(sceneProgram,'uMVP'),false,mvp);gl.uniformMatrix4fv(uniform(sceneProgram,'uShadowMVP'),false,shadowMVP);gl.uniform1f(uniform(sceneProgram,'uNight'),phase.night);gl.uniform1f(uniform(sceneProgram,'uDusk'),phase.dusk);gl.uniform3fv(uniform(sceneProgram,'uCamera'),eye);gl.uniform1f(uniform(sceneProgram,'uUseShadows'),useShadows?1:0);gl.uniform1f(uniform(sceneProgram,'uSkipFog'),0.0);gl.uniform2f(uniform(sceneProgram,'uShadowTexel'),1/shadowTarget.size,1/shadowTarget.size);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,shadowTarget.texture);gl.uniform1i(uniform(sceneProgram,'uShadowMap'),1);gl.activeTexture(gl.TEXTURE0);gl.drawArrays(gl.TRIANGLES,0,solidCount);
      if(state.grass&&underGrassCount){gl.bindBuffer(gl.ARRAY_BUFFER,underGrassBuffer);gl.vertexAttribPointer(pl,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(cl,3,gl.FLOAT,false,24,12);gl.drawArrays(gl.TRIANGLES,0,underGrassCount);}
      if(state.grass&&grassCount){gl.useProgram(grassProgram);bindAttrs(grassProgram,[{name:'aRoot',size:3,buffer:grassRoot},{name:'aLocal',size:3,buffer:grassLocal},{name:'aColor',size:3,buffer:grassColor}]);gl.uniformMatrix4fv(uniform(grassProgram,'uMVP'),false,mvp);gl.uniformMatrix4fv(uniform(grassProgram,'uShadowMVP'),false,shadowMVP);gl.uniform1f(uniform(grassProgram,'uTime'),elapsed);gl.uniform1f(uniform(grassProgram,'uWind'),state.wind);const d=state.windDirection==='left'?[-1,0]:state.windDirection==='variable'?[Math.sin(elapsed*.22),Math.cos(elapsed*.17)*.62]:[1,0];gl.uniform2fv(uniform(grassProgram,'uDirection'),d);gl.uniform3fv(uniform(grassProgram,'uCamera'),eye);gl.uniform1f(uniform(grassProgram,'uUseShadows'),useShadows?1:0);gl.uniform2f(uniform(grassProgram,'uShadowTexel'),1/shadowTarget.size,1/shadowTarget.size);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,shadowTarget.texture);gl.uniform1i(uniform(grassProgram,'uShadowMap'),1);gl.activeTexture(gl.TEXTURE0);gl.disable(gl.CULL_FACE);gl.drawArrays(gl.TRIANGLES,0,grassCount);}
      const dyn=makeDynamicObjects(elapsed,phase.day);if(dyn.length){gl.useProgram(sceneProgram);gl.bindBuffer(gl.ARRAY_BUFFER,dynamicBuffer);gl.bufferData(gl.ARRAY_BUFFER,dyn,gl.DYNAMIC_DRAW);const p=attribute(sceneProgram,'aPosition'),c=attribute(sceneProgram,'aColor');gl.enableVertexAttribArray(p);gl.vertexAttribPointer(p,3,gl.FLOAT,false,24,0);gl.enableVertexAttribArray(c);gl.vertexAttribPointer(c,3,gl.FLOAT,false,24,12);gl.uniformMatrix4fv(uniform(sceneProgram,'uMVP'),false,mvp);gl.uniformMatrix4fv(uniform(sceneProgram,'uShadowMVP'),false,shadowMVP);gl.uniform1f(uniform(sceneProgram,'uNight'),phase.night);gl.uniform1f(uniform(sceneProgram,'uDusk'),phase.dusk);gl.uniform3fv(uniform(sceneProgram,'uCamera'),eye);gl.uniform1f(uniform(sceneProgram,'uUseShadows'),0.0);gl.uniform1f(uniform(sceneProgram,'uSkipFog'),1.0);gl.drawArrays(gl.TRIANGLES,0,dyn.length/6);}
      frameId=requestAnimationFrame(draw);
      }catch(err){alive=false;paused=true;cancelAnimationFrame(frameId);frameId=0;if(window.MeadowLog)window.MeadowLog.record('error','menu-renderer','Menu animation loop failed',err);}
    }
    let shadowLastTime=-100,shadowMVP=new Float32Array(16);
    function makeShadowMVP(time){const arc=clamp((time-3/24)/(18/24),0,1),sunX=-22+44*arc,sunY=14+Math.sin(Math.PI*arc)*25,light=[sunX*1.18,sunY+30,-86],target=[pathCenter(-18),0,-18];return matMul(matOrtho(-39,39,-34,34,.1,180),matLookAt(light,target,[0,1,0]));}
    let lastSize='';function resizeIfNeeded(){const key=`${canvas.clientWidth}x${canvas.clientHeight}:${state.quality}:${devicePixelRatio||1}`;if(key!==lastSize){lastSize=key;resize();}}
    function setQuality(q){if(disposed)return;const previousQuality=state.quality,nextQuality=['low','medium','high'].includes(q)?q:'low';if(nextQuality===previousQuality)return;state.quality=nextQuality;frameInterval=state.quality==='low'?1000/30:state.quality==='high'?1000/45:1000/36;try{if(state.grass)rebuildGrass();const size=state.quality==='low'?256:state.quality==='high'?768:512;resizeShadowTarget(size);shadowLastTime=-100;lastSize='';resizeIfNeeded();if(window.MeadowLog)window.MeadowLog.record('info','menu-renderer','Quality preset changed',{quality:state.quality,frameInterval});}catch(err){state.quality=previousQuality;frameInterval=state.quality==='low'?1000/30:state.quality==='high'?1000/45:1000/36;if(state.grass)try{rebuildGrass();}catch(rollbackError){if(window.MeadowLog)window.MeadowLog.record('error','menu-renderer','Grass rollback after quality failure also failed',rollbackError);}if(window.MeadowLog)window.MeadowLog.record('error','menu-renderer','Could not apply quality preset; previous preset restored',err);}}
    function visibilityChange(){if(document.hidden){cancelAnimationFrame(frameId);}else if(!paused){previous=0;lastDrawAt=0;frameId=requestAnimationFrame(draw);}}
    resize();window.addEventListener('resize',resizeIfNeeded);cleanupCallbacks.push(()=>window.removeEventListener('resize',resizeIfNeeded));document.addEventListener('visibilitychange',visibilityChange);cleanupCallbacks.push(()=>document.removeEventListener('visibilitychange',visibilityChange));frameId=requestAnimationFrame(draw);pendingFrameId=frameId;
    if(window.MeadowLog)window.MeadowLog.record('info','menu-renderer','Menu scene buffers ready',{quality:state.quality,terrainGrid:state.quality==='low'?48:state.quality==='high'?156:118,solidTriangles:Math.round(solidCount/3),grassTriangles:Math.round(grassCount/3),grassEnabled:!!state.grass,canvasWidth:canvas.width,canvasHeight:canvas.height,devicePixelRatio:ratio,frameLimit:Math.round(1000/frameInterval)});
    let disposed=false;
    return {engine:'built-in WebGL 3D',setWalk(v){state.walkProgress=clamp(Number(v)||0,0,1);},setTime(v){state.time=clamp(Number(v)||660/1440,3/24,21/24);shadowLastTime=-100;},getTime(){return state.time;},setAuto(v){state.autoTime=!!v;},setMotion(v){state.cameraMotion=!!v;},setBirds(v){state.birds=!!v;},setGrass(v){if(disposed)return;const previousGrass=state.grass;state.grass=!!v;if(previousGrass===state.grass)return;try{rebuildGrass();if(window.MeadowLog)window.MeadowLog.record('info','menu-renderer','Grass visibility changed',{enabled:state.grass,grassTriangles:Math.round(grassCount/3)});}catch(err){state.grass=previousGrass;if(window.MeadowLog)window.MeadowLog.record('error','menu-renderer','Could not change grass; previous state restored',err);}},setWind(v){const n=Number(v);state.wind=clamp(Number.isFinite(n)?n:0,0,1.6);},setWindDirection(v){state.windDirection=['left','right','variable'].includes(v)?v:'right';},setHorror(v){state.horrorMode=!!v;},setQuality,pause(){if(disposed)return;paused=true;cancelAnimationFrame(frameId);frameId=0;},resume(){if(!alive||disposed)return;paused=false;previous=0;lastDrawAt=0;cancelAnimationFrame(frameId);frameId=requestAnimationFrame(draw);},dispose(){if(disposed)return;disposed=true;alive=false;paused=true;cancelAnimationFrame(frameId);frameId=0;document.removeEventListener('visibilitychange',visibilityChange);window.removeEventListener('resize',resizeIfNeeded);const buffers=[solidBuffer,shadowBuffer,clipBuffer,dynamicBuffer,grassRoot,grassLocal,grassColor,underGrassBuffer];buffers.forEach(buffer=>{if(buffer)gl.deleteBuffer(buffer);});const programs=[sceneProgram,grassProgram,skyProgram,shadowProgram];programs.forEach(programHandle=>{if(programHandle)gl.deleteProgram(programHandle);});if(shadowTarget){deleteShadowTarget(shadowTarget);shadowTarget=null;}uniformCache.clear();attributeCache.clear();}};
    }catch(err){
      if(pendingFrameId)try{cancelAnimationFrame(pendingFrameId);}catch(_e){}
      cleanupCallbacks.forEach(fn=>{try{fn();}catch(_e){}});
      uniformCache.clear();attributeCache.clear();
      if(gl){for(const resource of owned.buffers)try{gl.deleteBuffer(resource);}catch(_e){}for(const resource of owned.programs)try{gl.deleteProgram(resource);}catch(_e){}for(const resource of owned.shaders)try{gl.deleteShader(resource);}catch(_e){}for(const resource of owned.textures)try{gl.deleteTexture(resource);}catch(_e){}for(const resource of owned.renderbuffers)try{gl.deleteRenderbuffer(resource);}catch(_e){}for(const resource of owned.framebuffers)try{gl.deleteFramebuffer(resource);}catch(_e){}}
      try{if(window.MeadowLog)window.MeadowLog.record('error','menu-renderer','Renderer initialization failed; partial GPU resources released',err);}catch(_e){}
      throw err;
    }
  }
  window.MeadowWebGL = { create };
})();
