/* Shared Three.js loader. Offline priority: project file -> IndexedDB/localStorage -> network. */
(function () {
  'use strict';
  const DB = 'meadow-offline-v5', STORE = 'modules', KEY = 'three-r160';
  // Shared name used by CacheStorage, the service worker and the status UI.
  const SW_CACHE = 'meadow-three-r160-cache-v1';
  const LIBRARY_URLS = [
    'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js',
    'https://unpkg.com/three@0.160.0/build/three.module.js'
  ];
  const MIN_SIZE = 200000, MAX_SIZE = 8000000;
  const scriptURL = document.currentScript && document.currentScript.src ? document.currentScript.src : new URL('js/storage/offline-engine.js', document.baseURI).href;
  const LOCAL_URL = new URL('../../vendor/three/three.module.js', scriptURL).href;
  let currentLoad = null;
  let currentLoadController = null;

  const log = (level, area, message, details) => { if (window.MeadowLog) window.MeadowLog.record(level, area, message, details); };
  function abortError() { const e = new Error('Завантаження скасовано.'); e.name = 'AbortError'; return e; }
  function checkAbort(signal) { if (signal && signal.aborted) throw abortError(); }
  function timed(promise, ms, signal, label) {
    let timer, abortHandler;
    const guards = [new Promise((_, reject) => { timer = setTimeout(() => { const e = new Error((label || 'Операція') + ': перевищено час очікування (' + Math.round(ms / 1000) + ' с).'); e.code = 'TIMEOUT'; reject(e); }, ms); })];
    if (signal) guards.push(new Promise((_, reject) => { abortHandler = () => reject(abortError()); if (signal.aborted) abortHandler(); else signal.addEventListener('abort', abortHandler, { once: true }); }));
    return Promise.race([promise, ...guards]).finally(() => { clearTimeout(timer); if (signal && abortHandler) signal.removeEventListener('abort', abortHandler); });
  }
  function openDB() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) return reject(new Error('IndexedDB недоступний у цьому середовищі.'));
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('Не вдалося відкрити IndexedDB.'));
      req.onblocked = () => reject(new Error('Відкриття IndexedDB заблоковано іншою вкладкою.'));
    });
  }
  async function get(key) {
    let db = null;
    try {
      db = await openDB();
      const value = await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, 'readonly'), req = tx.objectStore(STORE).get(key);
        req.onsuccess = () => resolve(req.result || null); req.onerror = () => reject(req.error);
      });
      if (value) return value;
    } catch (e) { log('warn', 'storage', 'IndexedDB read failed; trying legacy/local storage', e); }
    finally { if (db) db.close(); }
    // Migrate the v25 cache database without asking the user to download it again.
    let legacy = null;
    try {
      const oldDB = await new Promise((resolve, reject) => { const req = indexedDB.open('meadow-offline-v4', 1); req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); req.onupgradeneeded = () => { try { req.transaction.abort(); } catch (_e) {} reject(new Error('Legacy DB does not exist')); }; });
      if (oldDB.objectStoreNames.contains(STORE)) legacy = await new Promise((resolve, reject) => { const tx = oldDB.transaction(STORE, 'readonly'), req = tx.objectStore(STORE).get(key); req.onsuccess = () => resolve(req.result || null); req.onerror = () => reject(req.error); });
      oldDB.close();
      if (legacy) { try { await put(key, legacy); log('info', 'storage', 'Migrated Three.js from v25 cache', { bytes: legacy.length }); } catch (e) { log('warn', 'storage', 'Legacy cache migration was not persisted', e); } return legacy; }
    } catch (_legacyError) { /* no previous IndexedDB is normal on first run */ }
    try { return localStorage.getItem('meadow-library-' + key) || null; }
    catch (e) { log('warn', 'storage', 'localStorage read failed', e); return null; }
  }
  async function put(key, value) {
    let db = null;
    try {
      db = await openDB();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).put(value, key);
        tx.oncomplete = resolve; tx.onerror = () => reject(tx.error || new Error('IndexedDB write failed')); tx.onabort = () => reject(tx.error || new Error('IndexedDB write aborted'));
      });
      return 'IndexedDB';
    } catch (dbError) {
      log('warn', 'storage', 'IndexedDB save failed; trying localStorage', dbError);
      try { localStorage.setItem('meadow-library-' + key, value); return 'localStorage'; }
      catch (storageError) { throw new Error('Не вдалося зберегти бібліотеку. IndexedDB: ' + (dbError.message || 'помилка') + '; localStorage: ' + (storageError.message || 'помилка') + '. Скопіюй файл у vendor/three/three.module.js.'); }
    } finally { if (db) db.close(); }
  }
  function validateSource(source) {
    if (typeof source !== 'string' || source.length < MIN_SIZE || source.length > MAX_SIZE || !source.includes('REVISION') || !source.includes('WebGLRenderer')) {
      throw new Error('Обраний файл не схожий на повний three.module.js r160. Не підходять сторінка HTML, архів ZIP чи файл іншої збірки.');
    }
    return source;
  }
  async function importSource(source, signal) {
    checkAbort(signal); validateSource(source);
    if (typeof URL.createObjectURL !== 'function') throw new Error('Blob URL не підтримується. Використай локальний шлях vendor/three/three.module.js.');
    const objectURL = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
    try { return await timed(import(objectURL), 10000, signal, 'Імпорт Three.js із кешу'); }
    catch (err) {
      if (err.name === 'AbortError' || err.code === 'TIMEOUT') throw err;
      throw new Error('WebView не зміг імпортувати файл із браузерного сховища: ' + (err.message || 'невідома помилка') + '. Спробуй фізичний файл vendor/three/three.module.js і відкриття через локальний HTTP-сервер.');
    } finally { URL.revokeObjectURL(objectURL); }
  }
  async function importLocalFile(signal) {
    checkAbort(signal);
    if (location.protocol === 'file:') { log('warn', 'three', 'Skipping project module path on file://; browser module CORS restrictions may block it', LOCAL_URL); return null; }
    log('info', 'three', 'Checking project-local Three.js file', LOCAL_URL);
    try {
      const mod = await timed(import(LOCAL_URL + '?meadow=' + Date.now()), 7000, signal, 'Локальний Three.js');
      log('info', 'three', 'Loaded Three.js from project folder', LOCAL_URL);
      return { module: mod, saved: true, storage: 'project file', cached: true, source: 'project-file' };
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      log('info', 'three', 'Project-local Three.js not available', e.message || String(e));
      return null;
    }
  }
  async function loadCached(signal) {
    const local = await importLocalFile(signal); if (local) return local.module;
    const source = await timed(get(KEY), 3200, signal, 'Читання кешу Three.js'); if (!source) return null;
    log('info', 'three', 'Found cached source; importing from browser storage', { bytes: source.length });
    try { return await importSource(source, signal); }
    catch (blobError) {
      if (blobError.name === 'AbortError') throw blobError;
      let hasSameOriginCopy = false;
      try { hasSameOriginCopy = !!('caches' in window && await (await caches.open(SW_CACHE)).match(LOCAL_URL)); } catch (_e) {}
      if (!hasSameOriginCopy || location.protocol === 'file:') throw blobError;
      log('warn', 'three', 'Blob URL import is blocked; retrying the saved module through Service Worker', blobError);
      try { return await importFromServiceWorker(signal); }
      catch (pathError) {
        throw new Error('Three.js знайдено в локальному сховищі, але цей WebView не імпортує Blob ES-модулі. Відкрий гру через HTTP/HTTPS localhost і повтори запуск. Blob: ' + (blobError.message || blobError) + '; локальний модуль: ' + (pathError.message || pathError));
      }
    }
  }
  async function storeInCacheStorage(source) {
    try {
      if (!('caches' in window) || location.protocol === 'file:') return false;
      const cache = await caches.open(SW_CACHE);
      await cache.put(LOCAL_URL, new Response(source, { headers: { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' } }));
      log('info', 'storage', 'Saved Three.js to CacheStorage for service-worker offline imports', { url: LOCAL_URL, bytes: source.length });
      return true;
    } catch (e) { log('warn', 'storage', 'CacheStorage save unavailable; using IndexedDB/localStorage', e); return false; }
  }
  async function importFromServiceWorker(signal) {
    if (!('serviceWorker' in navigator) || location.protocol === 'file:') throw new Error('Service Worker недоступний у цьому середовищі.');
    if (!navigator.serviceWorker.controller) {
      let onController;
      const controllerPromise = new Promise(resolve => {
        onController = () => resolve(true);
        navigator.serviceWorker.addEventListener('controllerchange', onController, { once: true });
      });
      try { await timed(controllerPromise, 3000, signal, 'Очікування Service Worker'); }
      finally { if (onController) navigator.serviceWorker.removeEventListener('controllerchange', onController); }
    }
    checkAbort(signal);
    return timed(import(LOCAL_URL + '?meadow-cache=' + Date.now()), 10000, signal, 'Імпорт локального модуля через Service Worker');
  }
  async function installSource(source, signal) {
    checkAbort(signal); validateSource(source);
    log('info', 'three', 'Persisting Three.js source before module import', { bytes: source.length });
    let storage = '', cacheSaved = false;
    try { storage = await timed(put(KEY, source), 4000, signal, 'Збереження Three.js'); } catch (e) { log('error', 'storage', 'Three.js could not be persisted to IndexedDB/localStorage', e); }
    try { cacheSaved = await timed(storeInCacheStorage(source), 3000, signal, 'Збереження Three.js у CacheStorage'); } catch (e) { log('warn', 'storage', 'CacheStorage write timed out or failed', e); cacheSaved = false; }
    checkAbort(signal);
    let module;
    try { module = await importSource(source, signal); }
    catch (blobError) {
      if (!cacheSaved) throw blobError;
      try {
        log('warn', 'three', 'Blob import failed; trying same-origin service-worker module URL', blobError);
        module = await importFromServiceWorker(signal);
      } catch (pathError) {
        throw new Error('Файл Three.js вже збережено, але WebView заблокував і Blob-імпорт, і локальний ES-модуль. Потрібно відкрити проєкт через HTTPS/localhost та повторити запуск. Blob: ' + (blobError.message || blobError) + '; локальний шлях: ' + (pathError.message || pathError));
      }
    }
    const persisted = !!storage || cacheSaved;
    return { module, saved: persisted, storage: [storage, cacheSaved ? 'CacheStorage' : ''].filter(Boolean).join(' + '), onlineOnly: !persisted, warning: persisted ? '' : 'Three.js працює лише до закриття сторінки: браузер не дозволив зберегти бібліотеку.' };
  }
  function readFile(file, signal) {
    return timed(new Promise((resolve, reject) => {
      if (!file) return reject(new Error('Файл не вибрано.'));
      if (file.size < MIN_SIZE || file.size > MAX_SIZE) return reject(new Error('Потрібен повний файл three.module.js розміром приблизно 0,2–8 МБ.'));
      if (typeof file.text === 'function') { file.text().then(resolve, reject); return; }
      const reader = new FileReader(); reader.onload = () => resolve(String(reader.result || '')); reader.onerror = () => reject(reader.error || new Error('Не вдалося прочитати файл.'));
      if (signal) signal.addEventListener('abort', () => { try { reader.abort(); } catch (_e) {} reject(abortError()); }, { once: true });
      reader.readAsText(file);
    }), 8000, signal, 'Читання вибраного файла Three.js');
  }
  async function importFile(file, signal) { return installSource(await readFile(file, signal), signal); }

  async function fetchSource(url, onProgress, signal) {
    checkAbort(signal);
    if (!('AbortController' in window)) throw new Error('Цей WebView не підтримує AbortController і не може безпечно скасувати мережеве завантаження.');
    const ctrl = new AbortController(), timeout = setTimeout(() => ctrl.abort(), 10000);
    const abortHandler = () => ctrl.abort(); if (signal) signal.addEventListener('abort', abortHandler, { once: true });
    try {
      log('info', 'network', 'Fetching Three.js', url);
      const response = await fetch(url, { mode: 'cors', cache: 'no-store', signal: ctrl.signal });
      if (!response.ok) throw new Error('HTTP ' + response.status + ' ' + response.statusText);
      let source;
      if (response.body && typeof response.body.getReader === 'function' && typeof TextDecoder === 'function') {
        const reader = response.body.getReader(), decoder = new TextDecoder(), parts = [], total = Number(response.headers.get('content-length')) || 0; let loaded = 0;
        while (true) { const item = await reader.read(); if (item.done) break; loaded += item.value.byteLength; parts.push(decoder.decode(item.value, { stream: true })); if (onProgress) onProgress({ phase: 'bytes', host: new URL(url).hostname, loaded, total }); checkAbort(signal); }
        parts.push(decoder.decode()); source = parts.join('');
      } else source = await response.text();
      validateSource(source); log('info', 'network', 'Three.js download completed', { host: new URL(url).hostname, bytes: source.length }); return source;
    } catch (e) {
      if ((signal && signal.aborted) || e.name === 'AbortError') { if (signal && signal.aborted) throw abortError(); const timeoutError = new Error('Сервер не відповів за 10 секунд.'); timeoutError.code = 'FETCH_TIMEOUT'; throw timeoutError; }
      throw e;
    } finally { clearTimeout(timeout); if (signal) signal.removeEventListener('abort', abortHandler); }
  }
  async function download(onProgress, options) {
    options = options || {}; const signal = options.signal, errors = [];
    for (let i = 0; i < LIBRARY_URLS.length; i++) {
      checkAbort(signal); const url = LIBRARY_URLS[i];
      if (onProgress) onProgress({ phase: 'connect', attempt: i + 1, total: LIBRARY_URLS.length, host: new URL(url).hostname });
      try {
        const source = await fetchSource(url, onProgress, signal);
        if (onProgress) onProgress({ phase: 'import', attempt: i + 1, total: LIBRARY_URLS.length });
        const result = await installSource(source, signal);
        result.source = 'network'; return result;
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        errors.push(new URL(url).hostname + ': ' + (e.message || 'помилка'));
        log('warn', 'network', 'Three.js source attempt failed', { url, error: e.message || String(e) });
      }
    }
    throw new Error('Не вдалося отримати Three.js. ' + errors.join(' | ') + '. Перевір інтернет або поклади файл у vendor/three/three.module.js.');
  }
  async function loadOnline(onProgress, options) {
    options = options || {}; const externalSignal = options.signal; checkAbort(externalSignal);
    // One shared in-flight load prevents the startup restore and chapter launch
    // from fetching/importing the same large module at the same time.
    if (currentLoad && !options.forceRetry) {
      const sharedController = currentLoadController;
      let abortShared = null;
      if (externalSignal && sharedController) {
        abortShared = () => sharedController.abort('shared-cancel');
        externalSignal.addEventListener('abort', abortShared, { once: true });
      }
      try { return await timed(currentLoad, 43000, externalSignal, 'Очікування спільного завантаження Three.js'); }
      finally { if (externalSignal && abortShared) externalSignal.removeEventListener('abort', abortShared); }
    }
    const controller = new AbortController();
    currentLoadController = controller;
    const externalAbort = () => controller.abort('external-cancel');
    if (externalSignal) externalSignal.addEventListener('abort', externalAbort, { once: true });
    const totalTimer = setTimeout(() => controller.abort('total-timeout'), 42000);
    const work = (async () => {
      try {
        log('info', 'three', 'Starting bounded Three.js load', { timeoutMs: 42000, online: navigator.onLine, origin: location.origin || 'opaque/file' });
        let cached = null;
        try {
          cached = await timed(loadCached(controller.signal), 11000, controller.signal, 'Перевірка локальної бібліотеки');
          if (cached) return { module: cached, saved: true, storage: 'project file or browser cache', cached: true, source: 'browser-cache' };
        } catch (e) {
          if (e.name === 'AbortError') throw e;
          if (e.code === 'TIMEOUT' && controller.signal.aborted) throw e;
          log('warn', 'three', 'Browser cache unavailable; trying network', e);
        }
        return await download(onProgress, { signal: controller.signal });
      } catch (e) {
        if ((externalSignal && externalSignal.aborted) || controller.signal.reason === 'shared-cancel' || controller.signal.reason === 'external-cancel') throw abortError();
        if (controller.signal.aborted) {
          const timeoutError = new Error('Не вдалося підготувати Three.js за 42 секунди. Перевір з’єднання або поклади файл у vendor/three/three.module.js.');
          timeoutError.code = 'LOAD_TIMEOUT';
          throw timeoutError;
        }
        throw e;
      } finally {
        clearTimeout(totalTimer);
        if (externalSignal) externalSignal.removeEventListener('abort', externalAbort);
      }
    })();
    currentLoad = work;
    try { return await work; } finally { if (currentLoad === work) { currentLoad = null; currentLoadController = null; } }
  }
  async function clear() {
    const errors = [];
    try { if ('caches' in window) { const keys = await caches.keys(); await Promise.all(keys.filter(k => k.toLowerCase().startsWith('meadow-')).map(k => caches.delete(k))); } } catch (_e) { errors.push('Cache API'); }
    try { localStorage.removeItem('meadow-library-' + KEY); } catch (_e) { errors.push('localStorage'); }
    for (const dbName of [DB, 'meadow-offline-v4']) { try { await new Promise((resolve, reject) => { const req = indexedDB.deleteDatabase(dbName); req.onsuccess = resolve; req.onerror = () => reject(req.error); req.onblocked = resolve; }); } catch (_e) { errors.push(dbName); } }
    return errors;
  }
  window.MeadowOffline = {
    loadCached, loadOnline, download, importFile, clear,
    hasCached: async () => {
      try { const source = await get(KEY); if (typeof source === 'string' && source.length > MIN_SIZE) return true; } catch (_e) {}
      try { return !!('caches' in window && await (await caches.open(SW_CACHE)).match(LOCAL_URL)); } catch (_e) { return false; }
    },
    libraryURL: LIBRARY_URLS[0], libraryURLs: LIBRARY_URLS.slice(), revision: '160', storage: 'IndexedDB + CacheStorage', localPath: 'vendor/three/three.module.js', cacheName: SW_CACHE
  };
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    navigator.serviceWorker.register(new URL('../../sw.js', scriptURL).href, { scope: new URL('../../', scriptURL).pathname }).then(reg => { log('info', 'offline', 'Service worker registered', { scope: reg.scope }); return reg; }).catch(err => { log('warn', 'offline', 'Service worker registration failed; browser storage remains available', err); return null; });
  } else {
    log('warn', 'offline', 'Service worker unavailable on this origin; use HTTPS/localhost for robust offline module URL caching', { protocol: location.protocol, origin: location.origin });
  }
  log('info', 'three', 'Offline loader ready', { localPath: 'vendor/three/three.module.js', cacheName: SW_CACHE, origin: location.origin || 'opaque/file origin' });
})();
