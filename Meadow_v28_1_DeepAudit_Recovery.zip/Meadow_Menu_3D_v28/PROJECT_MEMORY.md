# Meadow — Project Memory / Important Notes

This is the durable hand-off file. Read it before making future changes and append important decisions after every release.

## Current baseline

- Release label: **v13 (cache refresh 21.0.0)**. Asset cache-busting query is `21.0.0` in `index.html`.
- Target: standalone HTML/CSS/JavaScript, Android browser and HTML-to-APK WebView. No build process is required for the built-in renderer.
- Main menu is deliberately minimal: title `Meadow`, Play, Settings, Exit, and UA/EN. Do not alter the current visual design of the buttons, settings panels or the optional-library prompt unless specifically requested. Do not add slogans/captions to the menu.
- There is no house. Viewpoint is approximately 1.68 units above the ground, looking through an open winding path from a compact, irregular forest edge into green meadow, far golden wheat and distant rolling hills.
- Current scene uses two renderers: `js/engine/webgl-world.js` is bundled and works without downloads; `js/scene/three-world.js` runs only when the optional Three.js r160 module has been imported.

## Scene invariants

- Trees must form irregular groups around the beginning of the path (z about 6–29), with varied depth; no tree rows along the road and no trunks inside a generous center-path clearance. Keep a wide clear center path.
- Clouds must occupy a wide sky band, sit high and far back (roughly y 80–101 and z -228 to -266), and must not feel close to the camera during the short chapter walk.
- No house in the current menu landscape. Foreground green grass must visibly differ from the distant gold wheat field.
- Grass counts for the animated GPU layer: Low 45,000, Balanced 100,000, High 175,000. There is an additional static 100,000-blade underlayer to keep grass visible on WebViews where shader rendering is unreliable. Grass is decorative background geometry only. It must be placed once with fixed seeds, never re-randomized every frame, and must not block the road. Roots are raised about 0.48 units above terrain to avoid being hidden by the coarser ground mesh.
- Wind slider range is 0–160%; `windDirection` is `left`, `right`, or `variable`. Both renderers must apply it to the grass. Short leaf gusts recur approximately every 12.8 seconds while wind is enabled, lift leaves and carry them across view for a few seconds.
- Lighting: Three.js uses a directional sun, fill light, hemisphere light, tone mapping and shadow maps. Built-in WebGL cannot use Three.js shadow maps; it uses brighter material palettes, baked directional terrain shading, and layered contact-shadow geometry instead. Keep the left-side CSS vignette/grain extremely subtle.
- Clouds, tree positions and grass layout use seeded randomness. Avoid per-frame allocations or geometry regeneration.

## Time, horror and chapters

- Slider is restricted to 03:00–21:00. Stored `time` is a fraction of a 24-hour day. Automatic time stops at 21:00.
- `window.MeadowHorror.begin()` / `end()` and `setActive(true/false)` control the horror-preview state, darken the scene and hide/show the time slider.
- This project is still a menu/world preview, not the playable story. The Chapters panel currently contains one entry, “Книга / The Book”. Its button triggers a walking-and-fade presentation. If no chapter scene calls `window.MeadowChapterReady()` within 15 seconds, a warning appears and the camera returns to the start beneath a fade. Do not write gameplay/story scenes unless separately requested.
- Keep forward walk linear and constant-speed along `pathCenter(z)`, eye height around 1.68, subtle step bob only; never apply double easing or accelerate toward the horizon.

## Optional library and storage

- Startup prompt asks whether to download additional offline files. “Not now” closes it immediately and uses the bundled WebGL renderer. “Download” is handled only by `js/ui/menu.js`; do not add a capture-phase handler for that button to the inline script in `index.html`.
- `js/storage/offline-engine.js` downloads pinned Three.js r160 from jsDelivr then unpkg, attempts both fetch/Blob-module install and direct HTTPS module import, and caches the source in IndexedDB (`meadow-offline-v4`, key `three-r160`). On slow mobile networks a fetch can take up to 60 seconds per mirror.
- If automatic install fails, Settings must show the error and expose a direct link plus `.js` file picker. Never silently replace the built-in renderer with a blank canvas if external loading fails.
- `meadow-settings-v21` and `meadow-startup-choice-v21` intentionally provide fresh settings for the current release, so grass defaults to enabled instead of inheriting a stale disabled grass toggle.
- Asset query key currently `21.0.0`. Increment it after future resource changes. Reset Cache removes page-owned Cache API, IndexedDB module storage, and legacy preference keys, then reloads with a timestamp query. It cannot clear every APK-wrapper cache; if necessary the project must be re-imported and the APK rebuilt.

## Audio and controls

- Local background music: `assets/audio/meadow-theme.mp3`, loaded by `js/audio/music.js`. Browser autoplay may be blocked until a user gesture.
- `window.MeadowMusic` exposes `play`, `pause`, `stop`, `setEnabled(boolean)` and `setVolume(0..1)`.
- Shared renderer controls: time, auto time, camera motion, birds, grass, wind strength/direction, quality, horror, `setWalk(progress)`, `dispose()`.

## Folder responsibilities

- `index.html`: menu/settings/dialog markup and versioned script/style URLs.
- `css/style.css`: presentation and responsive layout.
- `js/engine/webgl-world.js`: bundled no-download WebGL renderer.
- `js/scene/three-world.js`: optional Three.js scene.
- `js/storage/offline-engine.js`: CDN attempts, local file import, IndexedDB cache and reset.
- `js/audio/music.js`: soundtrack player.
- `js/ui/menu.js`: UI event handlers, settings and chapter preview.
- `assets/`: sound, model/texture placeholders.
- `data/levels/levels.json`: chapter metadata.
- `docs/`: architecture/testing notes.

## v13 release notes (2026-10-29)

- Fixed the incorrect leaf-tip y coordinate in built-in rendering (`tipY` is already absolute and must not have `y` added again).
- Increased static grass to 100,000 crossed blade tufts and weighted placement toward the near foreground; the animated quality layer stays 45k/100k/175k. Roots are offset above terrain to prevent depth occlusion. New preference namespace ensures grass is enabled by default.
- Trees are limited to 10 irregularly spread trunks in clustered edge groups beside the start, with additional clearance from the path; no tree placement occurs along the far road.
- Clouds span a wide x range, sit at y 80–101 and z -228 to -266, and have fog disabled in the Three.js material. Wind gust leaves are more prominent. Lighting, sky color and left overlay are brighter/less grey.
- Download attempts both CDN mirrors for up to 180 seconds per host, displays which mirror is being tried, and opens Settings after errors to make the direct link/manual importer easy to find.
- Headless Chromium could not initialize its WebGL graphics context in the work environment. Do not claim final visual verification without testing the exported project in Android WebView.


## Latest adjustment notes

- Asset query is now `21.0.0` and preference keys use v21 so Android browsers refresh the renderer and do not inherit stale grass preferences. The inline fail-safe must never intercept the `installEngine` button.
- CDN installation tries jsDelivr and unpkg; Settings offers both manual links plus the local file picker. If fetch and module import are blocked by the WebView, state the failure instead of leaving an indefinite silent dialog.
- Tree-cluster z positions are randomized with a real spread; never clamp every trunk to the same z value. Keep the road clear. Clouds use a farther fog range and a larger camera far plane.
- Grass has a raised, broader static underlayer as a compatibility fallback and an independently animated quality layer.


## v13 adjustments (2026-10-29)

- Updated asset query and preference namespace again so a locally cached v12 render cannot keep the old tree line or hide the grass toggle.
- Corrected tree depth distribution: groups use a meaningful z spread and stay near the opening, while a wide safe corridor remains clear.
- Clouds are high and far, with fog disabled on their material in Three.js, the far plane extended, and fewer, broader billows to reduce per-frame work in the built-in engine.
- Raised and widened both grass layers and increased green contrast to make the grass visually read as blades rather than a smooth lawn.
- Library installation now opens Settings while downloading so progress remains visible. Added a second manual CDN link; direct module import timeout is longer for slow connections. The inline capture-phase fail-safe must only handle Not now / close, never the actual Download button.

- A duplicate `let saved = false` declaration in `offline-engine.js` caused the optional library loader script to fail parsing; it is removed. Do not reintroduce duplicate lexical declarations. The Download action now opens Settings during transfer, making progress visible instead of leaving the user on the menu with a transient toast.


## v14 scale correction (2026-10-29)
- The previous grass was accidentally oversized: blades were 1.55–3.1 m tall and rooted 0.48 m above the ground, which made the camera/player feel like a tiny person. Both renderers now use realistic 0.26–0.60 m grass and roots only 0.025 m above terrain; blade width is about 0.02–0.044 m.
- Wind-blown leaves were too large (built-in renderer used ~0.32–0.55 m size and Three.js instances were over-scaled). Reduced to natural small leaves, about 8–15 cm long.
- Trees were too few and spread along the road. Replaced with 26 varied trees in irregular close clusters around the entrance (z≈7–18), leaving the central path open and the far field clear.
- Widened the path from about 1.04 m to 1.72 m so it reads as a walkable footpath.
- Cache-busting version advanced to 22.0.0 and preference keys v22.


## Meadow v15 — render/lighting correction
- The core visual bug: Three.js grass BufferGeometry used only custom attributes (`aRoot`, `aLocal`, `aColor`) without the standard `position` attribute. Three.js determines non-indexed draw counts from `position`, so grass could silently draw zero vertices. v15 includes `position` and splits grass into 30 spatial chunks with frustum culling.
- Removed the duplicate static grass layer so the moving, lit grass is the authoritative layer. Grass has thin crossed blades, non-uniform orientations, higher density near the camera, more visible wind sway, and a distance fade toward terrain color.
- Three.js uses tighter directional shadow bounds, 2048 shadow map, softer ambient fill, higher-contrast warm daylight, PBR ground/path/wheat, fog/depth separation, and true cast/receive shadows for trees and terrain.
- Built-in WebGL remains standalone/offline. It now has directional per-vertex grass lighting, distance fading and far/behind-camera vertex clipping, irregular 30-tree distribution, scattered cloud layers across different altitudes/depths, improved stylized directional tree shadows and distance fog.
- Clouds are distributed across more of the sky and at varied heights/depths rather than a single horizontal band.
- Keep the chapter loading fade and 15-second reset warning. Do not show implementation narration in normal gameplay; technical details belong in this memory/doc file.
- Current version: v15. Asset query parameter should be bumped when scripts change.

- v15.1 refinement: grass blades narrowed to about 5.5–14 mm, with more density concentrated close to the camera, randomized crossed-plane directions, tip highlights, lighting response, and a gradual blend into the ground in the distance. Correct Three.js draw geometry includes `position`; grass meshes are chunked for frustum culling.
- Tree leaf clumps now use `InstancedMesh` batches by leaf color to reduce draw calls and still cast/receive sunlight shadows. Cloud layers use depth-correlated altitude and spread across different sky angles, not a same-height band.
- Built-in renderer now fades grass into terrain, drops geometry beyond the near-view radius in the vertex shader, and applies a soft distant haze. Normal game flow does not toast implementation choices; chapter transition fade remains. Cache/asset version is v24.


## Meadow v15 graphics pass (2026-10-29)
- Kept the existing title/menu/settings/chapter fade UI. Removed optional explanatory paragraph from startup prompt, chapter sublabel, and small descriptive text under settings controls; essential status messages remain.
- Three.js grass now uses `MeshStandardMaterial` with a small `onBeforeCompile` patch for GPU wind and distance fade. That lets the regular physically based lighting/shadow system shade grass and lets it receive shadows from trees. The earlier custom unlit `ShaderMaterial` did not participate in normal PBR shading.
- Fixed the previous Three.js grass geometry's missing standard `position` attribute in v14/v15; geometry draw count depends on it. Each grass patch is frustum-culled. Grass is denser closer to the camera, has ~24–63 cm blades and ~0.9–2.4 cm width, with roots close to terrain. Terrain grid resolution increased to better align grass roots with the height field.
- Three.js sun direction is now aligned with its visible sun disc, and shadow camera bounds are tighter for stronger/sharper shadows. Ground/path/wheat use physically lit materials.
- Wheat is split into spatial cells, and foliage instances are bucketed by color and spatial cell so off-camera cells can be frustum-culled. Clouds use a wider, higher, multi-depth layout and are culled by Three.js; built-in WebGL skips cloud batches outside its approximate horizontal view and discards distant/behind-camera vertices.
- Built-in renderer remains an offline fallback with vertex-lit terrain, baked contact shadows, and a packed-depth directional shadow map when its framebuffer is supported; it falls back to baked contact shadows if that framebuffer is unavailable. The optional Three.js renderer uses PBR materials and standard directional shadow maps.
- Quality grass settings remain 45,000 / 100,000 / 175,000 blades. Grass positions and variation are generated once per quality change, while only vertex deformation changes each frame.
- Asset/cache revision for this pass is `25.0.0`; active settings keys are v25. Clearing cache removes v25 keys too.


## Meadow v16 visual refinement (2026-10-29)
- Grass silhouette changed from two large, thin triangles to three crossed tapered blade triangles per tuft. Each tuft has a standard `position` attribute, PBR material in Three.js, GPU wind deformation, and distance fade into the ground. Use 45k / 100k / 175k tufts by quality.
- Trees are clustered at the woodland entrance (z≈0.8..18) and leave the road corridor open. Sky cloud positions are sampled across horizontal and vertical viewing angles (not random x within a flat band), with 48 groups at varying depths and heights.
- Three.js ground uses a subtle bump texture; soft shadow map covers a larger region around the scene; ambient hemisphere and sun exposure are tuned for a warmer natural daylight.
- Built-in WebGL remains independent of download and now uses the same three-leaf tuft silhouette plus its packed-depth shadow map.
- Keep the chapter fade and 15-second timeout reset. Keep technical implementation notes in this file, not in normal gameplay UI. Asset/cache revision `26.0.0`; settings and startup keys v26.


## Meadow v17 visual pass (2026-10-29)
- New grass silhouettes: three crossed, tapered blades per tufty clump; height ~25–68 cm; width ~1.4–3.1 cm. Count remains 45k / 100k / 175k tufts for Low / Balanced / High. Shader movement remains GPU-based. Distance fade now begins nearer so the background grass is intentionally less visible than foreground grass.
- Three.js PBR daylight: ACES tone mapping, directional sun, hemisphere fill, standard materials, bump-textured rough ground, soft shadow maps. Terrain, path, wheat, grass and instanced foliage receive shadows; tree trunk/branches/foliage cast.
- Tree placement is concentrated at the entrance (z≈0.8..18), with a clear road corridor. Clouds are 48 angularly distributed groups at varied vertical angles and depths rather than one broad horizontal row.
- The no-download renderer remains self-contained, with animated grass and a packed-depth shadow map when the framebuffer is supported.
- Chapter dark fade and 15-second timeout reset are preserved. User-facing menu remains free of implementation narration. Cache revision and settings keys now v27.


## Meadow v18 (2026-10-29)
- Important fix: the Three.js grass geometry stores nine vertices per tuft (three triangular leaf blades). The geometry loop must iterate `verts.length`, otherwise it leaves trailing uninitialized vertices and renders only two-thirds of each tuft correctly.
- Grass is 25–68cm tall with ~1.4–3.1cm base width and fades from 13 to 31 world units, keeping high detail close and letting the field blend out into natural green turf at distance. GPU wind continues to deform tip vertices.
- Trees use six jittered clusters around the initial forest opening; clouds vary by horizontal angle, vertical angle, and depth.
- Three.js uses ACES tone mapping, directional sun, hemisphere fill, rough ground bump texture, PBR materials and soft depth shadows. Shadow maps are refreshed ~once per second while time advances to balance quality and phone performance.
- Built-in WebGL remains offline-capable; it uses the same three-blade grass silhouette and a packed-depth shadow map if the framebuffer is supported.
- Chapter dark fade and 15-second reset remain intact. Cache revision `28.0.0`; active storage keys v28.


## Meadow v18 scene pass
- Grass blade half-width is now ~4.5–10 mm (full width 9–20 mm), height ~25–68 cm. Three crossed tapered triangles per tuft help it read as grass. Density settings remain 45k / 100k / 175k tufts.
- Critical Three.js vertex loop iterates `verts.length` (nine vertices per tuft). Do not change to a fixed six-vertex loop: it silently leaves geometry unfilled.
- Three.js: ACES tone mapping, physically based standard materials, bump textured ground, directional sun + hemisphere fill, soft shadow maps from tree trunks/branches/canopies onto terrain/path/wheat/grass. Shadow map refresh is throttled to roughly once per second as the day changes.
- Built-in WebGL: self-contained renderer with packed-depth shadow map, directional shading and the same three-blade grass silhouette. Shadows fall back to baked contact shadows if framebuffer setup fails.
- Trees form jittered pockets at the woodland entrance while the road remains clear. Clouds use separate horizontal and vertical viewing angles to avoid a single cluster. Scene chunks/instances use frustum culling; built-in geometry uses GPU clipping for offscreen/far vertices.
- Keep chapter fade + 15-second timeout/reset. Avoid nonessential implementation notices in the actual menu/game. Current cache/resource revision and storage keys: v29.


## Meadow v19 — 2026-10-29 lighting/vegetation pass
- Preserve the existing minimal menu and settings style. Do not add implementation/status prose to the normal game screen; keep only essential errors or loading feedback. Keep the chapter fade and 15-second timeout/reset.
- The grass should read as foreground grass, not as the wheat field: Three.js and built-in WebGL now generate grass only across x=-18..18, z=-12..18, with three crossed tapered blades per tuft, about 20–59 cm tall, wider 2.4–4.4 cm bases, a GPU wind sway, and fade to ground from ~20 to 43 world units. Quality counts remain 45k/100k/175k tufts.
- Three.js grass material uses MeshStandardMaterial for PBR diffuse lighting and receives shadows; use complete `position` attributes, and loop through every vertex of every tuft. Frustum-cull the spatially bucketed meshes.
- Clouds are stratified over horizontal viewing angles instead of being pure random clusters; they sit higher and further back. Tree clusters spread irregularly around the entrance, with the road corridor kept empty.
- Lighting: ACES tone mapping, hemisphere fill, warm directional sun, PCF soft shadow maps and scene materials with roughness. Three.js shadows refresh only when time-of-day changes enough; preserve this mobile-conscious throttle. Built-in WebGL uses a packed depth map with filtered shadow taps if its framebuffer is supported, otherwise falls back to contact shading.
- Current resource revision: `30.0.0` in index.html. LocalStorage setting/startup identifiers remain v29 intentionally so existing preferences and user's selected engine survive an update.


## Meadow v19 / resource revision 31 — foliage & light pass (2026-10-29)
- Keep the menu visual language and chapter dark fade unchanged. Do not add routine in-game toasts for successful settings changes or download progress; progress belongs in Settings, errors remain visible.
- Grass must look like foreground grass and not wheat: only green area x≈-17.5..17.5, z≈-12..18; three crossed tapered blades/tuft, roughly 19–58 cm tall and 2.8–5 cm wide, dense around the viewer and fading naturally into terrain from roughly 19 to 40 units. Quality counts 45k/100k/175k. GPU wind deformation stays. Make sure every tuft vertex has complete `position`, `aRoot`, `aLocal`, and `color` values; never loop a fixed smaller number than `verts.length`.
- Three.js grass uses MeshStandardMaterial, receives sunlight and soft shadows. `renderer.shadowMap.enabled=true`, `PCFSoftShadowMap`, and throttled shadow refresh must remain. Terrain tiles, foliage cells, grass patches are frustum-culled. Built-in WebGL stays no-dependency and uses a packed-depth shadow FBO where supported.
- Clouds are stratified across horizontal viewing angles and placed high/far (current count 72), not clumped. Trees use eight irregular near-entrance cluster anchors and keep the curved path corridor clear.
- Resource cache-buster is `31.0.0` in index.html. LocalStorage setting/startup keys intentionally remain v29, preserving user's preferences.


## Meadow v20 — grass and lighting (2026-10-29)
- User explicitly wants the current interface style preserved and does not want technical progress/success chatter in gameplay. Only essential error/loading and chapter-timeout notices remain. The level's dark transition/fade remains required.
- Grass: visible near-field, tapering crossed blades, clearly wind-bent, only on green foreground x≈-17.5..17.5/z≈-12..18, fade from 19 to 40 distance, counts 45k/100k/175k. Three.js material is MeshStandardMaterial and receives sunlight/shadow; all geometry must have `position`, `color`, `aRoot`, `aLocal` attributes populated across `verts.length`.
- Lighting: Three.js uses ACES tone mapping, hemisphere fill, warm directional sun and PCF soft shadows; shadow refresh is throttled, not every frame. Built-in WebGL has packed-depth shadow FBO where supported; baked contact shadows only as fallback if the FBO is incomplete, avoiding doubled dark blobs when true shadows work.
- Trees remain in irregular groups only around the entrance and road corridor stays free. Cloud positions are stratified across horizontal view angles, higher and farther away. Three.js uses frustum-cullable tiled ground / spatial batches for foliage, wheat, and grass. Built-in fallback batches geometry and uses hardware clip/far-distance rejection.
- Cache-buster `32.0.0`; localStorage preferences/startup choices intentionally remain v29 to preserve the user's selected engine and settings.


## Meadow v21 (2026-10-29)
- Goal: finish the menu scene, do not add story/gameplay content. Preserve the menu typography/buttons; a subtle translucent backdrop behind the menu keeps controls readable without washing out the scene.
- Horror mode is not a user setting. Trigger it only through `window.MeadowHorror.begin()` from game logic; the menu has no horror checkbox. Time controls hide when game logic activates it.
- Three.js may load online for the current session through `MeadowOffline.loadOnline()` without requiring offline storage. The explicit “Save for offline” action still downloads and caches the library. Built-in WebGL remains a fallback.
- Fixed missing `computeVertexNormals()` on the Three.js wheat batch (likely cause of black wheat).
- Grass profile is shorter and concentrated near the camera; high-frequency terrain relief added. Tree clusters are nearer and more irregular with a wider clear path. Cloud layers are spread across different sky bands and move at speed proportional to wind strength/direction.
- Quality now affects render pixel ratio, shadow-map resolution and fog/render distance as well as vegetation count. High quality can be GPU-heavy on phones; Balanced is recommended for first test.
- When changing project version, update cache-busting version in `index.html` and the localStorage preference key in `js/ui/menu.js`. Keep file structure and user-facing text minimal.


## Meadow v22 — first playable chapter (2026-10-29)
- The main menu styling and 3D meadow are preserved. Chapter I now launches a separate interactive night interior instead of the old 15-second walk preview.
- SVG room art is stored in `assets/chapters/`. Chapter flow/controls are implemented in `js/chapters/chapter-one.js`, included before `js/ui/menu.js`.
- The v22 prototype left `chapters/chapter-01/story.md` empty and used a fixed five-action break after page 5. This was superseded in v23 by the author-supplied outline, a blank 20-page book and randomized pauses after pages 4, 8 and 12.
- Room navigation supports touchscreen tabs/hotspots and keyboard (arrows/A-D, W-S, E/Enter, 1–4, Escape).
- At that v22 stage, the resource cache-buster and preference keys were v34; the later v23 chapter asset revision is `35.0.0`.


## Meadow v23 — Chapter I rebuild (2026-11-01)
- Preserve the meadow main menu and settings UI. Do not turn the old walk/loading transition into a story scene. Chapter I begins with 1.35 s of darkness, slow fade-in, seated first-person view, and the protagonist's wake-up dialogue.
- Subtitles are a visible high-contrast dialogue panel with typewriter reveal; tap once to finish the current line, tap again to advance, otherwise advance 3 seconds after typing ends.
- Use portrait-first 900×1120 SVG room artwork so the entire room fits vertically on phones. Rooms: `entry`, `closet`, `bedroom`, `kitchen`. Bedroom must be a separate room with the bed visible inside, never the entire room represented by a bed.
- Entry room design: three doors (centre exterior, left closet/hall, right kitchen), two windows flanking the exterior door, drying flowers with falling leaves on one sill, clean ashtray on the other, cross above the exit, dusty rug, calendar marked 2010, two sofas. The opening first-person hands and extinguished cigarette are non-interactive; do not add a smoking action.
- Closet: wardrobe, shoe cabinet with jacket lying on it, empty hanger above, door to bedroom. Jacket inspection has a short personal thought about coming home tired and leaving it there again.
- Bedroom: small separate room, untidy bed, two-person card table and coffee cup. Kitchen: old Soviet fridge with magnets and food, sink, oven, dish shelves, empty little table and nearly empty bowl of sweets; keep path clear.
- Only one note/task may be visible at any time. At book pages 4, 8 and 12, select one mini-task at random from the hidden pool, without repeats until pool exhaustion; do not show all activities at once.
- Keep `chapters/chapter-01/story.md` blank until the author supplies the actual fairy-tale text. Store only their supplied synopsis and beats in `story-outline.md`.
- Keep the complete room visible and do not fake a camera turn by cropping the illustration. Current 2D room art has no off-screen geometry, so the camera stays fixed; WASD / arrows switch rooms. Add camera rotation only with deeper/wider 3D room geometry.
- Cache query `35.0.0`.

## Meadow v24 — Chapter I real-time 3D rebuild (2026-11-01)
- Replace the SVG room illustration as the primary game scene with `js/chapters/chapter-3d.js`, a real Three.js perspective scene. Keep the old SVG files only as unused legacy references; do not present them as gameplay.
- Central room has a physically opened front facade with the central exit and two window openings flanking it, cross above the door, rug, side doors to hall and kitchen, drying flowers, clean ashtray, 2010 calendar and two sofas. Hall, bedroom and kitchen are separate room groups with actual door openings and object meshes.
- Use rounded / bevelled geometry, procedural wood/plaster/floor textures, room-local warm ceiling lights, flickering candle point light, shadow maps, dust particles and perspective camera. Avoid presenting text buttons as the world; raycast actual object meshes.
- The character moves freely using the mobile virtual joystick or WASD/arrow keys; a tap/click also walks toward the selected object before interaction. Door leaves animate open before room transitions. Camera rotates by touch/mouse drag, Q/R on keyboard; wheel zoom on desktop.
- Mini-task selection stays hidden and random at pages 4, 8 and 12. Do not teleport to the target room when a pause begins: player navigates using doors or room tabs. After completing the task, return to the book manually. Queue a task-object tap made during the task's introductory dialogue so the input is not lost.
- Preserve chapter opening beats, subtitles/typewriter/3-second pause, book blank until user authors `story.md`, jacket anecdote, separate bedroom, kitchen props, and chapter ending. Start objective is get up before going to the front door.
- Three.js remains sourced through the project's online/cached module loader; if it cannot load, surface the actual error rather than silently presenting the old 2D scene as the chapter.
- Cache-buster: `36.0.0`.


## v25: 3D chapter startup and mobile performance repair

- Fixed the Three.js setup path: both the menu and Chapter I now call the shared loader, which checks the cached source first and downloads/saves once when missing.
- Persistent library source uses IndexedDB (`meadow-offline-v4`, key `three-r160`) with a localStorage fallback for Android WebViews that restrict IndexedDB. The UI now distinguishes saved offline from current-session-only.
- Chapter startup displays download progress and reports WebGL2/context errors instead of leaving a blank scene.
- Chapter renderer receives the menu quality setting; Low/Balanced/High control pixel-ratio cap, frame-rate cap, antialiasing, shadows, and geometry/texture detail.
- Rooms are generated lazily: the entry room at launch, other rooms only when entered. This avoids creating and shadow-processing every room during the initial load.
- Added/strengthened small geometry detail on furniture, rug fringe, dried flowers, calendar, candle holder, coffee set, cards and kitchen props.
- Cache-busting asset version updated to 37.0.0. Static JS syntax, local script paths, scene JSON and empty story.md were checked. No real Android/WebGL device test was available in this environment.


## v25 follow-up compatibility fix
Removed the incorrect WebGL2-only rejection from `js/chapters/chapter-3d.js`. Three.js r160 still supports WebGL1 fallback (WebGL1 was removed in r163), so a valid WebGL1 context is now accepted and automatically switches Chapter I to the low performance profile (30 FPS target, DPR cap 1.0, shadows disabled). Added a WebGL context-lost listener with a visible recovery message, updated cache-busting versions to 38.0.0, and documented both compatibility paths.

Additional v25 diagnostics: `loadOnline()` now retains a failed cached-module import error and combines it with network recovery failure, rather than silently replacing it with a generic CDN message. The menu exposes the exact Three.js/cache startup error in Settings. README/offline notes recommend stable HTTP(S) or APK WebView asset origin over raw `file://` because module loading and persistent storage may be restricted there.


## v26 runtime recovery work (2026-11-02)
- Fixed menu/chapter WebGL context contention by disposing and replacing the menu canvas before chapter creation; menu is rebuilt on return/error.
- Added total load timeout, abort propagation, story fetch timeout, library download cancel, persistent logs and downloadable diagnostics.
- Added CacheStorage + service-worker module path fallback and clear guidance for HTTPS/localhost vs file://.
- Reduced low preset menu meshes and set mobile quality Low by default.
- Added `.glb`/gltf asset handoff guide and manifest example; model loader hookup remains pending user-provided files.
- Three.js `three.module.js` is intentionally not bundled; the runtime downloads it or reads the project-local `vendor/three/three.module.js` file.


## Meadow v26.2 / v26.3 stability findings (2026-11-02)

- Critical runtime root cause found in the v26 loader: `SW_CACHE` was referenced in the exported `MeadowOffline` object but had no declaration. This threw during loader initialization, before `window.MeadowOffline` existed. Declared the cache key and added a browser-like Node smoke test that verifies the loader initializes and exports `importFile`/`cacheName`.
- Cached Three.js now falls back from Blob import to the same-origin Service Worker URL if Blob import errors or times out, provided CacheStorage has the saved module and the page is served via HTTPS/localhost.
- Extended bounded operations to tolerate slower mobile devices: up to 10 seconds per CDN request, 42 seconds for total library preparation, 50 seconds for chapter startup; manual file read is bounded to 8 seconds. Chapter and shared-loader cancellation are propagated.
- Reduced Low menu profile on coarse-pointer devices (terrain grid 48, 10 trees, 2,300 wheat blades, 1,700 grass tufts, 5 clouds, smaller foreground and hill details), added a renderer stats log. Chapter Low DPR is capped at 0.8. Medium/High remain more detailed.
- Cache/query version is 41.0.0.
- `vendor/three/three.module.js` is intentionally not bundled because CDN retrieval was unavailable in the editing environment. User must download/select the official r160 module once or add it at that local project path. `file://` does not permit reliable Service Worker offline module loading; use HTTPS or localhost for persistent offline imports.
- 3D handoff format: recommend `.glb` (glTF 2.0 binary). Runtime GLB import is not yet wired; user-provided files can be inspected/integrated after upload.

## v28 — исправление запуска рендер-цикла

- Диагностика пользователя показала `TypeError: frame is not a function` в `chapter-3d.js:160` после успешной загрузки Three.js.
- Причина: локальная переменная `const frame = document.getElementById('chapterSceneFrame')` затеняла функцию `frame()`, запускающую RAF. Контейнер переименован в `sceneFrame`, цикл — в `renderLoop`.
- Цикл защищён от runtime-исключений: RAF останавливается, ошибка фиксируется в MeadowLog.
- Добавлен fail-fast после первого синхронного кадра и откат частичной инициализации в `start()`.
- При blur/скрытии вкладки очищаются клавиатура, джойстик и drag; снятие обработчика pointercancel теперь явное.
- Очистка охватывает кэшированные материалы/геометрии/текстуры, даже если сцена не была полностью построена.
- Добавлен `tests/chapter3d-smoke.cjs`: запуск, первый кадр, все четыре lazy-room, hotspot/actions, stop, restart, abort, ошибки первого/последующих кадров и потеря контекста. Проверено в Node с мок-реализацией Three.js.
- Ключи CSS/JS cache-busting обновлены до 43.0.0.
- Реальный GPU/WebGL на Android не тестировался; это остаётся проверкой на устройстве.


## Meadow v28 follow-up regression patch (resource revision 44.0.0)
- Fixed the chapter startup shadowing bug: `const frame = $('#chapterSceneFrame')` conflicted with the RAF function. The DOM reference is now `sceneFrame`; RAF callback is `renderLoop`.
- Fixed a menu geometry construction bug in the winding path: `quad(a,c,b,tone); quad(a,d,c,tone)` passed malformed argument positions; now a single four-vertex `quad(a,b,c,d,tone)` creates the path segment.
- Menu and chapter animation loops log and stop on runtime exceptions rather than silently freezing or repeatedly scheduling a broken loop.
- Chapter clears keyboard, joystick and drag state on blur/visibility/context loss and removes the relevant listeners during stop. Partial startup failures roll back renderer and scene resources.
- Regression tests: `tests/chapter3d-smoke.cjs` and `tests/menu-renderer-smoke.cjs`; run with Node from the project root. They are deterministic mocks/stubs and do not prove actual Android GPU compatibility.
- No bundled Three.js module is committed in `vendor/three/`; the README there explains this intentionally. Preserve the local r160 file the user already downloaded, or use the project loader.


## v28 Deep Audit

Исправлены `frame is not a function` (затенение RAF callback DOM-ссылкой), неправильные аргументы terrain `quad()` (цвет передавался вместо четвёртой вершины), добавлены rollback частичной инициализации, безопасный RAF failure, blur/pointercancel cleanup, grass GPU buffer release и кэширование uniform/attribute lookup.


## Meadow v28.1 deep audit (resource revision 45.0.0)

- Corrected terrain cell geometry: `quad(a,b,c,d,color,alternate)` now receives four positions, not a color array in the `d` vertex slot.
- Fixed RAF function shadowing and added transactional scene startup rollback, runtime frame exception handling, pointercancel/blur/visibility/context-loss input cleanup.
- Menu creation failures release partial WebGL resources. Grass-off frees three GPU buffers. Uniform/attribute lookups are cached by program.
- Added lookup-cache assertions and terrain-quad regression check to menu renderer test; retained chapter lifecycle regression test. Both pass. Manual real-browser smoke page is `tests/browser-webgl-smoke.html`; development Chromium's EGL backend could not initialize, so Android test remains required.
